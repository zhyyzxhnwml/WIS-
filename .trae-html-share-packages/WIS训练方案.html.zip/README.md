# InnoMap —— 基于知识重定向的跨领域创新辅助平台

闽江大学「大学生创新创业训练计划」创新训练项目（2026.06 – 2027.06）

> 用户输入一个技术问题（如「如何让无人机更抗冲击？」），系统从生物、物理、机械、材料等看似无关的领域中检索并映射出可借鉴的原理、结构或算法，生成具有原创性、可解释的跨领域创新方案。

---
## 目录

- [1. 项目模块总览](#1-项目模块总览)
- [2. 前端（frontend/）](#2-前端frontend)
- [3. 后端（backend/）](#3-后端backend)
- [4. 知识图谱（neo4j/ + crawler 导出）](#4-知识图谱neo4j--crawler-导出)
  - [4.1 数据来源](#41-数据来源)
  - [4.2 数据流向](#42-数据流向)
  - [4.3 RawDoc 统一格式](#43-rawdoc-统一格式data-rawjsonl)
  - [4.4 图谱标注记录](#44-图谱标注记录data-extractedrecordsjsonl)
  - [4.5 图谱结构（节点·关系·含义）](#45-图谱结构节点关系含义)
  - [4.6 构建图数据库的语句](#46-构建图数据库的语句)
- [5. 数据管道（crawler/）](#5-数据管道crawler)
- [6. 快速开始](#6-快速开始)
- [7. 关键技术决策](#7-关键技术决策)
- [8. 已知限制与后续计划](#8-已知限制与后续计划)

> 使用与配置指南：见 [`使用说明.md`](./使用说明.md)（启动 / AI 模型来源 / 页面操作 / 常见问题）
> 数据爬取与 Neo4j 导入教程：见 [`crawler/docs/数据爬取与Neo4j导入指南.md`](./crawler/docs/数据爬取与Neo4j导入指南.md)
> 数据合规与出处说明：见 [`crawler/docs/数据合规与出处说明.md`](./crawler/docs/数据合规与出处说明.md)

---

## 1. 项目模块总览

```
innomap/
├── frontend/          # Vue 3 前端（首页 + 结果可视化页 + 图谱浏览 + 登录/历史）
├── backend/           # FastAPI 后端（图谱检索 + LLM 融合 + 认证/历史）
├── neo4j/
│   └── init.cypher    # ⚠ 早期手工示例脚本（旧命名，与后端不兼容，已弃用勿执行，见文件头注释）
├── crawler/           # 数据管道（多源抓取 → LLM 抽取 → 校验 → Neo4j 导出）
├── 数据/              # 已入库图谱导入脚本（import_graph.cypher + extend_problems.cypher）
├── 部署安装指南.md     # 从零部署指南（下载软件 → 配置 → 导入 → 启动）
└── 使用说明.md         # 使用手册（启动 / AI 模型 / 页面操作 / 常见问题）
```

| 模块 | 技术栈 | 作用 |
|---|---|---|
| 前端 | Vue 3 + Vite + vue-router + ECharts | 输入问题、可视化展示映射路径与热力图 |
| 后端 | FastAPI + SQLAlchemy(MySQL) + Neo4j + DeepSeek | 检索调度、方案融合、用户认证与历史记录 |
| 图谱 | Neo4j + Cypher | 存储 跨领域重定向 知识（实例/概念/领域/TRIZ 原理） |
| 管道 | Python + DeepSeek API + YAML | 从维基/专利/开源语料生产真实结构化数据 |

---

## 2. 前端（frontend/）

**页面**
- 首页 `src/views/HomeView.vue`：Hero 主视觉、大号搜索框、项目指标、示例问题卡、三个核心能力、四步工作原理、底部 CTA
- 结果页 `src/views/ResultView.vue`：可改问题搜索、功能抽象摘要、三栏布局
  - 左：跨领域方案卡（领域色标、创新度、TRIZ、灵感实例、收益，点击联动高亮）
  - 中：**多领域并行路径图** `PathGraph.vue`（问题→功能→TRIZ→跨域概念→源领域实例→融合方案，`重定向·权重` 高亮边，可拖拽缩放、点节点看详情）
  - 右：**灵感热力图** `Heatmap.vue`（领域×领域关联度矩阵）+ 节点详情面板
  - 联动：**推理链** `ReasoningPanel.vue`（随选中方案展示「问题定位→功能抽象→矛盾识别→原理推演→概念中介→源域类比→方案落地」逐步推理）
- 图谱浏览页 `src/views/GraphExploreView.vue`：Neo4j 知识图谱可视化（ECharts 力导向图）
  - 按类型（问题/功能/TRIZ/概念/实例/领域）与领域筛选、关键字检索
  - 点击节点查看详情与邻域关系；「问题」节点可一键进入结果页
- 我的历史页 `src/views/HistoryView.vue`：登录后查看检索记录，点击直达结果
- 登录/注册页 `src/views/LoginView.vue`

**技术要点**
- 深色科技感 + 深蓝霓虹渐变主题，主色对齐项目 logo 深蓝
- ECharts 按需引入（`src/utils/echarts.js`），降低包体积
- 三种交互联动：点方案卡 → 高亮对应路径；点子图节点 → 右栏显示详情

**运行**
```bash
cd frontend
npm install
npm run dev        # http://localhost:5173
npm run build      # 产出 dist/
```

> 结果页已接入后端：搜索走 `/api/search`（带结果缓存，避免重复检索/重复调 LLM），失败自动回退本地 mock。首页示例与统计数字来自 `/api/samples`、`/api/stats`，后端不可用时回退默认展示。dev 模式下由 Vite 代理 `/api` → `http://127.0.0.1:8000`。

---

## 3. 后端（backend/）

FastAPI 服务：跨领域创新请求的检索调度、四支柱注释生成、用户认证与搜索历史。

**技术栈 / 结构**
```
backend/
├── app/
│   ├── main.py            # FastAPI 入口：CORS、路由、启动建表
│   ├── core/              # config(.env 读取)、security(bcrypt + JWT)
│   ├── db/                # mysql.py(SQLAlchemy)、neo4j.py(driver 单例)
│   ├── models/            # users、search_history（MySQL 表）
│   ├── schemas/           # auth / knowledge / history 的 Pydantic 模型
│   ├── routers/           # auth、history、knowledge 路由
│   ├── services/          # 检索与融合核心（见下）
│   └── utils/deps.py      # 登录态依赖（强制/可选）
├── tests/test_api.py      # pytest：检索/认证/历史端到端
├── requirements.txt
└── .env(.example)         # MySQL / Neo4j / DeepSeek 凭据（已 gitignore）
```

**检索与融合策略（app/services/）**

1. `alias.py`：自然问法 → 图谱问题节点（覆盖图谱 5 个问题的多种问法）
2. `graph_engine.py`：
   - `chain_from_problem`：问题→功能→TRIZ→概念→实例→方案 的完整证据链查询
   - `search_chains`：当没有精确图谱节点时，抽取问题字词与概念/功能名做 `CONTAINS` 检索
   - `build_heatmap`：概念所属领域 × 实例领域 的关联强度矩阵（归一化 0-100）
3. `fusion.py`：把证据链拼装为与前端 `buildExample(meta)` 一致的结构，每个 lane 附带**四段注释**：`triz`（TRIZ 原理依据）、`functionAbstraction`（功能抽象）、`crossDomainAnalogy`（跨领域类比映射）、`knowledgeGraph`（图谱证据链）
4. `llm_engine.py`：`deepseek-chat` 真调（`response_format: json_object`）+ **按问题内存缓存**，未命中图谱且缓存失效时才调 API，避免滥用
5. `catalog.py`：`/api/samples` 动态样例（图谱 5 问题 + 3 内置示例）

**接口一览**（交互文档 http://127.0.0.1:8000/docs）

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | /api/search | 问题 → 跨域方案（公开；登录后自动记录历史） |
| GET | /api/samples | 示例问题列表（首页卡片，图谱 19 个 + 内置 2 个） |
| GET | /api/stats | 图谱统计：节点/关系/领域/TRIZ 数（首页指标） |
| GET | /api/graph/summary | 图谱浏览页指标与领域分布 |
| GET | /api/graph/network | 力导向图数据（按类型/领域/关键字过滤，节点+边） |
| GET | /api/graph/node | 节点详情与邻域关系（?name=节点名） |
| POST | /api/auth/register | 注册（返回 JWT） |
| POST | /api/auth/login | 登录（返回 JWT） |
| GET | /api/auth/me | 当前用户 |
| GET | /api/history | 我的搜索历史（列表） |
| GET | /api/history/{id} | 历史完整结果（json） |

**运行**
```bash
cd backend
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt
copy .env.example .env    # 填入 MySQL/Neo4j/DeepSeek 真实凭据
.venv\Scripts\python -m uvicorn app.main:app --reload --port 8000
```

**测试**
```bash
cd backend
.venv\Scripts\python -m pytest tests -q
```

---

## 4. 知识图谱（neo4j/ + crawler 导出）

本小节说明：**数据从哪来、每类数据长什么样、如何构建成图数据库**。
建库脚本 `neo4j/init.cypher`（手工示例 + 结构定义）与 crawler 自动导出的
`data/output/graph_import.cypher`（海量真实数据）共用同一套标签/关系建模，可共存于同一库。

### 4.1 数据来源

| 来源 | 数据形态 | 获取方式 | 需外网 | 许可/合规 |
|---|---|---|---|---|
| 维基百科（zh/en） | 仿生学、机构学、力学、材料等分类下的条目摘要 | `crawler` 的 MediaWiki API 抓取 | 是 | CC BY-SA，**保留出处** |
| 开放专利 PatentView | 各领域检索词匹配的专利摘要 | `crawler` 的 PatentsView API | 是 | USPTO 官方开放数据 |
| 百度百科 | 「蜂巢」「气凝胶」等 60+ 词条的 lemma-summary | `crawler` 页面抓取 | 否 | 部分 IP 会 403 |
| GitHub / Gitee 开源语料 | 仓库内 json/jsonl/csv/txt 语料 | contents API（经 `github_open.py`，统一实现） | 否 | 沿用各仓库许可证 |
| 内建精选语料 | 围绕 9 大领域的跨领域创新词条（1030 条已全量导入，覆盖量产级） | `crawler/scripts/build_custom.py` 编译 `crawler/scripts/custom_data/custom_*.json` → `data/raw/custom.jsonl`（走同一管线） | 否 | 公开资料/公开论文，留出处 |

> 三条生产链路的目标量级 1000–2000 条有效「概念→实例」重定向（≥ 申报书要求的 500 三元组）。

### 4.2 数据流向

```
维基/专利/百科/GitHub/Gitee
        │  抓取（各源独立命令）
        ▼
  data/raw/<source>.jsonl        ← RawDoc 统一格式（见 4.3）
        │  DeepSeek 结构化抽取（src/extract/）
        ▼
  data/extracted/records.jsonl   ← 图谱标注记录（见 4.4）
        │  去重 · 校验 · 20%人工核对清单（src/pipeline/）
        ▼
  data/output/graph_import.cypher ← Neo4j 导入语句（见 4.6）
```

### 4.3 RawDoc 统一格式（`data/raw/*.jsonl`）

每个数据源抓出后，统一归一化为一行一个 JSON 文档，字段如下：

```json
{
  "id": "wikipedia_zh_仿生学_蜂巢",
  "title": "蜂巢",
  "lang": "zh",                    // zh | en
  "field": "生物",                 // 领域先验（来自种子分类/检索词/keyword）
  "text": "蜜蜂的巢……",            // 摘要/正文（截断至 max_chars）
  "url": "https://zh.wikipedia.org/wiki/...",
  "source": "wikipedia",           // wikipedia | patents | baike | github | gitee
  "meta": { "category": "仿生学", "patent_id": "...", "cpc": "...", "keyword": "蜂巢" }
}
```

> 不同源的差异只在 `id` 前缀、`source`、`meta`；`extract` 只依赖 `text/title/lang/field/url`，
> 因此数据源可随时替换或新增，不影响下游。

### 4.4 图谱标注记录（`data/extracted/records.jsonl`）

DeepSeek 从每条 raw 文档抽取出的、可直接入库的结构化标注（每行一条）：

```json
{
  "raw_id": "wikipedia_zh_仿生学_蜂巢",
  "title": "蜂巢",
  "source": "wikipedia",
  "lang": "zh",
  "url": "https://zh.wikipedia.org/wiki/...",
  "concept": "多孔胞元结构",            // 跨领域抽象隐喻（核心）
  "instance": "蜂巢六边形结构",          // 源领域具体实例
  "field": "材料",                       // 实例所属领域
  "function": "在轻量下承受压力",        // 可实现的抽象功能（动词+宾语）
  "concept_desc": "六边形蜂窝胞元受压承载",
  "instance_desc": "蜂巢六边形胞元高强轻量",
  "triz_principle": "多孔材料原理",      // 可由 LLM 判断（可空）
  "triz_no": "31",
  "weight": 0.83,                        // 0~1 重定向强度（前端高亮）
  "why": "轻质高比强度，可迁移到轻量化抗冲击结构"
}
```

- 只有 `usable == true` 才保留；字段不全的记录在导出时补齐默认值（`weight` 缺省 0.8）。
- 语义去重：以 `(concept, instance)` 归一化 + 同领域概念相似度（阈值 0.92）双重去重。

### 4.5 图谱结构（节点 · 关系 · 含义）

**节点（6 + 1 类）**

| 标签 | 关键属性 | 含义 | 来源 |
|---|---|---|---|
| `问题` | `name`(唯一), `所属领域`, `场景` | 用户输入的技术难题 | `init.cypher` 手工示例 |
| `功能` | `name`(唯一), `描述` | 问题抽象出的核心功能 | 示例/LMM 抽取 |
| `TRIZ原理` | `name`(唯一), `编号` | 40 个发明原理 | 标准 TRIZ |
| `概念` | `name`(唯一), `描述`, `来源_url` | **跨域抽象隐喻（中介）** | LLM 抽取 |
| `实例` | `name`(唯一), `描述`, `来源_url` | 源领域具体对象 | 抓取+抽取 |
| `领域` | `name`(唯一), 索引 | 实例归属的领域 | 归一化映射 |
| `方案` | `name`(唯一,与`融合`组合), `创新度`, `融合` | 生成的方案（可分融合/单域） | 示例/LMM 生成 |

**关系（边）**

> 以 `数据/图数据库/import_graph.cypher` 实际建模为准（`neo4j/init.cypher` 为早期旧命名，已弃用）。

| 关系 | 方向 | 属性 | 语义 |
|---|---|---|---|
| `-[:具备功能]->` | 问题→功能 | — | 问题需要满足的功能 |
| `-[:运用TRIZ原理]->` | 功能→TRIZ原理 | — | 功能匹配对应的发明原理 |
| `-[:启发]->` | TRIZ原理→概念 | — | 原理推演出跨域概念 |
| `-[:所属领域]->` | 概念→领域 | — | 概念归属领域（跨域中介） |
| `-[:参考]->` | 概念→实例 | weight | **核心**：概念跨领域重定向到源领域实例 |
| `-[:包含]->` | 领域→实例 | — | 领域所包含的实例 |
| `-[:生成]->` | 实例→方案 | — | 从实例生成单领域方案 |

**一句话刻画**：`问题 →功能 →TRIZ原理 →概念 →(参考)实例 →方案`，
多领域各走一条并行链；`方案` 节点的 `融合` 属性标记各级方案的聚合关系。

### 4.6 构建图数据库的语句

**步骤 0：清空重建（如需）**
```cypher
MATCH (n) DETACH DELETE n;
```

**步骤 1：建约束与索引（`neo4j/init.cypher` 顶部，幂等）**
```cypher
CREATE CONSTRAINT problem_name IF NOT EXISTS FOR (n:问题)   REQUIRE n.name IS UNIQUE;
CREATE CONSTRAINT function_name IF NOT EXISTS FOR (n:功能)   REQUIRE n.name IS UNIQUE;
CREATE CONSTRAINT principle_name IF NOT EXISTS FOR (n:TRIZ原理) REQUIRE n.name IS UNIQUE;
CREATE CONSTRAINT concept_name IF NOT EXISTS FOR (n:概念)    REQUIRE n.name IS UNIQUE;
CREATE CONSTRAINT instance_name IF NOT EXISTS FOR (n:实例)   REQUIRE n.name IS UNIQUE;
CREATE CONSTRAINT domain_name IF NOT EXISTS FOR (n:领域)     REQUIRE n.name IS UNIQUE;
CREATE CONSTRAINT scheme_name IF NOT EXISTS FOR (n:方案)     REQUIRE (n.name, n.融合) IS UNIQUE;
CREATE INDEX domain_idx IF NOT EXISTS FOR (n:领域) ON (n.name);
```

**步骤 2：写入一条完整映射链（手工示例，单条代表`import_graph.cypher`中一个区块）**
```cypher
MERGE (p:问题 { name: '如何让无人机更抗冲击？', 所属领域: '航空', 场景: '户外炸机频繁' })
MERGE (f:功能 { name: '吸收冲击能量', 描述: '碰撞瞬间耗散冲击动能' })
MERGE (p)-[:具备功能]->(f)
MERGE (t:TRIZ原理 { name: '缓冲原理', 编号: '9' })
MERGE (c:概念 { name: '弹性缓冲', 描述: '以弹性元件吸收冲击动能' })
MERGE (e:实例 { name: '人体软骨减震结构', 描述: '软骨借孔穴压缩吸收冲击' })
MERGE (d:领域 { name: '生物领域' })
MERGE (s:方案 { name: '仿生弹性缓冲无人机框架', 创新度: 92, 融合: false })
MERGE (c)-[:所属领域]->(d)
MERGE (d)-[:包含]->(e)
MERGE (f)-[:运用TRIZ原理]->(t)
MERGE (t)-[:启发]->(c)
MERGE (c)-[:参考 { weight: 0.87 }]->(e)
MERGE (e)-[:生成]->(s);
```
> 完整真实数据见 `数据/图数据库/import_graph.cypher`（19 个问题节点的证据链）。
> `方案` 节点的 `融合` 属性标记聚合性：单域方案 `融合:false`，最终聚合方案 `融合:true`。

**步骤 3：批量导入爬取数据（`数据/图数据库/import_graph.cypher`）**

每条标注记录生成一段可重复执行的 `MERGE`（字段即 4.4 的标注）：
```cypher
MERGE (c:概念 { name: '多孔胞元结构', 描述: '六边形蜂窝胞元受压承载', 来源_url: 'https://…' })
MERGE (e:实例 { name: '蜂巢六边形结构', 描述: '蜂巢六边形胞元高强轻量', 来源_url: 'https://…' })
MERGE (d:领域 { name: '材料' })
MERGE (d)-[:包含]->(e)
MERGE (c)-[:所属领域]->(d)
MERGE (c)-[:参考 { weight: 0.83 }]->(e)
// 若抽到 TRIZ/功能，再补：
MERGE (t:TRIZ原理 { name: '多孔材料原理', 编号: '31' })
MERGE (t)-[:启发]->(c)
MERGE (f:功能 { name: '在轻量下承受压力' })
MERGE (f)-[:运用TRIZ原理]->(t)
MERGE (sc:方案 { name: '基于多孔胞元结构的蜂巢六边形结构应用方案', 创新度: 80, 融合: false })
MERGE (e)-[:生成]->(sc);
```

**运行方式**
```bash
# Neo4j Browser：直接粘贴 `数据/图数据库/import_graph.cypher` 与 `extend_problems.cypher` 执行
# 命令行（后端已启动时也可用脚本）：
.\.venv\Scripts\python -m scripts.load_cypher ..\数据\图数据库\import_graph.cypher
.\.venv\Scripts\python -m scripts.load_cypher ..\数据\图数据库\extend_problems.cypher
```

**步骤 4：演示查询（`数据/图数据库/import_graph.cypher` 末尾）**

① 单问题完整重定向链（路径图数据源）：
```cypher
MATCH (p:问题 { name: '无人机抗冲击能力不足' })-[:具备功能]->(f)
MATCH (f)-[:运用TRIZ原理]->(t)-[:启发]->(c)-[:参考 { weight: w }]->(e)
MATCH (d:领域)-[:包含]->(e)
OPTIONAL MATCH (e)-[:生成]->(s)
RETURN d.name AS 源领域, t.name AS 发明原理, c.name AS 跨域概念,
       w AS 映射强度, e.name AS 灵感实例, s.name AS 方案
ORDER BY w DESC;
```
② 某问题下的所有方案：
```cypher
MATCH (p:问题 { name: '无人机抗冲击能力不足' })
MATCH (p)-[:具备功能]->(:功能)-[:运用TRIZ原理]->(:TRIZ原理)-[:启发]->(:概念)-[:参考]->(:实例)-[:生成]->(s:方案)
RETURN s.name AS 方案, s.创新度 AS 创新度 ORDER BY s.创新度 DESC;
```
③ 领域间连接强度（热力图数据源）：
```cypher
MATCH (d2:领域)-[:包含]->(e)
MATCH (c:概念)-[:所属领域]->(d)
MATCH (c)-[:参考 { weight: w }]->(e)
RETURN d.name AS 目标领域, d2.name AS 来源领域, round(avg(w) * 100) AS 关联度
ORDER BY 关联度 DESC;
```

---

## 5. 数据管道（crawler/）

把来源语料爬成结构化图谱数据。目录：`crawler/`，详见其内部 `README.md`。

```
raw/*.jsonl  --LLM抽取-->  extracted/records.jsonl  --去重/校验-->  --导出-->  graph_import.cypher
```

**数据源**（`config.yaml` 可配）

| 源 | 命令 | 需外网 |
|---|---|---|
| 维基百科（zh/en） | `python -m src.cli wiki --lang both` | 是 |
| 开放专利 PatentsView | `python -m src.cli patents --pages 3` | 是 |
| 百度百科 | `python -m src.cli baike` | 否（部分 IP 会 403）     |
| GitHub 开源语料 | `python -m src.cli github` | 否（contents API）  |
| Gitee 开源语料 | `python -m src.cli gitee` | 否（国内最稳，已实测） |


**流程**
```bash
cd crawler
pip install -r requirements.txt
set DEEPSEEK_API_KEY=<你自己的 DeepSeek API Key>

python -m src.cli wiki --lang both    # 或 gitee / patents / baike
python -m src.cli extract             # DeepSeek 并发结构化抽取（注意 API 成本）
python -m src.cli validate            # 去重 + 统计 + 20% 人工核对清单
python -m src.cli export              # → graph_import.cypher，导入 Neo4j
```

**设计要点**
- 数据源统一产出 raw JSONL，可替换/可在有网环境单独跑
- deepseek 结构化抽取（并发、重试、JSON 清洗），`src/extract/`
- 校验：字段完整率、领域分布、去重、20% 人工抽样核对清单
- 每个节点带 `来源_url` 属性，保留出处合规引用
- LLM 抽取前建议小批量试跑控制成本

---

## 6. 快速开始

前置：本地 MySQL 8（建库 `CREATE DATABASE innomap CHARACTER SET utf8mb4;`）、Neo4j（导入
`数据/图数据库/import_graph.cypher` 后即含 5 个问题的真实链路）。

1. **启动后端**：`cd backend && .venv\Scripts\python -m uvicorn app.main:app --reload --port 8000`
2. **启动前端**：`cd frontend && npm run dev` → http://localhost:5173
3. **验证**：浏览器打开 http://localhost:5173，搜索「如何让无人机更抗冲击？」（走图谱证据链）、「如何让建筑物外墙更保温？」（走 LLM 融合）。方案生成的大模型**无内置密钥**：可在页面右上角「AI 模型」弹窗配置你自己的 DeepSeek Key 或本机 **Ollama**（详见根目录 `使用说明.md`）。
4. **跑测试**：`cd backend && .venv\Scripts\python -m pytest tests -q`

---

## 7. 关键技术决策

| 决策点 | 结论 |
|---|---|
| 视觉风格 | 深色科技感 + 深蓝霓虹渐变（对齐 logo 深蓝） |
| 页面范围 | 先做核心页（首页 + 结果可视化页） |
| 路径图形态 | 多领域并行链路（非单链），强调「跨多个无关领域」 |
| 重构核心 | 服务端入库「重定向」关系，封装为事实 |
| 图谱建模 | 显式 `重定向`、双引擎分工、实例属于领域、方案聚合 |
| 抽取引擎 | DeepSeek + 20% 人工抽检 + `quality` 自动质检（0 high/0 medium，8 low 近义候选） |
| 检索性能 | 全标签 name 属性索引 + 名称精确匹配优先（CONTAINS 兜底）+ vocab 60s 缓存 |
| 运行时 AI 来源 | 使用者页面自配：DeepSeek Key 或本机 Ollama（`GET /api/llm/status` 探测，无内置密钥） |
| 防滥用 | `/api/search` 滑动窗口限流（默认 12 次/分）+ LLM 4xx 不重试、5xx/超时自动重试 + 错误原因透传前端 |
| 数据量产级 | 1000–2000 条完整版（满足申报书 ≥500 三元组）；当前已入库 1030 条语料 |
| 国内源替换 | Gitee 最稳（已实测）；当前作演示仓库，可用自建仓库替换 |

---

## 8. 已知限制与后续计划

- 图谱已覆盖 19 个问题节点（5 个原始示例 + 14 个新扩充），每问题均有完整证据链；其余问题走 LLM 融合或兜底模板。后续以爬取管道继续扩充规模。
- 批量扩充已完成：内置精选语料（9 大领域）经 `crawler/scripts/build_custom.py` 编译为 1030 条 raw，走 DeepSeek 结构化抽取 → 校验 → 自动导出 → 导入合并。库当前共 **3300 节点 / 5656 关系（概念 956、实例 1162、方案 1102、问题 19、TRIZ 原理 41（全链）、功能 10、领域 10）**，跨 9 领域的常用原理链均已覆盖（`/api/search`、图谱浏览 `/api/graph/network` 均可命中），已进入 README 量产级区间。
- 维基/PatentsView 需外网；百度百科当前出口 IP 触发 403；Gitee 匿名无法按主题搜索仓库，需用已知名或自建仓库。
- LLM 抽取无自动质检；仅 20% 人工抽检。建议增加「重定向强度异常、概念过泛」自动检测。
- 前端仍需服务端渲染/鉴权增强：「我的历史」依赖登录态，token 存 localStorage（演示级别）。

**待办建议**
1. 扩充图谱：基于爬取管道为更多问题建立真实证据链（抓取 → 抽取 → 质检 → 导入）
2. LLM 抽取结果的自动质检（重定向强度异常、概念过泛检测）
3. 结果页「更多示例」改为从 `/api/samples` 动态加载（当前首页已动态）
4. 图谱浏览页增强：按问题维度展开证据链、节点溯源高亮
```
