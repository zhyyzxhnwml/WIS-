"""导入 cypher 脚本到 Neo4j 数据库。

用法：python scripts/load_cypher.py <graph.cypher>
每条语句以分号结束，逐条事务执行（幂等 MERGE 可重复运行）。
"""
import sys
from pathlib import Path

from app.db import neo4j


def main():
    path = Path(sys.argv[1] if len(sys.argv) > 1 else r"..\..\数据\图数据库\extend_problems.cypher")
    text = path.read_text(encoding="utf-8-sig")
    statements = [s.strip() for s in text.split(";") if s.strip()]
    for i, stmt in enumerate(statements, 1):
        neo4j.run(stmt)
        print(f"[{i}/{len(statements)}] executed ({len(stmt)} chars)")
    print("done:", path.name)


if __name__ == "__main__":
    main()