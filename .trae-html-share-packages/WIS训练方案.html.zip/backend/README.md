# InnoMap 后端

FastAPI + SQLAlchemy(PyMySQL/MySQL) + Neo4j + DeepSeek 的大创后端。

## 启动

```powershell
cd backend
.venv\Scripts\python -m uvicorn app.main:app --reload --port 8000
```

- 交互文档：http://127.0.0.1:8000/docs
- 健康检查：http://127.0.0.1:8000/api/health

## 依赖服务

- MySQL 8（127.0.0.1:3306），需先建库：`CREATE DATABASE innomap CHARACTER SET utf8mb4;`（表由启动时自动创建）
- Neo4j（bolt://localhost:7687），图数据见 `数据/图数据库/import_graph.cypher`，密码等配置在 `.env`

## 配置文件

复制 `.env.example` 为 `.env` 并填入真实凭据；`.env` 已被 gitignore，勿提交。

## 接口一览

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | /api/search | 创新问题→跨域方案（公开；登录后自动记录历史） |
| GET | /api/samples | 示例问题列表 |
| POST | /api/auth/register | 注册 |
| POST | /api/auth/login | 登录，返回 JWT |
| GET | /api/auth/me | 当前用户 |
| GET | /api/history | 我的搜索历史 |
| GET | /api/history/{id} | 历史完整结果 |

`/api/search` 返回结构与前端 `mock.js` 的 `buildExample(meta)` 入参一致（含 4 段 annotation）。

## 检索策略

1. 三方别名表：前端示例问题 → 图谱问题节点（0 调用 LLM，走图谱证据链）
2. 关键词匹配：抽取问题字词与图谱概念/功能名做 CONTAINS 检索
3. 兜底：DeepSeek `deepseek-chat`（json_object）+ 内置 fallback 模板，结果带内存缓存避免滥用 API