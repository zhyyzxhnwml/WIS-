﻿from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.core.security import decode_access_token
from app.db.mysql import get_db
from app.models.user import User

_bearer = HTTPBearer(auto_error=False)


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer),
    db: Session = Depends(get_db),
) -> User:
    subject = _resolve_subject(credentials)
    if subject is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="未登录")
    return _load_user(db, subject)


def get_current_user_optional(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer),
    db: Session = Depends(get_db),
) -> User | None:
    subject = _resolve_subject(credentials)
    if subject is None:
        return None
    return _load_user(db, subject)


def _resolve_subject(credentials: HTTPAuthorizationCredentials | None):
    if credentials is None:
        return None
    return decode_access_token(credentials.credentials)


def _load_user(db: Session, subject: str) -> User:
    # subject 来自 JWT 的 sub，正常应为本系统签发的数字用户 id；
    # 但恶意/失效 token 的 sub 可能不是数字，int() 会抛异常导致 500，
    # 这里统一拦截，按「未登录」处理而非内部错误。
    try:
        user_id = int(subject or "")
    except (TypeError, ValueError):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="无效的登录凭证")
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="用户不存在")
    return user