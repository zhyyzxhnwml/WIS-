from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .core.config import settings
from .db import indexes, neo4j
from .db.mysql import Base, engine
from .models import history, user  # noqa: F401
from .routers import auth, graph, history as history_router, knowledge


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    try:
        indexes.ensure_indexes()
    except Exception as e:  # noqa: BLE001
        print(f"[indexes] skip: {e}")
    yield
    neo4j.close_driver()


app = FastAPI(title="InnoMap API", version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(knowledge.router)
app.include_router(auth.router)
app.include_router(history_router.router)
app.include_router(graph.router)


@app.get("/")
def root():
    return {"service": "InnoMap API", "docs": "/docs"}