from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from app.db.mysql import Base


class SearchHistory(Base):
    """搜索历史记录表（MySQL search_history）。

    每次登录用户发起 /api/search 时写入一条；
    result_json 存整份方案结果（含 lanes / heatmap / annotation），
    「我的历史」页直接回放该 JSON 即可还原结果页。
    """

    __tablename__ = "search_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), index=True, nullable=False)
    question: Mapped[str] = mapped_column(String(255), nullable=False)
    result_json: Mapped[str] = mapped_column(Text, nullable=False)  # 完整方案结果 JSON
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)