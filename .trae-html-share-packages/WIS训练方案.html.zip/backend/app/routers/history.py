import json

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.mysql import get_db
from app.models.history import SearchHistory
from app.models.user import User
from app.schemas.history import HistoryOut
from app.utils.deps import get_current_user

router = APIRouter(prefix="/api/history", tags=["history"])


@router.get("", response_model=list[HistoryOut])
def list_history(
    limit: int = 50,
    user: User = Depends(get_current_user),  # 需登录，按当前用户隔离
    db: Session = Depends(get_db),
):
    """按创建时间倒序列出当前用户的历史记录（默认 50 条，上限 200 条）。"""
    items = (
        db.query(SearchHistory)
        .filter(SearchHistory.user_id == user.id)
        .order_by(SearchHistory.id.desc())
        .limit(min(limit, 200))
        .all()
    )
    return [HistoryOut.model_validate(i) for i in items]


@router.get("/{history_id}", response_model=dict)
def get_history(
    history_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # 同时限定 id 与 user_id，防止越权读取他人历史
    item = (
        db.query(SearchHistory)
        .filter(SearchHistory.id == history_id, SearchHistory.user_id == user.id)
        .first()
    )
    if item is None:
        raise HTTPException(status_code=404, detail="记录不存在")
    return json.loads(item.result_json)