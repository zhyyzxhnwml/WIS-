﻿import json

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db import neo4j
from app.db.mysql import get_db
from app.models.history import SearchHistory
from app.schemas.knowledge import ExampleMetaOut, SampleQuestionOut, SearchRequest, StatsOut
from app.services.catalog import all_samples
from app.services.fusion import build_example
from app.services.llm_engine import ollama_models
from app.services.ratelimit import SlidingWindowLimiter
from app.utils.deps import get_current_user_optional

router = APIRouter(prefix="/api", tags=["knowledge"])

_search_limiter = SlidingWindowLimiter(settings.RATE_LIMIT_SEARCH, settings.RATE_LIMIT_WINDOW)


@router.post("/search", response_model=ExampleMetaOut)
def search(
    payload: SearchRequest,
    request: Request,
    db: Session = Depends(get_db),
    user=Depends(get_current_user_optional),
):
    key = f"u{user.id}" if user is not None else f"ip{request.client.host}"
    if not _search_limiter.allow(key):
        raise HTTPException(
            status_code=429,
            detail=f"请求过于频繁，请 {settings.RATE_LIMIT_WINDOW} 秒后再试",
            headers={"Retry-After": str(settings.RATE_LIMIT_WINDOW)},
        )
    result = build_example(
        payload.question,
        api_key=payload.api_key,
        provider=payload.provider,
        model=payload.model,
    )
    if user is not None:
        record = SearchHistory(
            user_id=user.id,
            question=payload.question,
            result_json=json.dumps(result, ensure_ascii=False),
        )
        db.add(record)
        db.commit()
    return result


@router.get("/samples", response_model=list[SampleQuestionOut])
def samples():
    return all_samples()


@router.get("/stats", response_model=StatsOut)
def stats():
    try:
        def _count(query: str) -> int:
            rows = neo4j.run(query)
            return int(rows[0]["c"]) if rows else 0

        return StatsOut(
            nodes=_count("MATCH (n) RETURN count(n) AS c"),
            relations=_count("MATCH ()-[r]->() RETURN count(r) AS c"),
            domains=_count("MATCH (d:领域) RETURN count(d) AS c"),
            triz=_count("MATCH (t:TRIZ原理) RETURN count(t) AS c"),
        )
    except Exception:
        raise HTTPException(status_code=503, detail="知识图谱暂不可用")


@router.get("/llm/status")
def llm_status():
    """探测可用的大模型来源：DeepSeek（是否已配置 key）与本机 Ollama（是否可达、装了哪些模型）。"""
    models = ollama_models()
    return {
        "deepseek_available": bool(settings.DEEPSEEK_API_KEY),
        "ollama_available": len(models) > 0,
        "ollama_models": models,
        "default_ollama_model": models[0] if models else "",
    }


@router.get("/health")
def health():
    return {"status": "ok"}