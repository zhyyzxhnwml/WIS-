from fastapi import APIRouter, Query

from app.db import neo4j
from app.services.graph_engine import short_domain

router = APIRouter(prefix="/api/graph", tags=["graph"])

NODE_LABELS = {"问题", "功能", "TRIZ原理", "概念", "实例", "领域", "方案"}

RANK = {"领域": 0, "概念": 1, "实例": 2, "问题": 3, "功能": 4, "TRIZ原理": 5, "方案": 6}


@router.get("/summary")
def graph_summary():
    total = neo4j.run("MATCH (n) RETURN count(n) AS c")[0]["c"]
    rels = neo4j.run("MATCH ()-[r]->() RETURN count(r) AS c")[0]["c"]
    problems = neo4j.run("MATCH (p:问题) RETURN count(p) AS c")[0]["c"]
    concepts = neo4j.run("MATCH (c:概念) RETURN count(c) AS c")[0]["c"]
    instances = neo4j.run("MATCH (e:实例) RETURN count(e) AS c")[0]["c"]
    domain_rows = neo4j.run(
        """
        MATCH (d:领域)
        OPTIONAL MATCH (c:概念)-[:所属领域]->(d)
        OPTIONAL MATCH (e:实例)<-[:包含]-(d)
        RETURN d.name AS name,
               count(DISTINCT c) AS concepts,
               count(DISTINCT e) AS instances
        ORDER BY instances DESC
        """
    )
    domains = [
        {"name": short_domain(r["name"]), "full": r["name"], "concepts": r["concepts"] or 0, "instances": r["instances"] or 0}
        for r in domain_rows
    ]
    return {
        "nodes": total,
        "relations": rels,
        "problems": problems,
        "domains": domains,
    }


@router.get("/network")
def graph_network(
    domain: str | None = None,
    q: str | None = None,
    labels: str | None = Query(default=None, description="逗号分隔，如 概念,实例,领域"),
    limit: int = 350,
):
    params = {}
    if domain:
        domain_full = domain
        for r in neo4j.run("MATCH (d:领域) RETURN d.name AS n"):
            if r["n"] == domain or short_domain(r["n"]) == domain:
                domain_full = r["n"]
                break
        params["domain"] = domain_full
        match_clause = """
        MATCH (d:领域 {name:$domain})
        WITH d
        OPTIONAL MATCH (d)<-[:所属领域]-(c:概念)
        OPTIONAL MATCH (t:TRIZ原理)-[:启发]->(c)
        OPTIONAL MATCH (f:功能)-[:运用TRIZ原理]->(t)
        OPTIONAL MATCH (p:问题)-[:具备功能]->(f)
        OPTIONAL MATCH (d)-[:包含]->(e:实例)
        WITH collect(DISTINCT c) + collect(DISTINCT t) + collect(DISTINCT f)
             + collect(DISTINCT p) + collect(DISTINCT e) + collect(DISTINCT d) AS alln
        MATCH (n)-[r]->(m)
        WHERE n IN alln AND m IN alln
        """
    else:
        match_clause = "MATCH (n)-[r]->(m)"
    query = f"{match_clause} RETURN n, labels(n)[0] AS nl, type(r) AS rt, m, labels(m)[0] AS ml LIMIT 5000"
    rows = neo4j.run(query, **params)

    allowed = None
    if labels:
        allowed = {s.strip() for s in labels.split(",") if s.strip() in NODE_LABELS}

    node_map = {}
    links = []
    for r in rows:
        nl, ml = r["nl"], r["ml"]
        if allowed and (nl not in allowed or ml not in allowed):
            continue
        n, m = r["n"], r["m"]
        if q:
            nv = f"{n.get('name','')}{n.get('描述','')}".lower()
            mv = f"{m.get('name','')}{m.get('描述','')}".lower()
            if q.lower() not in nv and q.lower() not in mv:
                continue
        nid, mid = n["name"], m["name"]
        node_map.setdefault(nid, {"id": nid, "name": nid, "label": nl, "desc": n.get("描述") or ""})
        node_map.setdefault(mid, {"id": mid, "name": mid, "label": ml, "desc": m.get("描述") or ""})
        links.append({"source": nid, "target": mid, "type": r["rt"]})

    nodes = list(node_map.values())
    for nd in nodes:
        nd["degree"] = sum(1 for l in links if l["source"] == nd["id"] or l["target"] == nd["id"])

    if len(nodes) > limit:
        nodes.sort(key=lambda x: (RANK.get(x["label"], 9), -x["degree"]))
        keep = {n["id"] for n in nodes[:limit]}
        nodes = [n for n in nodes if n["id"] in keep]
    keep_ids = {n["id"] for n in nodes}
    links = [l for l in links if l["source"] in keep_ids and l["target"] in keep_ids]

    return {"nodes": nodes, "links": links}


@router.get("/node")
def graph_node(name: str = Query(...)):
    probe = neo4j.run(
        "MATCH (n {name:$name}) RETURN labels(n)[0] AS label, properties(n) AS props LIMIT 1",
        name=name,
    )
    if not probe:
        return {"node": None, "relations": []}
    node = {"name": name, "label": probe[0]["label"], "props": probe[0]["props"]}

    out = neo4j.run(
        "MATCH (n {name:$name})-[r]->(m) RETURN m, labels(m)[0] AS ml, type(r) AS rt",
        name=name,
    )
    inn = neo4j.run(
        "MATCH (s)-[r]->(n {name:$name}) RETURN s, labels(s)[0] AS sl, type(r) AS rt",
        name=name,
    )
    relations = []
    for r in out:
        relations.append({
            "type": r["rt"],
            "direction": "out",
            "to": {"name": r["m"]["name"], "label": r["ml"], "desc": r["m"].get("描述") or ""},
        })
    for r in inn:
        relations.append({
            "type": r["rt"],
            "direction": "in",
            "to": {"name": r["s"]["name"], "label": r["sl"], "desc": r["s"].get("描述") or ""},
        })
    return {"node": node, "relations": relations}