"""图谱属性索引（幂等）。"""

from app.db import neo4j

# 为检索主路径（名称精确/前缀）建立 RANGE 索引
_LABELS = {
    "概念": "concept",
    "实例": "instance",
    "功能": "function",
    "TRIZ原理": "triz",
    "领域": "domain",
    "问题": "problem",
    "方案": "scheme",
}


def ensure_indexes():
    """确保所有节点标签的 name 属性存在索引；IF NOT EXISTS 幂等，可随服务启动重复调用。"""
    created = []
    for label, key in _LABELS.items():
        q = f"CREATE INDEX {key}_name IF NOT EXISTS FOR (n:{label}) ON (n.name)"
        neo4j.run(q)
        created.append(key)
    return created


if __name__ == "__main__":
    print("indexes ensured:", ensure_indexes())