from app.services.alias import PROBLEM_DEFS

MOCK_SAMPLES = [
    {
        "question": "如何让建筑物外墙更保温？",
        "desc": "老旧建筑冬冷夏热，希望低成本提升热阻",
        "tags": ["建筑", "能源", "材料"],
        "source": "mock",
    },
    {
        "question": "如何让背包更轻便易收纳？",
        "desc": "差旅场景下希望空包可折叠、满载有支撑",
        "tags": ["出行", "机械", "折叠"],
        "source": "mock",
    },
]


def _graph_sample(name: str) -> dict:
    meta = PROBLEM_DEFS[name]
    return {
        "question": meta["question"],
        "name": name,
        "desc": meta["desc"],
        "tags": meta.get("funcs", [])[:3],
        "source": "graph",
    }


def all_samples() -> list[dict]:
    graph = [_graph_sample(name) for name in PROBLEM_DEFS]
    return graph + MOCK_SAMPLES