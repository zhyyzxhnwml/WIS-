﻿from app.core.config import settings
from app.db import neo4j

import time

CITY_TO_FRONTEND = {
    "生物领域": "生物",
    "机械工程领域": "机械",
    "物理领域": "物理",
    "材料科学领域": "材料",
    "化学化工领域": "化工",
    "电子信息领域": "电子信息",
    "航空航天领域": "航空",
    "建筑结构领域": "建筑",
    "能源动力领域": "能源",
    "算法领域": "算法",
}


def short_domain(name):
    if not name:
        return ""
    return CITY_TO_FRONTEND.get(name, name)


def _rows_to_chains(rows):
    chains = []
    for r in rows:
        if not (r.get("cn") and r.get("en")):
            continue
        chains.append(r)
    dedup = {}
    for r in chains:
        key = (r.get("tno"), r.get("cn"), r.get("en"))
        dedup.setdefault(key, r)
    ordered = list(dedup.values())

    def has_scheme(r):
        return bool(r.get("sn"))

    ordered.sort(key=has_scheme, reverse=True)
    return ordered


_CHAIN_QUERY = """
MATCH (p:问题 {name:$pname})-[:具备功能]->(f:功能)
MATCH (f)-[:运用TRIZ原理]->(t:TRIZ原理)
OPTIONAL MATCH (t)-[:启发]->(c:概念)
OPTIONAL MATCH (c)-[:所属领域]->(d:领域)
OPTIONAL MATCH (c)-[:参考]->(e:实例)
OPTIONAL MATCH (e)-[:生成]->(s:方案)
RETURN f.name AS fn, f.描述 AS fdesc,
       t.name AS tn, t.编号 AS tno, t.描述 AS tdesc,
       c.name AS cn, c.描述 AS cdesc, d.name AS dn,
       e.name AS en, e.描述 AS edesc, e.来源 AS esrc,
       s.name AS sn, s.描述 AS sdesc
"""

_SEARCH_QUERY = """
MATCH (c:概念)
WHERE c.name CONTAINS $kw OR c.描述 CONTAINS $kw
OPTIONAL MATCH (c)-[:所属领域]->(d:领域)
OPTIONAL MATCH (c)-[:参考]->(e:实例)
OPTIONAL MATCH (e)-[:生成]->(s:方案)
OPTIONAL MATCH (t:TRIZ原理)-[:启发]->(c)
RETURN '' AS fn, '' AS fdesc,
       t.name AS tn, t.编号 AS tno, t.描述 AS tdesc,
       c.name AS cn, c.描述 AS cdesc, d.name AS dn,
       e.name AS en, e.描述 AS edesc, e.来源 AS esrc,
       s.name AS sn, s.描述 AS sdesc
LIMIT 80
"""

_FUNC_QUERY = """
MATCH (f:功能)-[:运用TRIZ原理]->(t:TRIZ原理)
WHERE f.name CONTAINS $kw OR f.描述 CONTAINS $kw
OPTIONAL MATCH (t)-[:启发]->(c:概念)
OPTIONAL MATCH (c)-[:所属领域]->(d:领域)
OPTIONAL MATCH (c)-[:参考]->(e:实例)
OPTIONAL MATCH (e)-[:生成]->(s:方案)
RETURN f.name AS fn, f.描述 AS fdesc,
       t.name AS tn, t.编号 AS tno, t.描述 AS tdesc,
       c.name AS cn, c.描述 AS cdesc, d.name AS dn,
       e.name AS en, e.描述 AS edesc, e.来源 AS esrc,
       s.name AS sn, s.描述 AS sdesc
LIMIT 80
"""

# 名称精确匹配版本（CONTAINS 无法走属性索引，精确匹配可命中 RANGE 索引）
_SEARCH_EXACT_QUERY = _SEARCH_QUERY.replace(
    "WHERE c.name CONTAINS $kw OR c.描述 CONTAINS $kw",
    "WHERE c.name = $kw",
)
_FUNC_EXACT_QUERY = _FUNC_QUERY.replace(
    "WHERE f.name CONTAINS $kw OR f.描述 CONTAINS $kw",
    "WHERE f.name = $kw",
)


def chain_from_problem(pname: str):
    rows = neo4j.run(_CHAIN_QUERY, pname=pname)
    return _rows_to_chains(rows)


def search_chains(keywords):
    if not keywords:
        return []
    merged = []
    for kw in keywords:
        exact = neo4j.run(_SEARCH_EXACT_QUERY, kw=kw)
        if exact:
            merged.extend(exact)
        else:
            merged.extend(neo4j.run(_SEARCH_QUERY, kw=kw))
        fexact = neo4j.run(_FUNC_EXACT_QUERY, kw=kw)
        if fexact:
            merged.extend(fexact)
        else:
            merged.extend(neo4j.run(_FUNC_QUERY, kw=kw))
    return _rows_to_chains(merged)


def extract_keywords(question, vocab_names):
    q = question.lower()
    found = set()
    for name in vocab_names:
        name = (name or "").lower()
        if len(name) < 2:
            continue
        if name in q:
            found.add(name)
            continue
        for i in range(len(name) - 1):
            gram = name[i:i + 2]
            if len(gram) == 2 and gram in q:
                found.add(gram)
    return sorted(found, key=len, reverse=True)[:6]


_VOCAB_CACHE = {"ts": 0.0, "names": []}
_VOCAB_TTL = 60.0


def load_graph_vocab(force: bool = False):
    """拉取全部概念/功能名（用于关键词抽取）。进程内缓冲，TTL 60s。"""
    now = time.monotonic()
    if not force and _VOCAB_CACHE["names"] and (now - _VOCAB_CACHE["ts"]) < _VOCAB_TTL:
        return _VOCAB_CACHE["names"]
    rows = neo4j.run("MATCH (c:概念) RETURN c.name AS name UNION MATCH (f:功能) RETURN f.name AS name")
    names = [r.get("name") or "" for r in rows if r.get("name")]
    _VOCAB_CACHE["names"] = names
    _VOCAB_CACHE["ts"] = now
    return names


_HEATMAP_QUERY = """
MATCH (c:概念)-[:所属领域]->(dt:领域)
MATCH (c)-[:参考]->(e:实例)<-[:包含]-(ds:领域)
RETURN dt.name AS tgt, ds.name AS src, count(*) AS cnt
"""


def build_heatmap():
    rows = neo4j.run(_HEATMAP_QUERY)
    if not rows:
        return {"domains": [], "matrix": []}
    counts = {}
    for r in rows:
        t = short_domain(r["tgt"])
        s = short_domain(r["src"])
        counts.setdefault(t, {})
        counts[t][s] = counts[t].get(s, 0) + (r["cnt"] or 0)
    domains = sorted(counts.keys())
    size = len(domains)
    matrix = [
        [100 if i == j else 0 for j in range(size)]
        for i in range(size)
    ]
    off_diag = [counts[a].get(b, 0) for a in domains for b in domains if a != b]
    top = max(off_diag) if off_diag else 0
    if top > 0:
        for i in range(size):
            for j in range(size):
                if i != j:
                    v = counts[domains[i]].get(domains[j], 0)
                    matrix[i][j] = max(0, min(100, round(v * 100 / top)))
        for i in range(size):
            for j in range(size):
                if i != j:
                    merged = max(matrix[i][j], matrix[j][i])
                    matrix[i][j] = merged
                    matrix[j][i] = merged
    return {"domains": domains, "matrix": matrix}