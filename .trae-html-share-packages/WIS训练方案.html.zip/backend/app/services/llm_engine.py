import json
import time

import httpx

from app.core.config import settings

# 进程内 LLM 结果缓存（键 = provider/model/question）。为防止无限增长，超过 _CACHE_MAX
# 时整体清空（简单 LRU 不算这里的关键路径，清空一视同仁即可）。
_cache = {}
_CACHE_MAX = 128

_SYSTEM_PROMPT = (
    "你是跨领域知识重定向创新助理。请把用户给出的创新问题拆解为至少4个方案，"
    "每个方案对应一个不同领域，并基于TRIZ发明原理提供四元注释。"
    "必须返回合法JSON对象，结构为："
    "{'question','scene','coreFunction','functionDesc','schemeDesc',"
    "'lanes':[{'domain','triz','trizNo','trizDesc','concept','conceptDesc',"
    "'instance','instanceDesc','weight','score','schemeTitle','explanation','gains',"
    "'annotation':{'triz','functionAbstraction','crossDomainAnalogy','knowledgeGraph'}}]}"
    "各字段用中文，annotation 四段分别说明：TRIZ原理依据、功能抽象、跨域类比映射、知识图谱证据链。"
)


class LLMError(Exception):
    """携带可读错误码的大模型调用异常。

    code:
      - no_key       未配置任何 API Key（deepseek 且无 key）
      - no_model     ollama 未指定模型
      - auth         4xx 如 401/403（密钥无效）
      - rate_limited 429 限流
      - timeout|unreachable  网络/超时
      - http         其它 HTTP 错误
      - parse        LLM 输出无法解析（由调用方处理，不抛出）
    """

    def __init__(self, code: str, message: str):
        super().__init__(f"[{code}] {message}")
        self.code = code
        self.message = message


def _messages(question: str):
    return [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {"role": "user", "content": question},
    ]


def _call_deepseek(question: str, api_key: str, model: str) -> str:
    """调用 DeepSeek 兼容接口，返回原始 model 输出的文本。4xx 不重试，网络/5xx 重试。"""
    url = f"{settings.DEEPSEEK_BASE_URL}/v1/chat/completions"
    headers = {"Authorization": f"Bearer {api_key}"}
    payload = {
        "model": model or settings.DEEPSEEK_MODEL,
        "temperature": 0.7,
        "max_tokens": 4096,
        "response_format": {"type": "json_object"},
        "messages": _messages(question),
    }
    return _post_with_retry(url, payload, headers, provider="deepseek")


def _call_ollama(question: str, model: str) -> str:
    """调用本机 Ollama（/api/chat，关闭流式），返回原始 model 输出文本。"""
    url = f"{settings.OLLAMA_BASE_URL}/api/chat"
    payload = {
        "model": model,
        "stream": False,
        "options": {"temperature": 0.7},
        "messages": _messages(question),
    }
    return _post_with_retry(url, payload, headers=None, provider="ollama")


def _post_with_retry(url: str, payload: dict, headers: dict | None, provider: str) -> str:
    retries = settings.LLM_MAX_RETRIES
    last = None
    for attempt in range(retries + 1):
        try:
            resp = httpx.post(url, json=payload, headers=headers, timeout=settings.LLM_TIMEOUT)
        except (httpx.TimeoutException, httpx.ConnectError, httpx.TransportError) as e:  # noqa: PERF401
            if attempt < retries:
                time.sleep(1.0 + attempt)
                continue
            raise LLMError("timeout" if isinstance(e, httpx.TimeoutException) else "unreachable",
                           f"{provider} 网络错误: {type(e).__name__}") from e
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError:
            code = resp.status_code
            if code == 401 or code == 403:
                raise LLMError("auth", f"{provider} 密钥无效或无权访问 (HTTP {code})")
            if code == 429:
                raise LLMError("rate_limited", f"{provider} 请求过于频繁 (HTTP 429)")
            if code in (400, 404, 422):
                raise LLMError("http", f"{provider} 请求无效 (HTTP {code})")
            if attempt < retries:
                time.sleep(1.0 + attempt)
                continue
            raise LLMError("http", f"{provider} 服务异常 (HTTP {code})") from resp
        if provider == "ollama":
            try:
                return resp.json()["message"]["content"]
            except (KeyError, ValueError) as e:
                raise LLMError("parse", f"ollama 响应缺少 message.content") from e
        return resp.json()["choices"][0]["message"]["content"]
    raise last  # pragma: no cover


def ollama_models(timeout: float = 2.0):
    """列出本机 Ollama 已安装的模型名；未运行/不可达返回 []。"""
    try:
        resp = httpx.get(f"{settings.OLLAMA_BASE_URL}/api/tags", timeout=timeout)
        resp.raise_for_status()
        return [m.get("name", "") for m in resp.json().get("models", []) if m.get("name")]
    except Exception:
        return []


def search_llm(question: str, api_key: str = "", provider: str = "", model: str = ""):
    """按 provider 调用大模型生成多领域方案 JSON 文本。

    - DeepSeek：可传调用方 api_key，留空回退服务端 DEEPSEEK_API_KEY；
    - Ollama：本机本地部署（无需 key，model 为已安装模型名，如 qwen2.5:7b）。

    key 仅用于本次请求，不打日志、不入库。调用失败返回 (None, 错误信息)。
    成功返回 (content_text, None)。
    """
    provider = (provider or "deepseek").lower()
    cache_key = (provider, model, question)
    if cache_key in _cache:
        return _cache[cache_key], None
    try:
        if provider == "ollama":
            model = (model or "").strip()
            if not model:
                return None, "未设置 Ollama 模型：请在「AI 模型」面板选择或输入模型名"
            content = _call_ollama(question, model)
        else:
            api_key = (api_key or settings.DEEPSEEK_API_KEY or "").strip()
            if not api_key:
                return None, "未配置 DeepSeek API Key：请在「AI 模型」面板填入你自己的 Key"
            content = _call_deepseek(question, api_key, model)
    except LLMError as e:
        return None, e.message
    except Exception as e:  # noqa: BLE001
        return None, f"{provider} 调用失败: {type(e).__name__}"
    _cache[cache_key] = content
    if len(_cache) > _CACHE_MAX:  # 防止缓存无限增长，超出阈值整体丢弃重来
        _cache.clear()
    return content, None