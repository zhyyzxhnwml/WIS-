import json

from . import alias, graph_engine, llm_engine

COLOR_BY_DOMAIN = {
    "生物": "#34d399",
    "机械": "#f59e0b",
    "物理": "#22d3ee",
    "材料": "#ec4899",
    "化工": "#f97316",
    "算法": "#a78bfa",
    "电子信息": "#818cf8",
    "航空": "#38bdf8",
    "能源": "#a3e635",
}
_DEFAULT_COLOR = "#94a3b8"


def _color(domain: str) -> str:
    return COLOR_BY_DOMAIN.get(domain, _DEFAULT_COLOR)


# 各领域在矛盾推演中的典型代价项（用于技术矛盾叙述）
_DOMAIN_COST = {
    "材料": "材料重量与制造成本",
    "机械": "机构复杂度与维护成本",
    "物理": "系统能量损耗与体积占用",
    "生物": "工艺可实现性与量产成本",
    "化工": "原料成本与反应可控性",
    "算法": "计算开销与实现复杂度",
    "电子信息": "功耗与信号处理开销",
    "航空": "结构重量与载荷余量",
    "能源": "能量转换效率与系统体积",
    "建筑": "施工成本与结构冗余",
}


def _first_sentence(text, fallback):
    s = (text or "").strip()
    if not s:
        return fallback
    return s.split("。")[0] + "。"


def _lane_reasoning(question, fn, fdesc, scene, lane):
    """为单个 lane 生成从头推到底的完整文字推理链。

    每个方案都从问题出发，经功能抽象、矛盾识别、TRIZ 原理推演、概念中介、
    源域类比、跨域映射到最终方案与收益，形成可展开的分步叙述。
    """
    fn = (fn or "").strip() or "解决目标问题"
    fdesc = (fdesc or "").strip() or f"需要借助跨域机制实现「{fn}」。"
    domain = lane.get("domain") or ""
    cost = _DOMAIN_COST.get(domain, "系统复杂度与成本")
    triz_no = (lane.get("trizNo") or "").strip()
    triz = (lane.get("triz") or "").strip()
    triz_name = f"发明原理{triz_no}「{triz}」" if triz_no else f"发明原理「{triz}」"
    principle = _first_sentence(lane.get("principleDesc"), "以标准 TRIZ 启示跨越矛盾。")
    concept = (lane.get("concept") or "").strip()
    concept_desc = _first_sentence(lane.get("conceptDesc"), "将该抽象隐喻落到可实现的中介机制。")
    instance = (lane.get("instance") or "").strip()
    instance_desc = _first_sentence(lane.get("instanceDesc"), "该实例提供了可资借鉴的成熟工程解法。")
    scheme_title = (lane.get("schemeTitle") or "").strip() or f"基于「{concept}」的{domain}方案"
    explanation = (lane.get("explanation") or "").strip() or f"将实例「{instance}」的机制映射到目标问题，形成{scheme_title}。"
    gains = lane.get("gains") or []
    gains_txt = "；".join(str(g) for g in gains[:3]) if isinstance(gains, list) else str(gains or "")

    return [
        {"step": "问题定位", "text": f"问题「{question}」：{scene or '需要跨领域寻求创新解法。'}"},
        {"step": "功能抽象", "text": f"将问题抽象为底层功能「{fn}」——{fdesc}"},
        {"step": "矛盾识别", "text": f"技术矛盾：若沿用常规手段去强化「{fn}」，必然以{cost}的上升为代价；" f"物理矛盾：理想解要求关键部件兼具对立属性，既要借助「{concept}」这类机制的独特优势，又不能在{domain}场景中增加{cost}。矛盾无法简单折中，必须转移求解。", "tag": "矛盾"},
        {"step": "原理推演", "text": f"针对该矛盾调用 {triz_name}：{principle}从原理层面绕开矛盾点。"},
        {"step": "概念中介", "text": f"将原理具体化为通用工程隐喻「{concept}」——{concept_desc}"},
        {"step": "源域类比", "text": f"在{domain}领域找到实现该隐喻的成熟参照「{instance}」：{instance_desc}"},
        {"step": "跨域映射", "text": f"沿「{concept}→{instance}」完成柔性映射并落到目标问题：{explanation}"},
        {"step": "方案定型", "text": f"形成融合方案「{scheme_title}」，预计增益：{gains_txt or '待工程实测验证。'}"},
    ]


def _norm_domain(domain: str) -> str:
    """把 LLM 返回的领域名规范化为前端短名（如 材料→材料、机械→机械）。

    优先反查 CITY_TO_FRONTEND：先按短名匹配（材料→材料科学领域），
    再按前缀匹配（材料→材料科学领域），最后原样返回 short_domain 结果。
    """
    d = str(domain or "").strip()
    if not d:
        return ""
    short = graph_engine.short_domain(d)
    if short != d:
        return short
    for key, val in graph_engine.CITY_TO_FRONTEND.items():
        if key == d or key.startswith(d):
            return val
    for val in graph_engine.CITY_TO_FRONTEND.values():
        if val == d:
            return val
    return d


def _make_lane(src, idx: int, question: str):
    domain = graph_engine.short_domain(src.get("dn") or "")
    triz_no = str(src.get("tno") or "")
    triz = str(src.get("tn") or "")
    triz_desc = str(src.get("tdesc") or "")
    concept = src.get("cn") or ""
    concept_desc = str(src.get("cdesc") or "")
    instance = src.get("en") or ""
    instance_desc = str(src.get("edesc") or "")
    src_name = str(src.get("esrc") or "")
    fn = str(src.get("fn") or "")
    weight = round(0.78 + 0.04 * ((idx + len(instance)) % 5), 2)
    scheme = str(src.get("sn") or "")
    scheme_desc = str(src.get("sdesc") or "")
    scheme_title = scheme if scheme else f"{concept}→{instance} 工程化方案"
    score = min(96, 82 + (len(instance) % 12))
    principle_desc = triz_desc

    annotation = {
        "triz": f"TRIZ原理{triz_no}「{triz}」：{triz_desc}。" if triz else "",
        "functionAbstraction": (
            f"将问题抽象为底层功能「{fn}」，进而在概念「{concept}」层寻找可实现该功能的中介机制。"
            if fn
            else f"将问题抽象为需要实现的底层功能，经概念「{concept}」到达实例「{instance}」实现。"
        ),
        "crossDomainAnalogy": (
            f"跨域知识重定向：{domain}领域概念「{concept}」→ 实例「{instance}」（{src_name or '图谱实例'}），"
            f"源自「{src_name}」的灵感映射到目标问题。"
        ),
        "knowledgeGraph": (
            f"图谱证据链：{question} 具备功能{fn or '目标功能'} → TRIZ原理「{triz}」 → "
            f"概念「{concept}」 → 实例「{instance}」 → 方案（可沿图谱溯源）。"
        ),
    }

    return {
        "key": f"l{idx}",
        "domain": domain,
        "color": _color(domain),
        "laneY": [28, 43, 57, 72],
        "triz": triz,
        "trizNo": triz_no,
        "principleDesc": principle_desc,
        "concept": concept,
        "conceptDesc": concept_desc,
        "instance": instance,
        "instanceDesc": instance_desc,
        "weight": weight,
        "schemeTitle": scheme_title,
        "schemeScore": score,
        "explanation": f"{fn}：由「{concept}」经实例「{instance}」实现（{src_name or domain}）。",
        "gains": ([f"来源:{src_name}"] if src_name else []) + [f"{triz}原理映射"],
        "annotation": annotation,
        "reasoning": _lane_reasoning(
            question,
            src.get("fn") or "",
            src.get("fdesc") or "",
            "",
            {
                "domain": domain,
                "trizNo": triz_no,
                "triz": triz,
                "principleDesc": triz_desc,
                "concept": concept,
                "conceptDesc": concept_desc,
                "instance": instance,
                "instanceDesc": instance_desc,
                "schemeTitle": scheme_title,
                "explanation": f"{fn}：由「{concept}」经实例「{instance}」实现（{src_name or domain}）。",
                "gains": ([f"来源:{src_name}"] if src_name else []) + [f"{triz}原理映射"],
            },
        ),
    }


def _meta_base(question: str, id_: str, source: str, scene: str = ""):
    return {
        "id": id_,
        "question": question,
        "scene": scene,
        "coreFunction": "",
        "functionDesc": "",
        "schemeDesc": "",
        "fromGraph": source == "知识图谱",
        "source": source,
        "lanes": [],
        "heatmap": {"domains": [], "matrix": []},
    }


def from_graph(question: str, pname: str, chains: list, heatmap: dict) -> dict:
    meta = _meta_base(question, f"g_{pname or question}", "知识图谱")
    fn = next((c.get("fn") for c in chains if c.get("fn")), "")
    fdesc = next((c.get("fdesc") for c in chains if c.get("fdesc")), "")
    meta["coreFunction"] = fn or "解决目标问题"
    meta["functionDesc"] = fdesc or "由知识图谱链提取底层功能。"
    meta["schemeDesc"] = f"依据图谱中「{pname or question}」的多条跨域证据链，汇聚为融合创新方案。"
    seen_domains = set()
    for i, c in enumerate(chains):
        d = graph_engine.short_domain(c.get("dn") or "")
        if not d or d in seen_domains:
            continue
        seen_domains.add(d)
        meta["lanes"].append(_make_lane(c, i, question))
        if len(meta["lanes"]) >= 4:
            break
    if not meta["lanes"]:
        for i, c in enumerate(chains[:4]):
            meta["lanes"].append(_make_lane(c, i, question))
    meta["heatmap"] = heatmap or {"domains": [], "matrix": []}
    return meta


def from_llm(question: str, raw: str, heatmap: dict | None = None) -> dict:
    try:
        data = json.loads(raw)
    except Exception:
        return fallback(question)
    lanes_in = data.get("lanes") or []
    if not lanes_in:
        return fallback(question)
    meta = _meta_base(question, f"llm_{question[:10]}", "LLM")
    meta.update({
        "coreFunction": data.get("coreFunction") or "",
        "functionDesc": data.get("functionDesc") or "",
        "schemeDesc": data.get("schemeDesc") or "",
    })
    scores = [70, 76, 81, 85]
    for i, l in enumerate(lanes_in[:4]):
        domain = l.get("domain") or f"领域{i + 1}"
        kn = _norm_domain(domain)
        ann = (l.get("annotation") or {} if isinstance(l.get("annotation"), dict) else {})
        raw_gains = l.get("gains") or []
        if isinstance(raw_gains, str):
            raw_gains = [raw_gains]
        raw_score = l.get("score")
        try:
            score = int(raw_score) if raw_score is not None else scores[i]
        except (TypeError, ValueError):
            score = scores[i]
        try:
            weight = float(l.get("weight") or 0.8)
        except (TypeError, ValueError):
            weight = 0.8
        meta["lanes"].append({
            "key": f"l{i}",
            "domain": kn or domain,
            "color": _color(kn or domain),
            "laneY": [28, 43, 57, 72],
            "triz": l.get("triz") or "",
            "trizNo": str(l.get("trizNo") or ""),
            "principleDesc": l.get("trizDesc") or "",
            "concept": l.get("concept") or "",
            "conceptDesc": l.get("conceptDesc") or "",
            "instance": l.get("instance") or "",
            "instanceDesc": l.get("instanceDesc") or "",
            "weight": weight,
            "schemeTitle": l.get("schemeTitle") or f"{l.get('concept') or '跨域'}方案",
            "schemeScore": score,
            "explanation": l.get("explanation") or "",
            "gains": (raw_gains if isinstance(raw_gains, list) else [])[:3],
            "annotation": {
                "triz": ann.get("triz") or "",
                "functionAbstraction": ann.get("functionAbstraction") or "",
                "crossDomainAnalogy": ann.get("crossDomainAnalogy") or "",
                "knowledgeGraph": ann.get("knowledgeGraph") or "",
            },
            "reasoning": _lane_reasoning(
                question,
                meta["coreFunction"],
                meta["functionDesc"],
                meta["scene"],
                {
                    "domain": kn or domain,
                    "trizNo": str(l.get("trizNo") or ""),
                    "triz": l.get("triz") or "",
                    "principleDesc": l.get("trizDesc") or "",
                    "concept": l.get("concept") or "",
                    "conceptDesc": l.get("conceptDesc") or "",
                    "instance": l.get("instance") or "",
                    "instanceDesc": l.get("instanceDesc") or "",
                    "schemeTitle": l.get("schemeTitle") or f"{l.get('concept') or '跨域'}方案",
                    "explanation": l.get("explanation") or "",
                    "gains": (raw_gains if isinstance(raw_gains, list) else [])[:3],
                },
            ),
        })
    meta["heatmap"] = heatmap or {"domains": [x["domain"] for x in meta["lanes"]], "matrix": _default_matrix(len(meta["lanes"]))}
    return meta


def _default_matrix(n):
    return [[100 if i == j else 0 for j in range(n)] for i in range(n)]


def fallback(question: str, heatmap: dict | None = None) -> dict:
    import hashlib

    seed = int(hashlib.md5(question.encode()).hexdigest()[:6], 16) % 100
    return from_llm(question, _FALLBACK_RAW.replace("__SEED__", str(seed)), heatmap)


_FALLBACK_RAW = json.dumps({
    "coreFunction": "解决目标问题",
    "functionDesc": "将问题抽象为可跨域迁移的底层功能，通过知识重定向从多个领域借用解决方案。",
    "schemeDesc": "结合TRIZ与跨域类比，从材料、机械、物理、生物四个领域汇聚融合方案。",
    "scene": "未在图谱直接命中，采用通用跨域知识重定向方法给出建议。",
    "lanes": [
        {
            "domain": "材料", "triz": "复合材料", "trizNo": "40",
            "trizDesc": "以复合材料替代单一材料，兼顾多性能需求。",
            "concept": "多孔填充", "conceptDesc": "多孔结构高比强度且兼具缓冲与保温性能。",
            "instance": "蜂巢芯层", "instanceDesc": "蜂巢六边形胞元高强度低密度，广泛用于夹芯结构。",
            "weight": 0.85, "score": 88, "schemeTitle": "多孔复合夹芯结构",
            "gains": ["轻量化", "高比强度"],
            "annotation": {
                "triz": "应用TRIZ原理40（复合材料），以复合方式获取整体最优性能。",
                "functionAbstraction": "抽象为『高强度低成本的结构功能』，选择多孔复合思路。",
                "crossDomainAnalogy": "将蜂巢胞元结构映射到目标问题的承载/缓冲需求。",
                "knowledgeGraph": "此问题暂未在图谱中出现，建议后续补充建链后可沿图谱溯源。",
            },
        },
        {
            "domain": "机械", "triz": "预应作用", "trizNo": "9",
            "trizDesc": "预先施加反作用力或缓冲结构以应对冲击。",
            "concept": "预紧/溃缩", "conceptDesc": "预先设计变形吸能通道。",
            "instance": "溃缩吸能桶", "instanceDesc": "金属薄壁结构受压时逐级折叠吸收冲击能。",
            "weight": 0.8, "score": 82, "schemeTitle": "分级溃缩吸能结构",
            "gains": ["逐级吸能", "成本可控"],
            "annotation": {
                "triz": "应用TRIZ原理9（预先反作用），预设吸能路径。",
                "functionAbstraction": "抽象为『可控的冲击动能耗散』。",
                "crossDomainAnalogy": "汽车安全溃缩区映射到目标结构的耐撞需求。",
                "knowledgeGraph": "推荐机械领域『溃缩吸能』类节点扩展查询。",
            },
        },
        {
            "domain": "物理", "triz": "柔性壳体", "trizNo": "30",
            "trizDesc": "以柔性外包裹分散局部应力。",
            "concept": "柔性包裹", "conceptDesc": "柔性层可变形分散外界载荷。",
            "instance": "发泡缓冲层", "instanceDesc": "聚氨酯发泡层受压大变形吸收动能。",
            "weight": 0.78, "score": 79, "schemeTitle": "柔性发泡缓冲外衣",
            "gains": ["工艺简单", "成本低"],
            "annotation": {
                "triz": "应用TRIZ原理30（柔性壳体），以柔性层分散冲击。",
                "functionAbstraction": "抽象为『形变耗能』功能。",
                "crossDomainAnalogy": "包装发泡材料映射到户外装备耐撞需求。",
                "knowledgeGraph": "可沿物理领域概念节点「柔性结构」扩展。",
            },
        },
        {
            "domain": "生物", "triz": "仿生层压", "trizNo": "",
            "trizDesc": "借鉴自然界分层增韧结构。",
            "concept": "甲壳层状结构", "conceptDesc": "自然界常见层状+纤维复合增韧策略。",
            "instance": "珍珠母贝层", "instanceDesc": "珍珠母层状叠砌，兼具高硬与高韧。",
            "weight": 0.75, "score": 76, "schemeTitle": "仿珍珠母层状结构",
            "gains": ["高韧性", "仿生灵感"],
            "annotation": {
                "triz": "借鉴自然界层压增韧（非标准TRIZ编号）。",
                "functionAbstraction": "抽象为『既硬且韧』的力学功能。",
                "crossDomainAnalogy": "将贝壳层状结构映射为增韧策略。",
                "knowledgeGraph": "生物领域实例节点「珍珠母贝」可提供参考。",
            },
        },
    ],
})


def build_example(question: str, api_key: str = "", provider: str = "", model: str = "") -> dict:
    q = alias.normalize(question)
    pname = alias.resolve_problem_name(q)
    heatmap = {"domains": [], "matrix": []}
    chains = []
    try:
        heatmap = graph_engine.build_heatmap()
        if pname:
            chains = graph_engine.chain_from_problem(pname)
        if not chains:
            vocab = graph_engine.load_graph_vocab()
            kws = graph_engine.extract_keywords(q, vocab)
            chains = graph_engine.search_chains(kws)
    except Exception:
        heatmap = {"domains": [], "matrix": []}
        chains = []
    if chains:
        return from_graph(q, pname, chains, heatmap)
    raw, lerr = llm_engine.search_llm(q, api_key=api_key, provider=provider, model=model)
    if not lerr and raw:
        return from_llm(q, raw, heatmap)
    result = fallback(q, heatmap)
    if lerr:
        result["llmError"] = lerr
    return result