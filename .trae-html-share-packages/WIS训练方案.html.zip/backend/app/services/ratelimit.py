"""进程内滑动窗口限流器（无外部依赖；多进程部署时需换 Redis 等共享存储）。"""
import threading
import time


class SlidingWindowLimiter:
    def __init__(self, limit: int, window: float):
        self.limit = limit
        self.window = window
        self._hits: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def allow(self, key: str) -> bool:
        """记录一次访问并判定是否放行。"""
        now = time.monotonic()
        with self._lock:
            q = [t for t in self._hits.get(key, []) if now - t < self.window]
            if len(q) >= self.limit:
                self._hits[key] = q
                return False
            q.append(now)
            self._hits[key] = q
        return True