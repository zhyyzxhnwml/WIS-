from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

# Pydantic 请求/响应模型：负责入参校验与出参序列化，非法输入在进入路由前即被拦截。


class UserRegister(BaseModel):
    username: str = Field(min_length=2, max_length=50)
    password: str = Field(min_length=6, max_length=64)  # 至少 6 位
    nickname: str = Field(default="", max_length=50)


class UserLogin(BaseModel):
    username: str = Field(min_length=1, max_length=50)
    password: str = Field(min_length=1, max_length=64)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    nickname: str
    created_at: datetime


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut