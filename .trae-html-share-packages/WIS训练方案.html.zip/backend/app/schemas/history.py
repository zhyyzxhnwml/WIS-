from datetime import datetime

from pydantic import BaseModel, ConfigDict


class HistoryOut(BaseModel):
    """历史记录列表条目（不含完整结果 JSON，列表页只展示概览；详情另走 /api/history/{id}）。"""

    model_config = ConfigDict(from_attributes=True)  # 允许直接由 SQLAlchemy 对象构造

    id: int
    question: str
    created_at: datetime