from pydantic import BaseModel, ConfigDict, Field


class AnnotationOut(BaseModel):
    triz: str = ""
    functionAbstraction: str = ""
    crossDomainAnalogy: str = ""
    knowledgeGraph: str = ""


class LaneMeta(BaseModel):
    key: str
    domain: str = ""
    color: str = "#94a3b8"
    laneY: list[int] = [28, 43, 57, 72]
    triz: str = ""
    trizNo: str = ""
    principleDesc: str = ""
    concept: str = ""
    conceptDesc: str = ""
    instance: str = ""
    instanceDesc: str = ""
    weight: float = 0.8
    schemeTitle: str = ""
    schemeScore: int = 0
    explanation: str = ""
    gains: list[str] = []
    annotation: AnnotationOut = AnnotationOut()


class HeatmapOut(BaseModel):
    domains: list[str] = []
    matrix: list[list[int]] = []


class ExampleMetaOut(BaseModel):
    # 允许前端额外字段透传（如下方 llmError），避免大模型兜底信息被过滤
    model_config = ConfigDict(extra="allow")

    id: str
    question: str
    scene: str = ""
    coreFunction: str = ""
    functionDesc: str = ""
    schemeDesc: str = ""
    fromGraph: bool = False
    source: str = ""
    lanes: list[LaneMeta] = []
    heatmap: HeatmapOut = HeatmapOut()
    llmError: str = ""


class SearchRequest(BaseModel):
    question: str = Field(min_length=1, max_length=255)
    api_key: str = Field(default="", max_length=255)
    provider: str = Field(default="", max_length=32)
    model: str = Field(default="", max_length=128)


class SampleQuestionOut(BaseModel):
    question: str
    desc: str = ""
    tags: list[str] = []
    source: str = ""


class StatsOut(BaseModel):
    nodes: int = 0
    relations: int = 0
    domains: int = 0
    triz: int = 0