import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent.parent
load_dotenv(BASE_DIR / ".env")


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return default


class Settings:
    MYSQL_HOST = os.getenv("MYSQL_HOST", "127.0.0.1")
    MYSQL_PORT = _int("MYSQL_PORT", 3306)
    MYSQL_USER = os.getenv("MYSQL_USER", "root")
    MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")
    MYSQL_DB = os.getenv("MYSQL_DB", "innomap")

    NEO4J_URI = os.getenv("NEO4J_URI", "bolt://localhost:7687")
    NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
    NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "")

    DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "").strip()
    DEEPSEEK_BASE_URL = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com").rstrip("/")
    DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")

    OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/")

    LLM_TIMEOUT = _int("LLM_TIMEOUT", 120)              # 单次大模型调用超时（秒）
    LLM_MAX_RETRIES = _int("LLM_MAX_RETRIES", 2)        # 网络/5xx 重试次数（4xx 不重试）

    RATE_LIMIT_SEARCH = _int("RATE_LIMIT_SEARCH", 12)   # /api/search 每窗口每用户/IP 次数
    RATE_LIMIT_WINDOW = _int("RATE_LIMIT_WINDOW", 60)   # 限流窗口（秒）

    JWT_SECRET = os.getenv("JWT_SECRET", "innomap-dev-secret-change-me-0123456789")
    JWT_ALGORITHM = "HS256"
    JWT_EXPIRE_MINUTES = _int("JWT_EXPIRE_MINUTES", 10080)

    CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",") if o.strip()]


settings = Settings()