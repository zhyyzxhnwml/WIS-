import httpx
import pytest

from app.services.llm_engine import LLMError, search_llm
from app.services.ratelimit import SlidingWindowLimiter


class _Resp(httpx.Response):
    def raise_for_status(self):
        if self.status_code >= 400:
            raise httpx.HTTPStatusError(
                f"HTTP {self.status_code}", request=httpx.Request("POST", "http://x"), response=self
            )


def _ok_body():
    return httpx.Response(
        200,
        json={"choices": [{"message": {"content": '{"lanes": []}'}}]},
        request=httpx.Request("POST", "http://x"),
    )


def test_sliding_window_limiter():
    limiter = SlidingWindowLimiter(limit=3, window=60)
    assert limiter.allow("a") is True
    assert limiter.allow("a") is True
    assert limiter.allow("a") is True
    assert limiter.allow("a") is False          # 第 4 次被限
    assert limiter.allow("b") is True           # 其它 key 不受影响


def test_limiter_expires_after_window(monkeypatch):
    import time

    real_time = time.monotonic
    clock = {"now": 0.0}
    monkeypatch.setattr("app.services.ratelimit.time.monotonic", lambda: clock["now"])
    limiter = SlidingWindowLimiter(limit=2, window=10)
    assert limiter.allow("k")
    assert limiter.allow("k")
    assert limiter.allow("k") is False
    clock["now"] = 11.0                          # 窗口滑过（上次命中已过期）
    assert limiter.allow("k") is True


class _FakePost:
    def __init__(self, responses):
        self.responses = responses
        self.calls = {"n": 0}

    def __call__(self, url, json=None, headers=None, timeout=None):
        idx = min(self.calls["n"], len(self.responses) - 1)
        self.calls["n"] += 1
        return self.responses[idx]


def _post_fake_sequence(responses):
    return _FakePost(responses)


def test_deepseek_auth_error_not_retried(monkeypatch):
    resp = _Resp(401, request=httpx.Request("POST", "http://x"))
    fake = _post_fake_sequence([resp])
    monkeypatch.setattr("app.services.llm_engine.httpx.post", fake)
    content, err = search_llm("auth专用问题", api_key="sk-bad", provider="deepseek")
    assert content is None
    assert "密钥无效" in err
    assert fake.calls["n"] == 1  # 4xx 只调一次，不重试


def test_deepseek_retries_on_5xx(monkeypatch):
    ok = _ok_body()
    first = _Resp(500, request=httpx.Request("POST", "http://x"))
    fake = _post_fake_sequence([first, ok])
    monkeypatch.setattr("app.services.llm_engine.httpx.post", fake)
    content, err = search_llm("重试专用问题", api_key="sk-ok", provider="deepseek")
    assert err is None
    assert '"lanes"' in content
    assert fake.calls["n"] == 2


def test_no_key_returns_error_tuple():
    content, err = search_llm("无key专用问题", api_key="", provider="deepseek")
    assert content is None
    assert "未配置 DeepSeek API Key" in err


def test_ollama_no_model_returns_error_tuple():
    content, err = search_llm("无模型专用问题", provider="ollama", model="")
    assert content is None
    assert "Ollama" in err