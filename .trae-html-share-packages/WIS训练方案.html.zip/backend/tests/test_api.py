import uuid

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def _unique_user():
    suffix = uuid.uuid4().hex[:8]
    return f"tester_{suffix}", "pass1234"


def test_health():
    resp = client.get("/api/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_samples():
    resp = client.get("/api/samples")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) >= 5
    assert any(s["source"] == "graph" for s in data)


def test_stats():
    resp = client.get("/api/stats")
    assert resp.status_code == 200
    data = resp.json()
    assert data["nodes"] > 0
    assert data["relations"] > 0


def test_search_drone_uses_graph():
    resp = client.post("/api/search", json={"question": "如何让无人机更抗冲击？"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["source"] == "知识图谱"
    assert len(data["lanes"]) >= 1
    lane = data["lanes"][0]
    assert lane["key"]
    assert "laneY" in lane
    ann = lane["annotation"]
    assert ann["triz"] and ann["functionAbstraction"] and ann["crossDomainAnalogy"] and ann["knowledgeGraph"]
    assert isinstance(lane["gains"], list)
    assert data["heatmap"]["domains"]


def test_search_aliased_problem():
    resp = client.post("/api/search", json={"question": "如何让锂电池散热更好？"})
    assert resp.status_code == 200
    assert resp.json()["source"] == "知识图谱"


def test_auth_flow():
    username, password = _unique_user()
    reg = client.post("/api/auth/register", json={"username": username, "password": password})
    assert reg.status_code == 201
    token = reg.json()["access_token"]

    dup = client.post("/api/auth/register", json={"username": username, "password": password})
    assert dup.status_code == 400

    login = client.post("/api/auth/login", json={"username": username, "password": password})
    assert login.status_code == 200

    bad = client.post("/api/auth/login", json={"username": username, "password": "wrong-pass"})
    assert bad.status_code == 401

    headers = {"Authorization": f"Bearer {token}"}
    me = client.get("/api/auth/me", headers=headers)
    assert me.status_code == 200
    assert me.json()["username"] == username

    no_token = client.get("/api/auth/me")
    assert no_token.status_code == 401


def test_search_persists_history():
    username, password = _unique_user()
    reg = client.post("/api/auth/register", json={"username": username, "password": password})
    token = reg.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    resp = client.post("/api/search", json={"question": "无人机怎么防炸机？"}, headers=headers)
    assert resp.status_code == 200

    hist = client.get("/api/history", headers=headers)
    assert hist.status_code == 200
    items = hist.json()
    assert len(items) >= 1

    detail = client.get(f"/api/history/{items[0]['id']}", headers=headers)
    assert detail.status_code == 200
    assert detail.json()["question"]

    forbidden = client.get(f"/api/history/{items[0]['id']}")
    assert forbidden.status_code == 401


def test_search_new_extended_problem():
    for q in [
        "如何让电动车在碰撞中更安全？",
        "如何让手机在跌落时更耐摔？",
        "跑步膝盖冲击大怎么办",
    ]:
        resp = client.post("/api/search", json={"question": q})
        assert resp.status_code == 200
        data = resp.json()
        assert data["source"] == "知识图谱"
        assert len(data["lanes"]) >= 1


def test_graph_summary():
    resp = client.get("/api/graph/summary")
    assert resp.status_code == 200
    data = resp.json()
    assert data["nodes"] > 100
    assert data["relations"] > 100
    assert data["problems"] >= 19
    assert len(data["domains"]) >= 5
    assert all("name" in d and "instances" in d for d in data["domains"])


def test_graph_network():
    resp = client.get("/api/graph/network", params={"labels": "概念,实例,领域", "limit": 100})
    assert resp.status_code == 200
    data = resp.json()
    assert len(data["nodes"]) > 0
    assert len(data["links"]) > 0
    assert all(n["id"] and n["name"] and n["label"] for n in data["nodes"])

    resp2 = client.get("/api/graph/network", params={"domain": "生物", "limit": 150})
    assert resp2.status_code == 200
    assert len(resp2.json()["nodes"]) > 0

    resp3 = client.get("/api/graph/network", params={"q": "蜂巢", "limit": 150})
    assert resp3.status_code == 200


def test_graph_node_detail():
    resp = client.get("/api/graph/node", params={"name": "人体软骨减震结构"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["node"] is not None
    assert data["node"]["label"] == "实例"
    assert len(data["relations"]) >= 1
    assert all(r["type"] and r["to"]["name"] for r in data["relations"])

    miss = client.get("/api/graph/node", params={"name": "不存在的节点xyz"})
    assert miss.status_code == 200
    assert miss.json()["node"] is None