<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { api } from './utils/api.js'
import ApiKeyModal from './components/ApiKeyModal.vue'

const route = useRoute()
const router = useRouter()

// 当前登录用户（来自本地存储）
const user = ref(api.getUser())
const apiKeyRef = ref(null) // 引用弹出「AI 模型设置」弹窗的子组件
const aiConfigured = ref(false) // 是否已配置可用的 AI 模型

onMounted(() => {
  // 监听登录状态变化事件（登录/退出登录后由 LoginView / HistoryView 派发），刷新导航栏用户信息
  window.addEventListener('innomap:login', () => {
    user.value = api.getUser()
  })
  syncAiIndicator()
})

// 是否已登录
const loggedIn = computed(() => Boolean(user.value))

// 点击品牌 Logo 返回首页
function goHome() {
  router.push({ name: 'home' })
}

// 打开 AI 模型设置弹窗
function openApiKey() {
  apiKeyRef.value?.open()
}

// 同步「已配置 AI」指示点：Ollama 看模型名，DeepSeek 看 Key
function syncAiIndicator() {
  if (api.getLLMProvider() === 'ollama') {
    aiConfigured.value = Boolean(api.getLLMModel())
  } else {
    aiConfigured.value = Boolean(api.getDeepSeekKey())
  }
}

// 配置保存后刷新指示状态
function onKeySaved() {
  syncAiIndicator()
}
</script>

<template>
  <div class="app-shell">
    <header class="navbar">
      <div class="container navbar-inner">
        <div class="brand" @click="goHome">
          <img src="/logo.png" alt="InnoMap" class="brand-logo" />
          <div class="brand-text">
            <span class="brand-name gradient-text">InnoMap</span>
            <span class="brand-sub">跨领域创新辅助平台</span>
          </div>
        </div>
        <nav class="navbar-links">
          <router-link v-if="route.name !== 'home'" to="/" class="nav-link">返回首页</router-link>
          <router-link to="/graph" class="nav-link" :class="{ active: route.name === 'graph' }">图谱浏览</router-link>
          <button class="nav-link key-btn" @click="openApiKey" type="button">
            AI 模型<span v-if="aiConfigured" class="key-dot"></span>
          </button>
          <a v-if="route.name === 'home'" href="#how" class="nav-link">工作原理</a>
          <a v-if="route.name === 'home'" href="#features" class="nav-link">核心能力</a>
          <router-link v-if="loggedIn" to="/history" class="nav-link">我的历史</router-link>
          <router-link v-if="!loggedIn" to="/login" class="nav-link login-link">登录 / 注册</router-link>
          <div v-else class="nav-user">
            <span class="nav-avatar">{{ (user.nickname || user.username || '?').slice(0, 1) }}</span>
            <span class="nav-name">{{ user.nickname || user.username }}</span>
          </div>
        </nav>
      </div>
    </header>

    <main class="app-main">
      <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </main>

    <footer class="app-footer">
      <div class="container footer-inner">
        <div class="footer-brand">
          <span class="gradient-text">InnoMap</span>
          <p>基于知识重定向的跨领域创新辅助平台</p>
        </div>
        <div class="footer-meta">
          <span>闽江大学 · 计算机与大数据学院</span>
          <span>2026 大学生创新创业训练计划 · 创新训练项目</span>
        </div>
      </div>
    </footer>

    <ApiKeyModal ref="apiKeyRef" @save="onKeySaved" />
  </div>
</template>

<style scoped>
.app-shell {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.navbar {
  position: sticky;
  top: 0;
  z-index: 50;
  background: rgba(9, 12, 27, 0.78);
  backdrop-filter: blur(14px);
  border-bottom: 1px solid rgba(139, 165, 255, 0.1);
}

.navbar-inner {
  display: flex;
  align-items: center;
  gap: 14px;
  height: 64px;
  cursor: pointer;
}

.brand-logo {
  width: 38px;
  height: 38px;
  object-fit: contain;
  border-radius: 8px;
}

.brand-text {
  display: flex;
  flex-direction: column;
  line-height: 1.25;
}

.brand-name {
  font-size: 19px;
  font-weight: 800;
  letter-spacing: 1px;
}

.brand-sub {
  font-size: 11px;
  color: var(--text-3);
  letter-spacing: 2px;
}

.navbar-links {
  margin-left: auto;
  display: flex;
  align-items: center; /* 垂直居中，避免 <button> 与 <a>/<router-link> 基线不一致导致 AI 模型略低 */
  gap: 22px;
}

.nav-link {
  font-size: 14px;
  color: var(--text-2);
  transition: color 0.2s ease;
}
.nav-link:hover {
  color: var(--cyan);
}
.nav-link.active {
  color: var(--cyan);
  font-weight: 700;
}
.key-btn {
  border: none;
  background: transparent;
  cursor: pointer;
  font-size: 14px;
  color: var(--text-2);
  transition: color 0.2s ease;
  padding: 0;
  /* 用 flex 布局居中文字与状态圆点，和其它导航项垂直对齐一致 */
  display: inline-flex;
  align-items: center;
}
.key-btn:hover {
  color: var(--cyan);
}
.key-dot {
  display: inline-block;
  width: 7px;
  height: 7px;
  margin-left: 5px;
  border-radius: 50%;
  background: var(--cyan);
  box-shadow: 0 0 8px rgba(34, 211, 238, 0.7);
}
.login-link {
  padding: 6px 16px;
  border: 1px solid rgba(34, 211, 238, 0.4);
  border-radius: 999px;
  color: var(--cyan);
  font-weight: 700;
  font-size: 13px;
}
.login-link:hover {
  background: rgba(34, 211, 238, 0.1);
}
.nav-user {
  display: flex;
  align-items: center;
  gap: 8px;
}
.nav-avatar {
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  font-size: 13px;
  font-weight: 800;
  color: #fff;
  background: linear-gradient(135deg, var(--cyan), var(--purple));
}
.nav-name {
  font-size: 14px;
  font-weight: 700;
  color: var(--text-1);
}
.brand {
  display: flex;
  align-items: center;
  gap: 14px;
  cursor: pointer;
}

.app-main {
  flex: 1;
}

.app-footer {
  border-top: 1px solid rgba(139, 165, 255, 0.1);
  padding: 26px 0;
  margin-top: 40px;
}

.footer-inner {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
}

.footer-brand span {
  font-size: 18px;
  font-weight: 800;
}

.footer-brand p {
  font-size: 13px;
  color: var(--text-3);
  margin-top: 2px;
}

.footer-meta {
  font-size: 13px;
  color: var(--text-3);
  text-align: right;
  line-height: 1.8;
}

@media (max-width: 640px) {
  .binner-meta {
    text-align: left;
  }
}
</style>