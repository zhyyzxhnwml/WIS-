<script setup>
// 灵感热力图：横向/纵向均为领域，展示「领域 × 领域」的跨域关联度
import echarts from '../utils/echarts'
import { onMounted, onBeforeUnmount, ref, watch, nextTick } from 'vue'

const props = defineProps({
  heatmap: { type: Object, required: true } // 含 domains 名称与 matrix 关联度矩阵
})

const el = ref(null) // 图表容器
let chart = null
let resizeObs = null // 容器尺寸监听器，用于自适应

// 把关联度矩阵转成 ECharts 热力图所需的 [x, y, value] 三元组
function toOption() {
  const { domains, matrix } = props.heatmap
  const data = []
  matrix.forEach((row, y) => {
    row.forEach((val, x) => data.push([x, y, val]))
  })

  return {
    // 悬浮显示两个领域及其关联度
    tooltip: {
      position: 'top',
      backgroundColor: 'rgba(11,16,38,0.96)',
      borderColor: 'rgba(139,165,255,0.3)',
      textStyle: { color: '#eaeefc', fontSize: 12 },
      formatter: (p) => {
        const a = domains[p.value[0]]
        const b = domains[p.value[1]]
        return `<b>${a} ↔ ${b}</b><br/>跨域关联度：${p.value[2]}`
      }
    },
    grid: {
      left: 120,
      right: 46,
      top: 16,
      bottom: 36,
      containLabel: false
    },
    // 横纵轴均为领域分类
    xAxis: {
      type: 'category',
      data: domains,
      splitArea: { show: true },
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: {
        color: '#aab4d8',
        fontSize: 12,
        interval: 0
      }
    },
    yAxis: {
      type: 'category',
      data: domains,
      splitArea: { show: true },
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: { color: '#aab4d8', fontSize: 12, interval: 0 }
    },
    // 关联度从低到高的渐变色
    visualMap: {
      min: 0,
      max: 100,
      calculable: true,
      orient: 'vertical',
      right: 0,
      top: 'center',
      itemWidth: 10,
      itemHeight: 110,
      textStyle: { color: '#8b95c8', fontSize: 11 },
      inRange: {
        color: ['#141a3f', '#1f2b66', '#2f6fe8', '#38bdf8', '#a78bfa', '#ec4899']
      }
    },
    series: [
      {
        type: 'heatmap',
        data,
        label: {
          show: true,
          color: '#eaeefc',
          fontSize: 11,
          // 对角线的自重(100)不需要标注，其余显示数值
          formatter: (p) => (p.value[2] === 100 ? '' : p.value[2])
        },
        itemStyle: {
          borderColor: 'rgba(7,10,26,0.9)',
          borderRadius: 5,
          borderWidth: 2
        },
        emphasis: {
          itemStyle: { shadowBlur: 12, shadowColor: 'rgba(34,211,238,0.5)' }
        }
      }
    ]
  }
}

// 使用新的热力图配置重绘
function render() {
  if (!chart) return
  chart.setOption(toOption(), true)
}

onMounted(async () => {
  // 等 DOM 挂载后再初始化图表
  await nextTick()
  chart = echarts.init(el.value, null, { renderer: 'canvas' })
  render()
  // 监听容器尺寸变化以自适应
  resizeObs = new ResizeObserver(() => chart && chart.resize())
  resizeObs.observe(el.value)
})

onBeforeUnmount(() => {
  // 卸载时断开监听并销毁图表，释放资源
  if (resizeObs) resizeObs.disconnect()
  if (chart) {
    chart.dispose()
    chart = null
  }
})

// 数据变化时重绘
watch(
  () => props.heatmap,
  () => render(),
  { deep: true }
)
</script>

<template>
  <div ref="el" class="heat-chart"></div>
</template>

<style scoped>
.heat-chart {
  width: 100%;
  height: 480px;
}
</style>