<script setup>
// 搜索输入框组件：支持不同尺寸与占位文案，提交时向上抛出纯文本内容
import { ref, watch } from 'vue'

const props = defineProps({
  size: { type: String, default: 'lg' },
  placeholder: { type: String, default: '描述你的技术问题，例如：如何让无人机更抗冲击？' },
  initial: { type: String, default: '' }
})

const emit = defineEmits(['submit'])

const value = ref(props.initial)

// 当外部传入的 initial（如当前问题）变化时，同步回输入框，保证展示内容与新问题一致
watch(
  () => props.initial,
  (v) => {
    value.value = v || ''
  }
)

function onSubmit() {
  const text = value.value.trim()
  if (!text) return
  emit('submit', text)
}
</script>

<template>
  <form class="search-bar" :class="`size-${size}`" @submit.prevent="onSubmit">
    <span class="search-icon">⌕</span>
    <input
      v-model="value"
      type="text"
      :placeholder="placeholder"
      class="search-input"
    />
    <button type="submit" class="search-btn">
      <span class="btn-label">探索灵感</span>
      <span class="btn-arrow">→</span>
    </button>
  </form>
</template>

<style scoped>
.search-bar {
  display: flex;
  align-items: center;
  gap: 12px;
  background: rgba(13, 17, 40, 0.85);
  border: 1px solid rgba(139, 165, 255, 0.28);
  border-radius: 999px;
  padding: 6px 6px 6px 22px;
  transition: border-color 0.25s ease, box-shadow 0.25s ease;
}

.search-bar:focus-within {
  border-color: rgba(34, 211, 238, 0.6);
  box-shadow: 0 0 0 4px rgba(34, 211, 238, 0.08), var(--shadow-glow);
}

.size-lg {
  padding: 12px 12px 12px 26px;
}
.size-lg .search-input {
  font-size: 17px;
}
.size-lg .search-btn {
  padding: 14px 30px;
  font-size: 16px;
}

.search-icon {
  color: var(--cyan);
  font-size: 22px;
  line-height: 1;
  opacity: 0.9;
}

.search-input {
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  color: var(--text-1);
  font-size: 15px;
  min-width: 0;
}
.search-input::placeholder {
  color: var(--text-3);
}

.search-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 11px 24px;
  border-radius: 999px;
  font-size: 15px;
  font-weight: 700;
  color: #fff;
  background: var(--grad-main);
  box-shadow: 0 6px 18px rgba(59, 130, 246, 0.35);
  transition: transform 0.2s ease, filter 0.2s ease, box-shadow 0.2s ease;
  white-space: nowrap;
}
.search-btn:hover {
  transform: translateY(-1px);
  filter: brightness(1.08);
  box-shadow: 0 8px 24px rgba(139, 92, 246, 0.45);
}

.btn-arrow {
  transition: transform 0.2s ease;
}
.search-btn:hover .btn-arrow {
  transform: translateX(4px);
}

@media (max-width: 560px) {
  .size-lg {
    flex-direction: column;
    border-radius: 18px;
    padding: 16px;
  }
  .size-lg .search-input {
    width: 100%;
  }
  .size-lg .search-btn {
    width: 100%;
    justify-content: center;
  }
}
</style>