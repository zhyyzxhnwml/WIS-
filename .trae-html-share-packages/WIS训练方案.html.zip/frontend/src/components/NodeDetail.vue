<script setup>
// 节点详情面板：展示路径图中选中节点的角色、所属领域与重定向强度
const props = defineProps({
  node: { type: Object, default: null } // 选中的节点详情，为 null 时显示占位提示
})

// 各节点类型对应的图标
const typeIcon = {
  问题: '❓',
  功能: '⚙',
  'TRIZ原理': '🧩',
  跨域概念: '◎',
  源领域实例: '★',
  方案: '⚡'
}
</script>

<template>
  <div v-if="node" class="node-detail">
    <span class="type-tag" :style="{ color: node.lane ? '#aab4d8' : '#22d3ee' }">
      {{ node.typeLabel }}
    </span>

    <div class="node-title">
      <span class="node-icon" :style="{ '--nc': '#22d3ee' }">{{ typeIcon[node.type] || '✦' }}</span>
      <h4>{{ node.title }}</h4>
    </div>

    <div class="node-badges">
      <span v-if="node.domain" class="badge domain">
        <i class="dot" :style="{ background: node.color || '#22d3ee' }"></i>
        {{ node.domain }} 领域
      </span>
      <span v-if="node.weight" class="badge weight">
        <i class="dot cyan"></i>
        重定向强度 {{ node.weight.toFixed(2) }}
      </span>
    </div>

    <p class="node-desc">{{ node.detail }}</p>

    <p class="node-tip">
      <i>·</i> 在左侧路径图中任意点击节点，可查看对应解释
    </p>
  </div>

  <div v-else class="node-detail empty">
    <span class="empty-icon">◎</span>
    <p>点击左侧路径图中的节点，查看该节点在跨领域映射中的角色与解释。</p>
  </div>
</template>

<style scoped>
.node-detail {
  padding: 4px 2px;
}

.type-tag {
  display: inline-block;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 1px;
  border: 1px solid rgba(34, 211, 238, 0.3);
  border-radius: 4px;
  padding: 2px 10px;
  margin-bottom: 14px;
  background: rgba(34, 211, 238, 0.05);
}

.node-title {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 12px;
}
.node-icon {
  width: 34px;
  height: 34px;
  flex: none;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  border-radius: 9px;
  background: rgba(34, 211, 238, 0.1);
  border: 1px solid rgba(34, 211, 238, 0.3);
}
.node-title h4 {
  font-size: 17px;
  font-weight: 700;
  line-height: 1.4;
}

.node-badges {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 14px;
}
.badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: var(--text-2);
  border: 1px solid var(--card-border);
  border-radius: 999px;
  padding: 3px 10px;
}
.badge .dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
}
.badge .cyan {
  background: var(--cyan);
}

.node-desc {
  font-size: 13.5px;
  color: var(--text-2);
  line-height: 1.75;
  border-left: 2px solid rgba(34, 211, 238, 0.4);
  padding-left: 12px;
}

.node-tip {
  margin-top: 16px;
  font-size: 12px;
  color: var(--text-3);
}
.node-tip i {
  font-style: normal;
  color: var(--cyan);
}

.empty {
  text-align: center;
  color: var(--text-3);
  padding: 26px 6px;
}
.empty-icon {
  font-size: 30px;
  display: block;
  margin-bottom: 10px;
  opacity: 0.5;
}
.empty p {
  font-size: 13px;
}
</style>