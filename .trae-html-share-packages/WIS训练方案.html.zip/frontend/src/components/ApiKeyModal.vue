<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue'
import { api } from '../utils/api.js'

// AI 模型设置弹窗状态
const visible = ref(false) // 弹窗是否显示
const provider = ref('deepseek') // 当前选择的提供商：deepseek / ollama
const keyDraft = ref('') // DeepSeek Key 草稿（保存前不落地）
const showMask = ref(false) // 是否以密文显示 Key
const modelDraft = ref('') // Ollama 模型名草稿
const ollamaStatus = ref({ available: false, models: [] }) // Ollama 检测结果
const statusLoading = ref(false) // Ollama 状态检测中
const saved = ref(false) // 保存成功提示

const emit = defineEmits(['save'])

// 探测本机 Ollama 是否可用及其模型列表，可用时自动填入默认模型
async function loadOllamaStatus() {
  statusLoading.value = true
  try {
    const resp = await fetch('/api/llm/status', { headers: { 'Content-Type': 'application/json' } })
    const data = await resp.json()
    ollamaStatus.value = {
      available: Boolean(data.ollama_available),
      models: data.ollama_models || [],
    }
    // 尚未手动输入模型名时，自动带出默认模型
    if (ollamaStatus.value.available && !modelDraft.value) {
      modelDraft.value = data.default_ollama_model || data.ollama_models[0] || ''
    }
  } catch (e) {
    // 检测失败视为无本机 Ollama
    ollamaStatus.value = { available: false, models: [] }
  } finally {
    statusLoading.value = false
  }
}

// 打开弹窗：从本地存储恢复当前配置并重新检测 Ollama
function open() {
  provider.value = api.getLLMProvider()
  keyDraft.value = api.getDeepSeekKey() || ''
  modelDraft.value = api.getLLMModel() || ''
  saved.value = false
  visible.value = true
  loadOllamaStatus()
}

function close() {
  visible.value = false
}

// 判断当前草稿是否已构成有效配置
function isConfigured() {
  if (provider.value === 'ollama') return Boolean(modelDraft.value.trim())
  return Boolean(keyDraft.value.trim())
}

// 保存配置：按提供商分别持久化模型名或 Key，并把另一项清空
function save() {
  api.setLLMProvider(provider.value)
  if (provider.value === 'ollama') {
    api.setLLMModel(modelDraft.value.trim())
    api.setDeepSeekKey(null)
  } else {
    api.setDeepSeekKey(keyDraft.value)
    api.setLLMModel(null)
  }
  saved.value = true
  emit('save', { provider: provider.value, configured: isConfigured() })
  // 稍作延迟再关闭，让用户看到「已保存」提示
  setTimeout(close, 900)
}

// 清除所有 AI 配置并恢复默认
function clearAll() {
  api.setDeepSeekKey(null)
  api.setLLMProvider(null)
  api.setLLMModel(null)
  provider.value = 'deepseek'
  keyDraft.value = ''
  modelDraft.value = ''
  saved.value = false
  emit('save', { provider: 'deepseek', configured: false })
}

// 全局键盘监听：弹窗内支持 Esc 关闭、Enter 保存（textarea 除外）
function onKeydown(e) {
  // 弹窗未打开时不要响应用户按键，避免在搜索框等输入框中按 Enter 误触发保存
  if (!visible.value) return
  if (e.key === 'Escape') close()
  if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') save()
}

// 挂载时绑定、卸载时移除键盘监听
onMounted(() => window.addEventListener('keydown', onKeydown))
onBeforeUnmount(() => window.removeEventListener('keydown', onKeydown))

defineExpose({ open })
</script>

<template>
  <teleport to="body">
    <transition name="fade">
      <div v-if="visible" class="key-cover" @mousedown.self="close">
        <div class="key-card">
          <div class="key-head">
            <h3>AI 模型设置</h3>
            <button class="key-close" @click="close" aria-label="关闭">×</button>
          </div>

          <p class="key-tip">选择创新方案生成用的大模型来源，仅保存在当前浏览器本地。</p>

          <div class="provider-grid">
            <button
              type="button"
              class="provider-card"
              :class="{ active: provider === 'deepseek' }"
              @click="provider = 'deepseek'"
            >
              <span class="provider-name">DeepSeek 云端</span>
              <span class="provider-sub">在线 API，需你自己的 Key</span>
            </button>
            <button
              type="button"
              class="provider-card"
              :class="{ active: provider === 'ollama' }"
              @click="provider = 'ollama'"
            >
              <span class="provider-name">本机 Ollama</span>
              <span class="provider-sub">本地部署 AI，无需 Key</span>
            </button>
          </div>

          <div v-if="provider === 'deepseek'" class="provider-panel">
            <div class="key-field">
              <input
                v-model="keyDraft"
                :type="showMask ? 'password' : 'text'"
                placeholder="sk-xxxxxxxxxxxxxxxx"
                autocomplete="off"
              />
              <button class="key-eye" type="button" @click="showMask = !showMask">
                {{ showMask ? '显示' : '隐藏' }}
              </button>
            </div>
            <p class="key-note">不填时仅能使用图谱检索，LLM 创新兜底不可用。</p>
          </div>

          <div v-else class="provider-panel">
            <div v-if="statusLoading" class="key-note">正在检测本机 Ollama…</div>
            <div v-else-if="!ollamaStatus.available" class="key-note warn">
              未检测到本机 Ollama（<code>http://localhost:11434</code>）。请先启动 Ollama 并拉取模型。
            </div>
            <div class="key-field" style="margin-top: 10px">
              <input
                v-model="modelDraft"
                type="text"
                :list="ollamaStatus.available ? 'ollama-model-list' : undefined"
                placeholder="模型名，如 qwen2.5:7b"
                autocomplete="off"
              />
              <datalist v-if="ollamaStatus.available" id="ollama-model-list">
                <option v-for="m in ollamaStatus.models" :key="m" :value="m"></option>
              </datalist>
              <button v-if="ollamaStatus.available" class="key-eye" type="button" @click="loadOllamaStatus">刷新</button>
            </div>
          </div>

          <div class="key-actions">
            <button class="key-btn ghost" @click="clearAll">清除</button>
            <button class="key-btn primary" @click="save">保存</button>
          </div>
          <p v-if="saved" class="key-saved">✓ 已保存</p>
        </div>
      </div>
    </transition>
  </teleport>
</template>

<style scoped>
.key-cover {
  position: fixed;
  inset: 0;
  z-index: 200;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(4, 6, 16, 0.66);
  backdrop-filter: blur(6px);
  padding: 20px;
}

.key-card {
  width: 100%;
  max-width: 460px;
  max-height: 90vh;
  overflow-y: auto;
  background: rgba(13, 17, 40, 0.97);
  border: 1px solid rgba(139, 165, 255, 0.24);
  border-radius: 18px;
  padding: 24px;
  box-shadow: 0 18px 60px rgba(0, 0, 0, 0.5), var(--shadow-glow);
}

.key-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}
.key-head h3 {
  font-size: 17px;
  font-weight: 800;
  color: var(--text-1);
}
.key-close {
  border: none;
  background: transparent;
  color: var(--text-3);
  font-size: 22px;
  line-height: 1;
  cursor: pointer;
}
.key-close:hover {
  color: var(--cyan);
}

.key-tip {
  font-size: 13px;
  color: var(--text-2);
  margin-bottom: 14px;
  line-height: 1.6;
}

.provider-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  margin-bottom: 14px;
}
.provider-card {
  text-align: left;
  background: rgba(9, 12, 27, 0.8);
  border: 1px solid rgba(139, 165, 255, 0.24);
  border-radius: 12px;
  padding: 12px 14px;
  cursor: pointer;
  transition: border-color 0.2s ease, background 0.2s ease;
}
.provider-card.active {
  border-color: rgba(34, 211, 238, 0.65);
  background: rgba(34, 211, 238, 0.08);
}
.provider-name {
  display: block;
  font-size: 14px;
  font-weight: 800;
  color: var(--text-1);
}
.provider-sub {
  display: block;
  margin-top: 3px;
  font-size: 12px;
  color: var(--text-3);
}

.provider-panel {
  padding: 2px 0;
}

.key-field {
  display: flex;
  gap: 10px;
}
.key-field input {
  flex: 1;
  min-width: 0;
  background: rgba(9, 12, 27, 0.8);
  border: 1px solid rgba(139, 165, 255, 0.28);
  border-radius: 10px;
  padding: 10px 12px;
  color: var(--text-1);
  font-size: 14px;
  outline: none;
}
.key-field input:focus {
  border-color: rgba(34, 211, 238, 0.6);
  box-shadow: 0 0 0 3px rgba(34, 211, 238, 0.08);
}

.key-eye {
  border: 1px solid rgba(139, 165, 255, 0.28);
  background: transparent;
  color: var(--text-2);
  border-radius: 10px;
  padding: 0 14px;
  font-size: 13px;
  cursor: pointer;
  white-space: nowrap;
}
.key-eye:hover {
  color: var(--cyan);
  border-color: rgba(34, 211, 238, 0.5);
}

.key-note {
  margin-top: 10px;
  font-size: 12px;
  color: var(--text-3);
  line-height: 1.6;
}
.key-note.warn {
  color: #fbbf24;
}
.key-note code {
  color: var(--cyan);
  background: rgba(34, 211, 238, 0.1);
  padding: 1px 5px;
  border-radius: 5px;
}

.key-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 20px;
}
.key-btn {
  border-radius: 999px;
  padding: 9px 22px;
  font-size: 14px;
  font-weight: 700;
  cursor: pointer;
  transition: transform 0.15s ease, filter 0.15s ease;
}
.key-btn:hover {
  transform: translateY(-1px);
}
.key-btn.ghost {
  border: 1px solid rgba(139, 165, 255, 0.3);
  background: transparent;
  color: var(--text-2);
}
.key-btn.ghost:hover {
  color: var(--text-1);
  border-color: rgba(139, 165, 255, 0.55);
}
.key-btn.primary {
  border: none;
  color: #fff;
  background: var(--grad-main);
  box-shadow: 0 6px 18px rgba(59, 130, 246, 0.35);
}
.key-btn.primary:hover {
  filter: brightness(1.08);
}

.key-saved {
  margin-top: 12px;
  text-align: center;
  font-size: 13px;
  color: var(--cyan);
}
</style>