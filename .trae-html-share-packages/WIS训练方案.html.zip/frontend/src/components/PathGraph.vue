<script setup>
// 跨域映射路径图：以固定布局(graph layout none)展示 问题→功能→...→方案 的完整推理链
import echarts from '../utils/echarts'
import { onMounted, onBeforeUnmount, ref, watch, nextTick } from 'vue'

const props = defineProps({
  example: { type: Object, required: true }, // 结果结构（含 graph 节点与连线）
  activeLane: { type: String, default: '' } // 当前高亮的领域，用于弱化其余领域
})

const emit = defineEmits(['node-click'])

const el = ref(null)
let chart = null
let resizeObs = null

// 组装关系图配置；activeLane 非空时把其它领域的节点/连线降透明度淡出
function toOption() {
  const { nodes, links } = props.example.graph
  const active = props.activeLane || ''
  // ECharts graph 的 layout:'none' 不识别百分比坐标，此处换算为容器像素值
  const w = el.value?.clientWidth || 700
  const h = el.value?.clientHeight || 560

  // 节点：非活动 lane 的节点透明度调低（dim）
  const nodeOpts = nodes.map((n) => {
    const lane = n.payload?.lane
    const dim = lane && lane !== active
    return {
      id: n.id,
      name: n.name,
      payload: n.payload, // 透传 payload 供 tooltip / 点击事件读取
      symbol: 'circle',
      symbolSize: n.symbolSize,
      x: (n.x / 100) * w, // 固定百分比坐标换算为像素，形成从左到右的路径
      y: (n.y / 100) * h,
      itemStyle: {
        color: n.color,
        opacity: dim ? 0.15 : 1,
        shadowBlur: n.type === '方案' ? 22 : 14,
        shadowColor: n.color
      },
      label: {
        show: true,
        position: 'bottom',
        distance: 10,
        color: dim ? 'rgba(170,180,216,0.35)' : '#dce3ff',
        fontSize: 12,
        lineHeight: 16,
        fontWeight: n.type === '方案' ? 700 : 400
      },
      emphasis: {
        scale: 1.25,
        itemStyle: { shadowBlur: 26 },
        label: { color: '#ffffff' }
      }
    }
  })

  // 连线：重定向连线加粗高亮，非活动 lane 淡化
  const linkOpts = links.map((l) => {
    const dim = l.lane && l.lane !== active
    return {
      source: l.source,
      target: l.target,
      label: {
        show: !!l.label,
        formatter: l.label || '',
        color: l.redirect ? l.color : '#8b95c8',
        fontSize: l.redirect ? 12 : 10,
        fontWeight: l.redirect ? 700 : 400,
        position: 'middle',
        distance: 8,
        opacity: dim ? 0.12 : 1
      },
      lineStyle: {
        color: l.color,
        width: (l.redirect ? 4 : 2.2) * l.weight,
        opacity: dim ? 0.12 : l.redirect ? 1 : 0.8,
        curveness: 0.16,
        shadowColor: l.redirect ? l.color : 'transparent',
        shadowBlur: l.redirect ? 8 : 0
      },
      emphasis: { lineStyle: { width: 6 } }
    }
  })

  return {
    tooltip: {
      trigger: 'item',
      backgroundColor: 'rgba(11,16,38,0.96)',
      borderColor: 'rgba(139,165,255,0.3)',
      textStyle: { color: '#eaeefc', fontSize: 12 },
      formatter: (p) => {
        // 悬浮节点时展示其标题、类型与简单描述
        if (p.dataType === 'node' && p.data.payload) {
          const { title, typeLabel, detail } = p.data.payload
          const desc = detail ? `<div style="margin-top:6px;color:#aab4d8;max-width:320px;line-height:1.6">${detail}</div>` : ''
          return `<b>${title}</b><br/><span style="color:#8b95c8;font-size:11px">${typeLabel || ''}</span>${desc}`
        }
        return ''
      }
    },
    series: [
      {
        type: 'graph',
        layout: 'none', // 使用数据自带的 x/y 百分比坐标，固定路径布局
        data: nodeOpts,
        links: linkOpts,
        roam: true, // 允许缩放拖拽
        scaleLimit: { min: 0.7, max: 1.8 },
        edgeSymbol: ['none', 'arrow'],
        edgeSymbolSize: [0, 9],
        animationDuration: 600,
        animationEasingUpdate: 'cubicOut'
      }
    ]
  }
}

function render() {
  if (!chart) return
  chart.setOption(toOption(), true)
}

onMounted(async () => {
  await nextTick()
  chart = echarts.init(el.value, null, { renderer: 'canvas' })
  // 点击节点时向上抛出其详情数据（含所属 lane 与 id）
  chart.on('click', (params) => {
    if (params.dataType === 'node' && params.data && params.data.payload) {
      emit('node-click', { ...params.data.payload, id: params.data.id })
    }
  })
  render()
  resizeObs = new ResizeObserver(() => {
    if (!chart) return
    chart.resize()
    render() // 容器尺寸变化时重算百分比坐标
  })
  resizeObs.observe(el.value)
})

onBeforeUnmount(() => {
  // 卸载时释放监听与图表资源
  if (resizeObs) resizeObs.disconnect()
  if (chart) {
    chart.dispose()
    chart = null
  }
})

// 高亮领域变化或切换问题(example.id)时重绘
watch(
  () => props.activeLane,
  () => render()
)
watch(
  () => props.example.id,
  () => render()
)
</script>

<template>
  <div ref="el" class="path-chart"></div>
</template>

<style scoped>
.path-chart {
  width: 100%;
  height: 560px;
}
</style>