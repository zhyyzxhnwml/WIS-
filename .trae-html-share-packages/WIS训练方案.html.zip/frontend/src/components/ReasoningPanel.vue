<script setup>
// 完整推理链面板：独立大模块，展示当前选中方案的问题推导全过程
const props = defineProps({
  scheme: { type: Object, required: true } // 当前选中的方案（含 reasoning 8 步推导）
})
</script>

<template>
  <div class="card reasoning-panel">
    <div class="rp-head">
      <div>
        <h3>完整推理链</h3>
        <p class="rp-sub">
          问题 → 功能抽象 → 矛盾识别 → 原理推演 → 概念中介 → 源域类比 → 跨域映射 → 方案定型
        </p>
      </div>
      <div class="rp-meta">
        <span class="rp-domain" :style="{ '--dc': scheme.color, borderColor: scheme.color }">
          {{ scheme.domain }}
        </span>
        <span
          v-if="scheme.triz"
          class="rp-triz"
        >
          TRIZ · {{ scheme.triz }}
        </span>
      </div>
    </div>

    <ol v-if="scheme.reasoning && scheme.reasoning.length" class="rp-steps">
      <li
        v-for="(r, i) in scheme.reasoning"
        :key="i"
        class="rp-step"
      >
        <span class="rp-no">{{ i + 1 }}</span>
        <div class="rp-body">
          <span class="rp-k" :class="{ conflict: r.tag === '矛盾' }">{{ r.step }}</span>
          <p class="rp-t">{{ r.text }}</p>
        </div>
      </li>
    </ol>

    <p v-else class="rp-empty">当前方案暂无推理链数据。</p>
  </div>
</template>

<style scoped>
.reasoning-panel {
  padding: 22px 24px 24px;
  margin-top: 16px;
}

.rp-head {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 14px;
  flex-wrap: wrap;
  margin-bottom: 18px;
  padding-bottom: 14px;
  border-bottom: 1px solid rgba(139, 165, 255, 0.12);
}
.rp-head h3 {
  font-size: 18px;
  font-weight: 800;
}
.rp-sub {
  font-size: 12.5px;
  color: var(--text-3);
  margin-top: 4px;
  line-height: 1.6;
}

.rp-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.rp-domain {
  padding: 3px 14px;
  border-radius: 999px;
  font-size: 12.5px;
  font-weight: 700;
  color: var(--dc);
  border: 1px solid;
  background: color-mix(in srgb, var(--dc) 12%, transparent);
}
.rp-triz {
  font-size: 12px;
  font-weight: 700;
  color: #a78bfa;
  border: 1px solid rgba(167, 139, 250, 0.4);
  border-radius: 8px;
  padding: 3px 12px;
}

.rp-steps {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.rp-step {
  display: flex;
  align-items: flex-start;
  gap: 14px;
}

.rp-no {
  flex: none;
  width: 26px;
  height: 26px;
  margin-top: 2px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  font-size: 12px;
  font-weight: 800;
  color: #eaeefc;
  background: linear-gradient(135deg, rgba(59, 130, 246, 0.7), rgba(139, 92, 246, 0.7));
  box-shadow: 0 2px 8px rgba(59, 130, 246, 0.35);
}

.rp-body {
  flex: 1;
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 10px 14px;
  background: rgba(255, 255, 255, 0.025);
  border: 1px solid rgba(139, 165, 255, 0.1);
  border-radius: 10px;
}

.rp-k {
  flex: none;
  font-size: 12.5px;
  font-weight: 800;
  color: #a78bfa;
  border: 1px solid rgba(167, 139, 250, 0.4);
  border-radius: 6px;
  padding: 1px 9px;
  margin-top: 1px;
  white-space: nowrap;
}
.rp-k.conflict {
  color: #f472b6;
  border-color: rgba(244, 114, 182, 0.45);
}

.rp-t {
  font-size: 14px;
  color: var(--text-2);
  line-height: 1.85;
}

.rp-empty {
  font-size: 13px;
  color: var(--text-3);
  text-align: center;
  padding: 26px 0;
}
</style>