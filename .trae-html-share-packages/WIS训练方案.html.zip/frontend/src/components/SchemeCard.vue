<script setup>
// 方案卡片：展示单条跨领域融合方案，点击可高亮对应路径并联动下方推理链
const props = defineProps({
  scheme: { type: Object, required: true }, // 方案数据
  active: { type: Boolean, default: false } // 是否为当前高亮方案
})

const emit = defineEmits(['select'])
</script>

<template>
  <article
    class="card scheme-card"
    :class="{ 'is-active': active }"
    @click="emit('select', scheme.laneKey)"
  >
    <div class="scheme-head">
      <span class="domain-chip" :style="{ '--dc': scheme.color, borderColor: scheme.color }">
        {{ scheme.domain }}
      </span>
      <span class="score" :style="{ '--sc': scheme.color }">{{ scheme.score }}</span>
    </div>

    <h4 class="scheme-title">{{ scheme.title }}</h4>

    <div class="scheme-meta">
      <span class="meta-item">
        <i class="meta-k">TRIZ</i>{{ scheme.triz }}
      </span>
      <span class="meta-item">
        <i class="meta-k">灵感</i>{{ scheme.instance }}
      </span>
    </div>

    <p class="scheme-desc">{{ scheme.explanation }}</p>

    <div v-if="scheme.annotation" class="annotations">
      <div v-if="scheme.annotation.triz" class="ann-item">
        <span class="ann-k">TRIZ</span>
        <span class="ann-v">{{ scheme.annotation.triz }}</span>
      </div>
      <div v-if="scheme.annotation.functionAbstraction" class="ann-item">
        <span class="ann-k">功能</span>
        <span class="ann-v">{{ scheme.annotation.functionAbstraction }}</span>
      </div>
      <div v-if="scheme.annotation.crossDomainAnalogy" class="ann-item">
        <span class="ann-k">类比</span>
        <span class="ann-v">{{ scheme.annotation.crossDomainAnalogy }}</span>
      </div>
      <div v-if="scheme.annotation.knowledgeGraph" class="ann-item">
        <span class="ann-k">图谱</span>
        <span class="ann-v">{{ scheme.annotation.knowledgeGraph }}</span>
      </div>
    </div>

    <ul class="gains">
      <li v-for="g in scheme.gains" :key="g">{{ g }}</li>
    </ul>

    <div class="scheme-foot">
      <span class="weight">重定向强度 · {{ scheme.weight.toFixed(2) }}</span>
      <span class="view">查看路径 <i>→</i></span>
    </div>

    <div class="scheme-use">
      <div class="use-h">怎么用</div>
      <div class="use-b">
        点击本卡片即在路径图中高亮对应领域路径，并在下方「完整推理链」面板展示该方案从问题到定型的推导过程。
      </div>
      <div class="use-h">效果</div>
      <div class="use-b">
        同步高亮映射路径 + 逐条展开 8 步推理链，可对照方案来源、TRIZ 原理与创新评分理解其跨域思路。
      </div>
    </div>
  </article>
</template>

<style scoped>
.scheme-card {
  padding: 18px 18px 14px;
  cursor: pointer;
  border-left: 3px solid transparent;
}
.scheme-card:hover {
  transform: translateX(3px);
}
.scheme-card.is-active {
  border-color: var(--card-border-hover);
  border-left-color: var(--cyan);
  box-shadow: var(--shadow-glow);
  background: linear-gradient(135deg, rgba(59, 130, 246, 0.08), rgba(236, 72, 153, 0.05));
}

.scheme-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.domain-chip {
  padding: 2px 12px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 700;
  color: var(--dc);
  border: 1px solid;
  background: color-mix(in srgb, var(--dc) 12%, transparent);
}

.score {
  font-size: 20px;
  font-weight: 800;
  color: var(--sc);
}
.score::after {
  content: ' 创新度';
  font-size: 11px;
  font-weight: 500;
  color: var(--text-3);
}

.scheme-title {
  font-size: 15.5px;
  font-weight: 700;
  margin-bottom: 10px;
  line-height: 1.45;
}

.scheme-meta {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 10px;
}

.meta-item {
  font-size: 12.5px;
  color: var(--text-2);
  display: flex;
  align-items: baseline;
  gap: 6px;
}

.meta-k {
  flex: none;
  font-style: normal;
  font-size: 11px;
  font-weight: 700;
  color: var(--cyan);
  border: 1px solid rgba(34, 211, 238, 0.35);
  border-radius: 4px;
  padding: 0 6px;
}

.scheme-desc {
  font-size: 13px;
  color: var(--text-2);
  line-height: 1.65;
  margin-bottom: 10px;
}

.annotations {
  display: flex;
  flex-direction: column;
  gap: 7px;
  margin-bottom: 10px;
  padding: 10px 12px;
  background: rgba(255, 255, 255, 0.03);
  border-radius: 10px;
  border: 1px solid rgba(139, 165, 255, 0.12);
}
.ann-item {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  font-size: 12px;
  line-height: 1.6;
  color: var(--text-2);
}
.ann-k {
  flex: none;
  margin-top: 1px;
  font-size: 11px;
  font-weight: 800;
  color: #a78bfa;
  border: 1px solid rgba(167, 139, 250, 0.4);
  border-radius: 4px;
  padding: 0 6px;
}
.ann-v {
  color: var(--text-2);
}

.gains {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  padding: 10px 0;
  border-top: 1px dashed rgba(139, 165, 255, 0.16);
}

.scheme-use {
  margin-top: 10px;
  padding: 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  background: rgba(34, 211, 238, 0.05);
  border: 1px solid rgba(34, 211, 238, 0.18);
  border-radius: 10px;
}
.use-h {
  font-size: 11px;
  font-weight: 800;
  letter-spacing: 1px;
  color: var(--cyan);
}
.use-b {
  font-size: 12.5px;
  color: var(--text-2);
  line-height: 1.7;
}

.gains li {
  font-size: 12px;
  color: var(--text-2);
}
.gains li::before {
  content: '+ ';
  color: var(--cyan);
  font-weight: 700;
}

.scheme-foot {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 12px;
  color: var(--text-3);
}

.view {
  color: var(--cyan);
  font-weight: 700;
}
.view i {
  font-style: normal;
  display: inline-block;
  transition: transform 0.2s ease;
}
.scheme-card:hover .view i {
  transform: translateX(4px);
}
</style>