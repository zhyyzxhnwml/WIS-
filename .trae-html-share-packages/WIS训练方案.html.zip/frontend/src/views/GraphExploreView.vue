<script setup>
import { ref, onMounted, onBeforeUnmount, watch } from 'vue'
import { useRouter } from 'vue-router'
import echarts from '../utils/echarts.js'
import { api } from '../utils/api.js'

const router = useRouter()

// 加载与展示状态
const loading = ref(false)
const error = ref('')
const summary = ref(null) // 图谱统计概要
const network = ref({ nodes: [], links: [] }) // 图谱网络数据

// 过滤条件
const domains = ref([]) // 可用领域列表（含实例数）
const activeDomain = ref('') // 当前选中领域，空串表示全部
const keyword = ref('') // 检索关键词
const activeLabels = ref(['概念', '实例', '领域']) // 默认展示的节点类型

// 节点类型及配色
const LABELS = ['问题', '功能', 'TRIZ原理', '概念', '实例', '领域', '方案']
const LABEL_COLOR = {
  问题: '#22d3ee',
  功能: '#3b82f6',
  TRIZ原理: '#8b5cf6',
  概念: '#a78bfa',
  实例: '#ec4899',
  领域: '#34d399',
  方案: '#f59e0b'
}

// 选中的节点及其邻域，容器引用与图表实例
const selected = ref(null)
const nodeLoading = ref(false)
const chartEl = ref(null)
let chart = null
let resizeHandler = null

// 「使用说明」帮助面板是否展开
const showHelp = ref(false)

// 各类型在图例下的文字说明
const LABEL_DESC = {
  问题: '技术难题（用户输入 → 功能）',
  功能: '问题抽象出的核心功能',
  TRIZ原理: '40 个发明原理',
  概念: '跨领域抽象隐喻（中介）',
  实例: '源领域具体对象',
  领域: '实例归属领域',
  方案: '生成的方案'
}

onMounted(async () => {
  // 监听窗口尺寸变化以自适应图表
  resizeHandler = () => chart && chart.resize()
  window.addEventListener('resize', resizeHandler)
  await loadSummary()
  await loadNetwork()
})

onBeforeUnmount(() => {
  // 卸载时移除监听并销毁图表实例，避免内存泄漏
  window.removeEventListener('resize', resizeHandler)
  if (chart) {
    chart.dispose()
    chart = null
  }
})

// 加载图谱统计概要
async function loadSummary() {
  try {
    summary.value = await api.graphSummary()
    domains.value = summary.value.domains
  } catch (e) {
    error.value = e.message
  }
}

// 按当前过滤条件加载图谱网络并渲染
async function loadNetwork() {
  loading.value = true
  error.value = ''
  try {
    network.value = await api.graphNetwork({
      domain: activeDomain.value || undefined,
      q: keyword.value || undefined,
      labels: activeLabels.value.length ? activeLabels.value.join(',') : undefined,
      limit: 420
    })
    render()
  } catch (e) {
    error.value = e.message
  } finally {
    loading.value = false
  }
}

// 切换某节点类型的显隐
function toggleLabel(label) {
  const i = activeLabels.value.indexOf(label)
  if (i >= 0) activeLabels.value.splice(i, 1)
  else activeLabels.value.push(label)
  loadNetwork()
}

// 选择/取消领域
function selectDomain(name) {
  activeDomain.value = activeDomain.value === name ? '' : name
  loadNetwork()
}

// 关键词检索
function onSearch() {
  loadNetwork()
}

// 重置所有过滤条件，恢复到默认（全部领域、默认节点类型、清空关键词）
function resetFilters() {
  activeDomain.value = ''
  keyword.value = ''
  activeLabels.value = ['概念', '实例', '领域']
  loadNetwork()
}

// 将当前 network 渲染为关系图，重复调用时更新配置
function render() {
  if (!chartEl.value) return
  if (!chart) chart = echarts.init(chartEl.value)

  // 图例类别：每个节点类型一种颜色
  const categories = Object.keys(LABEL_COLOR).map((l) => ({
    name: l,
    itemStyle: { color: LABEL_COLOR[l] }
  }))
  // 统计每类节点数量，用于决定是否显示标签
  const byLabel = {}
  network.value.nodes.forEach((n) => {
    byLabel[n.label] = (byLabel[n.label] || 0) + 1
  })

  // 依据节点大小度(degree)映射节点尺寸
  const nodeMax = Math.max(3, ...network.value.nodes.map((n) => n.degree || 0))
  const nodes = network.value.nodes.map((n) => ({
    id: n.id,
    name: n.name,
    category: n.label,
    symbolSize: 10 + Math.round(((n.degree || 1) / nodeMax) * 24),
    value: n.desc || n.label,
    degree: n.degree || 0
  }))
  const links = network.value.links.map((l) => ({
    source: l.source,
    target: l.target,
    value: l.type,
    lineStyle: {
      width: 1.2,
      color: 'rgba(139,165,255,0.35)',
      curveness: 0.12
    }
  }))

  // 节点标签显示策略：领域/概念总是显示；实例类型过多时隐藏以免拥挤
  const showLabel = (l) => l.label === '领域' || l.label === '概念' || (l.label === '实例' && byLabel[l.label] < 40)

  chart.setOption({
    backgroundColor: 'transparent',
    // 底部图例
    legend: [
      {
        bottom: 0,
        icon: 'circle',
        textStyle: { color: '#9aa7c7' },
        itemWidth: 12,
        itemHeight: 12,
        data: categories.map((c) => c.name)
      }
    ],
    // 悬浮提示
    tooltip: {
      backgroundColor: 'rgba(13,18,38,0.96)',
      borderColor: 'rgba(139,165,255,0.25)',
      textStyle: { color: '#e6edff', fontSize: 12 },
      formatter(p) {
        return `<b>${p.data.name}</b><br/>${p.data.value || ''}`
      }
    },
    animationDuration: 600,
    animationEasingUpdate: 'quinticInOut',
    series: [
      {
        type: 'graph',
        layout: 'force', // 力导向布局
        roam: true, // 允许缩放拖拽
        draggable: true,
        data: nodes,
        links,
        categories,
        label: {
          show: true,
          position: 'right',
          formatter(p) {
            const l = p.value.id !== undefined ? p.value : p.data
            return showLabel(l) ? l.name : ''
          },
          fontSize: 11,
          color: '#c8d4f5'
        },
        edgeSymbol: ['none', 'arrow'],
        edgeSymbolSize: [0, 5],
        force: {
          repulsion: 130,
          edgeLength: [40, 130],
          gravity: 0.12,
          layoutAnimation: false
        },
        emphasis: {
          focus: 'adjacency', // 高亮相邻节点
          lineStyle: { width: 2.4, color: '#22d3ee' }
        },
        itemStyle: {
          borderColor: 'rgba(255,255,255,0.18)',
          borderWidth: 0.5
        }
      }
    ]
  }, true)

  // 先移除旧点击绑定再重新绑定，避免重复触发；点击节点时查看详情
  chart.off('click')
  chart.on('click', (p) => {
    if (p.dataType === 'node') selectNode(p.data.id)
  })
}

// 查询单个节点详情与邻域关系
async function selectNode(name) {
  nodeLoading.value = true
  try {
    const res = await api.graphNode(name)
    selected.value = res.node ? { ...res.node, relations: res.relations } : null
  } catch (e) {
    error.value = e.message
  } finally {
    nodeLoading.value = false
  }
}

// 跳转到结果页展示该问题的分析
function openResult(question) {
  router.push({ name: 'result', query: { q: question } })
}

// 格式化节点属性：去掉 name，过滤空值，统一转字符串便于渲染
function formatProps(props) {
  return props
    ? Object.entries(props)
        .filter(([k, v]) => ['name'].includes(k) === false && v !== '' && v != null)
        .map(([k, v]) => ({ k, v: String(v) }))
    : []
}

// 各类节点的数量统计函数（用于过滤栏计数徽标）
const counts = {
  问题: () => network.value.nodes.filter((n) => n.label === '问题').length,
  功能: () => network.value.nodes.filter((n) => n.label === '功能').length,
  TRIZ原理: () => network.value.nodes.filter((n) => n.label === 'TRIZ原理').length,
  概念: () => network.value.nodes.filter((n) => n.label === '概念').length,
  实例: () => network.value.nodes.filter((n) => n.label === '实例').length,
  领域: () => network.value.nodes.filter((n) => n.label === '领域').length,
  方案: () => network.value.nodes.filter((n) => n.label === '方案').length
}
</script>

<template>
  <div class="graph-page">
    <div class="container">
      <div class="graph-head">
        <div>
          <h2 class="graph-title">知识图谱浏览</h2>
          <p class="graph-sub">问题 → 功能 → TRIZ 原理 → 概念 → 源领域实例 的重定向网络</p>
        </div>
        <div v-if="summary" class="graph-metrics">
          <span class="metric">{{ summary.nodes }} 节点</span>
          <span class="metric">{{ summary.relations }} 关系</span>
          <span class="metric">{{ summary.problems }} 问题</span>
        </div>
      </div>

      <!-- 使用说明（可折叠的帮助面板） -->
      <div class="card help-card">
        <button class="help-toggle" type="button" @click="showHelp = !showHelp">
          <span class="help-icon">?</span>
          使用说明
          <span class="help-caret" :class="{ open: showHelp }">▸</span>
        </button>
        <div v-if="showHelp" class="help-body">
          <ol class="help-list">
            <li>图谱展示「问题 → 功能 → TRIZ 原理 → 概念 → 源领域实例」的重定向网络。</li>
            <li><b>节点越大</b>表示关联关系越多；支持<b>拖拽</b>移动节点、<b>滚轮或框选</b>缩放平移。</li>
            <li><b>点击任意节点</b>，右侧面板显示其属性与邻域关系，点击邻域项可继续跳转。<br>若点击的是「问题」节点，可一键转跳到结果页查看该问题的完整分析与方案。</li>
            <li>「类型」「领域」按钮用于<b>按节点类型 / 按领域过滤</b>高亮范围；顶部的检索框可按名称/描述<b>关键词查找</b>。</li>
            <li>「重置」一键恢复所有过滤条件。</li>
            <li>各节点类型的含义与配色见页面底部「图例」。</li>
          </ol>
        </div>
      </div>

      <!-- 过滤栏 -->
      <div class="card filter-bar">
        <div class="filter-row">
          <input
            v-model="keyword"
            class="filter-search"
            placeholder="检索概念 / 实例名称或描述，如：蜂巢"
            @keyup.enter="onSearch"
          />
          <button class="btn" @click="onSearch">检索</button>
          <button class="btn ghost" @click="resetFilters">重置</button>
        </div>
        <div class="filter-row">
          <span class="filter-label">类型</span>
          <button
            v-for="l in LABELS"
            :key="l"
            class="chip"
            :class="{ active: activeLabels.includes(l) }"
            :style="activeLabels.includes(l) ? { borderColor: LABEL_COLOR[l], color: LABEL_COLOR[l] } : {}"
            @click="toggleLabel(l)"
          >
            {{ l }}<small>{{ counts[l] ? counts[l]() : '' }}</small>
          </button>
        </div>
        <div class="filter-row">
          <span class="filter-label">领域</span>
          <button
            v-for="d in domains"
            :key="d.name"
            class="chip"
            :class="{ active: activeDomain === d.name }"
            @click="selectDomain(d.name)"
          >
            {{ d.name }}<small>{{ d.instances }}</small>
          </button>
          <span v-if="!domains.length" class="filter-empty">加载中…</span>
        </div>
      </div>

      <div v-if="error" class="card empty">
        <p>图谱接口不可用：{{ error }}</p>
        <button class="btn ghost" @click="loadNetwork">重试</button>
      </div>

      <div v-else class="graph-body">
        <div class="card graph-canvas">
          <div v-if="loading" class="canvas-loading">加载图谱数据…</div>
          <div ref="chartEl" class="chart" :class="{ dim: loading }" />
        </div>

        <aside class="card node-panel">
          <template v-if="nodeLoading">
            <p class="panel-empty">加载节点…</p>
          </template>
          <template v-else-if="selected">
            <div class="node-head">
              <span class="tag" :style="{ color: LABEL_COLOR[selected.label], borderColor: LABEL_COLOR[selected.label] }">
                {{ selected.label }}
              </span>
              <h3 class="node-name">{{ selected.name }}</h3>
            </div>
            <p class="node-desc">{{ selected.props && (selected.props.描述 || selected.props.desc) || '—' }}</p>

            <div v-if="formatProps(selected.props).length" class="node-props">
              <div v-for="p in formatProps(selected.props)" :key="p.k" class="prop-item">
                <span class="prop-k">{{ p.k }}</span>
                <span class="prop-v">{{ p.v }}</span>
              </div>
            </div>

            <div v-if="selected.label === '问题'" class="node-action">
              <button class="btn" @click="openResult(selected.name)">在结果页查看该问题</button>
            </div>

            <div class="rel-title">邻域关系（{{ selected.relations.length }}）</div>
            <ul class="rel-list">
              <li
                v-for="(rel, i) in selected.relations"
                :key="i"
                class="rel-item"
                @click="selectNode(rel.to.name)"
              >
                <span class="rel-dir" :class="rel.direction">↱</span>
                <span class="rel-type">{{ rel.type }}</span>
                <span class="rel-name">
                  {{ rel.to.name }}
                  <small>{{ rel.to.label }}</small>
                </span>
              </li>
            </ul>
          </template>
          <template v-else>
            <p class="panel-empty">点击图中任意节点，查看详情与关系</p>
          </template>
        </aside>
      </div>

      <div class="graph-legend">
        <span v-for="l in LABELS" :key="l" class="legend-item">
          <i :style="{ background: LABEL_COLOR[l] }" /> {{ LABEL_DESC[l] }}
        </span>
      </div>
    </div>
  </div>
</template>

<style scoped>
.graph-page {
  padding: 30px 0 20px;
}
.graph-head {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  gap: 16px;
  margin-bottom: 18px;
  flex-wrap: wrap;
}
.graph-title {
  font-size: 24px;
  font-weight: 800;
}
.graph-sub {
  font-size: 13px;
  color: var(--text-3);
  margin-top: 4px;
}
.graph-metrics {
  display: flex;
  gap: 10px;
}
.metric {
  font-size: 13px;
  font-weight: 700;
  color: var(--cyan);
  background: rgba(34, 211, 238, 0.08);
  border: 1px solid rgba(34, 211, 238, 0.25);
  padding: 6px 12px;
  border-radius: 999px;
}
.filter-bar {
  padding: 16px 18px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 18px;
}
.help-card {
  margin-bottom: 18px;
  padding: 4px 18px;
}
.help-toggle {
  display: flex;
  align-items: center;
  gap: 8px;
  background: transparent;
  border: none;
  cursor: pointer;
  color: var(--text-2);
  font-size: 14px;
  font-weight: 700;
  padding: 10px 0;
}
.help-icon {
  width: 18px;
  height: 18px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  font-size: 12px;
  font-weight: 800;
  color: var(--cyan);
  border: 1px solid rgba(34, 211, 238, 0.5);
}
.help-caret {
  transition: transform 0.2s ease;
  font-size: 11px;
}
.help-caret.open {
  transform: rotate(90deg);
}
.help-body {
  padding: 4px 4px 14px;
  border-top: 1px solid rgba(139, 165, 255, 0.1);
}
.help-list {
  padding-left: 18px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  font-size: 13px;
  color: var(--text-2);
  line-height: 1.7;
}
.help-list b {
  color: var(--text-1);
}
.filter-row {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.filter-search {
  flex: 1;
  min-width: 220px;
  background: rgba(13, 18, 38, 0.6);
  border: 1px solid rgba(139, 165, 255, 0.2);
  border-radius: 10px;
  padding: 10px 14px;
  color: var(--text-1);
  font-size: 14px;
}
.filter-search:focus {
  outline: none;
  border-color: var(--cyan);
}
.filter-label {
  font-size: 12px;
  color: var(--text-3);
  flex: none;
}
.chip {
  padding: 5px 12px;
  border-radius: 999px;
  font-size: 13px;
  color: var(--text-2);
  border: 1px solid rgba(139, 165, 255, 0.18);
  background: transparent;
  cursor: pointer;
  transition: all 0.15s ease;
}
.chip.active {
  border-color: var(--cyan);
  color: var(--cyan);
  background: rgba(34, 211, 238, 0.08);
}
.chip small {
  margin-left: 4px;
  opacity: 0.65;
  font-size: 11px;
}
.filter-empty {
  font-size: 12px;
  color: var(--text-3);
}
.graph-body {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 320px;
  gap: 18px;
}
.graph-canvas {
  position: relative;
  min-height: 640px;
  overflow: hidden;
}
.chart {
  width: 100%;
  height: 640px;
}
.chart.dim {
  opacity: 0.45;
  pointer-events: none;
}
.canvas-loading {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  color: var(--text-2);
  z-index: 2;
}
.node-panel {
  align-self: start;
  max-height: 640px;
  overflow-y: auto;
  padding: 18px;
}
.node-head {
  margin-bottom: 8px;
}
.tag {
  display: inline-block;
  font-size: 11px;
  font-weight: 700;
  padding: 2px 8px;
  border-radius: 6px;
  border: 1px solid;
  margin-bottom: 6px;
}
.node-name {
  font-size: 17px;
  font-weight: 800;
  line-height: 1.35;
}
.node-desc {
  font-size: 13px;
  color: var(--text-2);
  line-height: 1.6;
  margin-bottom: 10px;
}
.node-props {
  display: flex;
  flex-direction: column;
  gap: 5px;
  margin-bottom: 10px;
}
.prop-item {
  display: flex;
  gap: 8px;
  font-size: 12px;
}
.prop-k {
  color: var(--text-3);
  flex: none;
}
.prop-v {
  color: var(--text-1);
  word-break: break-all;
}
.node-action {
  margin: 10px 0;
}
.rel-title {
  font-size: 13px;
  font-weight: 800;
  color: var(--text-3);
  margin: 14px 0 8px;
}
.rel-list {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.rel-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  padding: 7px 10px;
  border-radius: 8px;
  cursor: pointer;
  border: 1px solid transparent;
  transition: all 0.15s ease;
}
.rel-item:hover {
  background: rgba(139, 165, 255, 0.07);
  border-color: rgba(139, 165, 255, 0.2);
}
.rel-dir {
  color: var(--text-3);
  flex: none;
}
.rel-type {
  font-size: 11px;
  color: #8b9cc8;
  background: rgba(139, 156, 200, 0.12);
  padding: 1px 6px;
  border-radius: 5px;
  flex: none;
}
.rel-name {
  color: var(--text-1);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.rel-name small {
  color: var(--text-3);
  margin-left: 4px;
  font-size: 11px;
}
.panel-empty {
  color: var(--text-3);
  font-size: 13px;
  text-align: center;
  padding: 30px 0;
}
.graph-legend {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
  margin-top: 18px;
  font-size: 12px;
  color: var(--text-3);
}
.legend-item {
  display: flex;
  align-items: center;
  gap: 6px;
}
.legend-item i {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  display: inline-block;
}
.btn {
  padding: 9px 20px;
  border-radius: 10px;
  font-size: 14px;
  font-weight: 700;
  color: #fff;
  background: linear-gradient(135deg, var(--cyan), var(--blue) 60%, var(--purple));
}
.btn.ghost {
  background: transparent;
  color: var(--text-2);
  border: 1px solid rgba(139, 165, 255, 0.2);
}
.empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 14px;
  padding: 40px 20px;
  color: var(--text-2);
}
@media (max-width: 960px) {
  .graph-body {
    grid-template-columns: 1fr;
  }
}
</style>