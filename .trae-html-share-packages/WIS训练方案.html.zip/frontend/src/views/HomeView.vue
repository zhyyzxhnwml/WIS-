<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import SearchBar from '../components/SearchBar.vue'
import { sampleQuestions } from '../data/mock.js'

const router = useRouter()

// 搜索提交：携带问题跳转到结果页
function onSearch(text) {
  router.push({ name: 'result', query: { q: text } })
}

// 页面统计数据的默认展示（后端不可用时的兜底）
const defaultStats = [
  { num: '500+', label: '知识图谱三元组' },
  { num: '2', label: '检索 + 生成双引擎' },
  { num: '40', label: 'TRIZ 发明原理' },
  { num: '100%', label: '推理路径可解释' }
]
const stats = ref(defaultStats)

const defaultExamples = sampleQuestions
const examples = ref(defaultExamples)

// 挂载后尝试从后端拉取真实的示例问题与统计数据，失败则保持默认展示
onMounted(async () => {
  try {
    const [samples, st] = await Promise.all([
      fetch('/api/samples').then((r) => r.json()),
      fetch('/api/stats').then((r) => r.json())
    ])
    // 后端有数据时才覆盖默认值
    if (Array.isArray(samples) && samples.length > 0) {
      examples.value = samples
    }
    if (st && typeof st === 'object' && st.nodes) {
      stats.value = [
        { num: `${st.relations}+`, label: '知识图谱三元组' },
        { num: '2', label: '检索 + 生成双引擎' },
        { num: `${st.triz}`, label: 'TRIZ 发明原理' },
        { num: `${st.domains}`, label: '覆盖领域' }
      ]
    }
  } catch (e) {
    // 后端不可用时保持默认展示
  }
})

// 核心能力卡片配置
const features = [
  {
    icon: '↗',
    title: '跨域知识重定向',
    desc: '将解决问题的“功能”抽象出来，基于 TRIZ 原理与知识图谱，在生物、机械、物理、材料等看似无关的领域中检索可迁移的隐喻与结构。',
    tag: 'TRIZ × 知识图谱'
  },
  {
    icon: '◎',
    title: '可解释推理路径',
    desc: '不只给出答案，更展示从“问题 → 功能 → 原理 → 概念 → 源领域实例 → 方案”的完整映射链，每一步都可点击溯源、值得信赖。',
    tag: '路径图 + 热力图'
  },
  {
    icon: '⚡',
    title: '双引擎协同生成',
    desc: '知识图谱精确检索保证结构严谨，大语言模型发散联想开创新思路。结构化与创造性的结合，让方案既扎实又惊艳。',
    tag: 'Neo4j + LLM API'
  }
]

// 「工作原理」步骤说明
const steps = [
  { no: '01', title: '描述问题', desc: '用一句自然语言描述你的技术难题：如何让无人机更抗冲击？', key: '输入' },
  { no: '02', title: '功能抽象', desc: 'InnoMap 将问题拆解为需要满足的核心功能：吸收冲击能量。', key: '意图识别' },
  { no: '03', title: '双引擎并行', desc: '知识图谱精确检索可借鉴原理，大模型发散联想跨域隐喻，并行执行。', key: '图谱 + LLM' },
  { no: '04', title: '融合 · 可视化', desc: '结果融合后生成带推理路径的创新方案，并用路径图与热力图呈现。', key: '可解释输出' }
]
</script>

<template>
  <div class="home">
    <!-- Hero -->
    <section class="hero">
      <div class="glow glow-a"></div>
      <div class="glow glow-b"></div>
      <div class="container hero-inner">
        <div class="hero-badge">
          <span class="dot"></span>
          面向大学生的跨领域 AI 创新伙伴
        </div>
        <h1 class="hero-title">
          打破领域壁垒
          <span class="gradient-text">看见创新可能</span>
        </h1>
        <p class="hero-sub">
          输入一个技术难题，InnoMap 从看似无关的领域中为你“重定向”灵感 ——<br />
          让不了解生物的工程师，也能从人体软骨中汲取无人机防护的设计灵感。
        </p>

        <SearchBar class="hero-search" size="lg" @submit="onSearch" />

        <div class="hero-stats">
          <div v-for="s in stats" :key="s.label" class="stat">
            <span class="stat-num gradient-text">{{ s.num }}</span>
            <span class="stat-label">{{ s.label }}</span>
          </div>
        </div>
      </div>
    </section>

    <!-- Examples -->
    <section class="section container">
      <h2 class="section-title">从这些例子开始</h2>
      <p class="section-sub">点击任一示例，观看跨领域灵感如何被“重定向”出来</p>
      <div class="example-grid">
        <article
          v-for="(ex, i) in examples"
          :key="ex.question"
          class="card example-card"
          tabindex="0"
          @click="onSearch(ex.question)"
          @keydown.enter="onSearch(ex.question)"
        >
          <div class="example-num">{{ String(i + 1).padStart(2, '0') }}</div>
          <h3 class="example-question">{{ ex.question }}</h3>
          <p class="example-desc">{{ ex.desc }}</p>
          <div class="example-tags">
            <span v-for="t in ex.tags" :key="t" class="tag">{{ t }}</span>
          </div>
          <span class="example-go">生成方案 <i>→</i></span>
        </article>
      </div>
    </section>

    <!-- Features -->
    <section id="features" class="section container">
      <h2 class="section-title">为什么是 InnoMap？</h2>
      <p class="section-sub">告别“同领域找答案”，开启跨领域找灵感</p>
      <div class="feature-grid">
        <article v-for="f in features" :key="f.title" class="card feature-card">
          <div class="feature-icon">{{ f.icon }}</div>
          <span class="tag feature-tag">{{ f.tag }}</span>
          <h3>{{ f.title }}</h3>
          <p>{{ f.desc }}</p>
        </article>
      </div>
    </section>

    <!-- How it works -->
    <section id="how" class="section container">
      <h2 class="section-title">工作原理</h2>
      <p class="section-sub">四步，把遥远领域里的答案“重定向”到你的问题</p>
      <div class="steps">
        <article v-for="(s, i) in steps" :key="s.no" class="step">
          <div class="step-node" :style="{ '--i': i }">{{ s.no }}</div>
          <h3>{{ s.title }}</h3>
          <p>{{ s.desc }}</p>
          <span class="step-key">{{ s.key }}</span>
        </article>
      </div>
    </section>

    <!-- CTA -->
    <section class="section container">
      <div class="card cta">
        <h2>有想法了吗？试试你自己的问题</h2>
        <p>把困扰你的技术难题交给 InnoMap，让跨领域灵感为你破局。</p>
        <SearchBar size="lg" @submit="onSearch" />
      </div>
    </section>
  </div>
</template>

<style scoped>
.hero {
  position: relative;
  overflow: hidden;
  padding: 84px 0 70px;
  text-align: center;
}

.glow {
  position: absolute;
  border-radius: 50%;
  filter: blur(90px);
  opacity: 0.5;
  pointer-events: none;
}
.glow-a {
  width: 460px;
  height: 460px;
  background: radial-gradient(circle, rgba(59, 130, 246, 0.55), transparent 70%);
  top: -160px;
  left: -80px;
}
.glow-b {
  width: 420px;
  height: 420px;
  background: radial-gradient(circle, rgba(236, 72, 153, 0.35), transparent 70%);
  bottom: -180px;
  right: -60px;
}

.hero-inner {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 7px 18px;
  border-radius: 999px;
  font-size: 13px;
  color: var(--text-2);
  border: 1px solid rgba(34, 211, 238, 0.3);
  background: rgba(34, 211, 238, 0.06);
  margin-bottom: 26px;
}
.hero-badge .dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--cyan);
  box-shadow: 0 0 10px var(--cyan);
  animation: pulse 2s ease-in-out infinite;
}

@keyframes pulse {
  0%,
  100% {
    opacity: 1;
  }
  50% {
    opacity: 0.35;
  }
}

.hero-title {
  font-size: clamp(34px, 5.4vw, 56px);
  font-weight: 800;
  letter-spacing: 2px;
  line-height: 1.25;
  margin-bottom: 18px;
}

.hero-sub {
  font-size: 16px;
  color: var(--text-2);
  line-height: 1.8;
  margin-bottom: 36px;
}

.hero-search {
  width: min(680px, 100%);
}

.hero-stats {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-top: 52px;
  width: min(720px, 100%);
}

.stat {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.stat-num {
  font-size: 28px;
  font-weight: 800;
}
.stat-label {
  font-size: 13px;
  color: var(--text-3);
}

.section {
  padding: 56px 0;
}

.example-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 22px;
}

.example-card {
  position: relative;
  padding: 28px 24px;
  overflow: hidden;
  cursor: pointer;
}
.example-card:hover {
  border-color: var(--card-border-hover);
  box-shadow: var(--shadow-glow);
  transform: translateY(-3px);
}

.example-num {
  position: absolute;
  top: 12px;
  right: 18px;
  font-size: 42px;
  font-weight: 800;
  color: rgba(139, 165, 255, 0.08);
}

.example-question {
  font-size: 19px;
  font-weight: 700;
  margin-bottom: 8px;
  color: var(--text-1);
}

.example-desc {
  font-size: 13.5px;
  color: var(--text-2);
  margin-bottom: 16px;
}

.example-tags {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.example-go {
  display: inline-block;
  margin-top: 18px;
  font-size: 14px;
  font-weight: 700;
  color: var(--cyan);
}
.example-go i {
  display: inline-block;
  transition: transform 0.2s ease;
  font-style: normal;
}
.example-card:hover .example-go i {
  transform: translateX(5px);
}

.feature-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 22px;
}

.feature-card {
  padding: 30px 26px;
}
.feature-card:hover {
  border-color: var(--card-border-hover);
  box-shadow: var(--shadow-glow);
}

.feature-icon {
  width: 52px;
  height: 52px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
  border-radius: 14px;
  margin-bottom: 18px;
  background: linear-gradient(135deg, rgba(34, 211, 238, 0.16), rgba(139, 92, 246, 0.16));
  border: 1px solid rgba(139, 165, 255, 0.3);
  color: var(--cyan);
}

.feature-tag {
  margin-bottom: 14px;
  display: inline-flex;
}

.feature-card h3 {
  font-size: 18px;
  margin-bottom: 10px;
}
.feature-card p {
  font-size: 14px;
  color: var(--text-2);
}

.steps {
  position: relative;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
}

.step {
  position: relative;
  background: var(--card);
  border: 1px solid var(--card-border);
  border-radius: var(--radius);
  padding: 26px 22px;
  transition: border-color 0.25s ease, transform 0.25s ease;
}
.step:hover {
  border-color: var(--card-border-hover);
  transform: translateY(-3px);
}

.step-node {
  position: relative;
  z-index: 1;
  width: 54px;
  height: 54px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 18px;
  font-size: 15px;
  font-weight: 800;
  border-radius: 50%;
  color: #fff;
  background: linear-gradient(135deg, var(--cyan), var(--blue), var(--purple));
  box-shadow: 0 0 18px rgba(59, 130, 246, 0.4);
}

.step h3 {
  font-size: 17px;
  margin-bottom: 8px;
}
.step p {
  font-size: 13px;
  color: var(--text-2);
  margin-bottom: 14px;
}
.step-key {
  font-size: 12px;
  color: var(--cyan);
  font-weight: 600;
}

.cta {
  padding: 48px 40px;
  text-align: center;
  background:
    linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(236, 72, 153, 0.08)),
    var(--card);
}
.cta h2 {
  font-size: 26px;
  margin-bottom: 8px;
}
.cta p {
  color: var(--text-2);
  margin-bottom: 26px;
}
.cta .search-bar {
  max-width: 640px;
  margin: 0 auto;
}

@media (max-width: 900px) {
  .example-grid,
  .feature-grid {
    grid-template-columns: 1fr;
  }
  .steps {
    grid-template-columns: 1fr;
  }
  .hero-stats {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>