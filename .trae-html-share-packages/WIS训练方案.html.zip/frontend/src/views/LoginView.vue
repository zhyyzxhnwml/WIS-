<script setup>
import { ref } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { api } from '../utils/api.js'

const router = useRouter()
const route = useRoute()

const mode = ref('login') // 当前模式：login / register
const username = ref('')
const password = ref('')
const nickname = ref('')
const error = ref('')
const loading = ref(false)

// 提交登录或注册
async function submit() {
  error.value = ''
  if (!username.value || !password.value) {
    error.value = '请填写用户名和密码'
    return
  }
  loading.value = true
  try {
    if (mode.value === 'login') {
      await api.login(username.value, password.value)
    } else {
      await api.register(username.value, password.value, nickname.value)
    }
    // 通知全局刷新导航栏用户信息
    window.dispatchEvent(new Event('innomap:login'))
    // 优先回跳到来源页，否则默认去历史页
    const target = typeof route.query.redirect === 'string' ? route.query.redirect : '/history'
    router.push(target)
  } catch (e) {
    error.value = e.message || '操作失败，请重试'
  } finally {
    loading.value = false
  }
}

// 切换登录/注册模式并清空错误提示
function switchMode(m) {
  mode.value = m
  error.value = ''
}
</script>

<template>
  <div class="login-page">
    <div class="login-wrap container">
      <div class="card login-card">
        <h2 class="login-title">
          {{ mode === 'login' ? '欢迎回来' : '创建账号' }}
        </h2>
        <p class="login-sub">
          {{ mode === 'login' ? '登录后使用搜索历史记录功能' : '注册后将自动登录' }}
        </p>

        <div class="tabs">
          <button class="tab" :class="{ on: mode === 'login' }" @click="switchMode('login')">登录</button>
          <button class="tab" :class="{ on: mode === 'register' }" @click="switchMode('register')">注册</button>
        </div>

        <form class="form" @submit.prevent="submit">
          <label class="field">
            <span>用户名</span>
            <input v-model="username" type="text" maxlength="50" autocomplete="username" placeholder="请输入用户名" />
          </label>

          <label v-if="mode === 'register'" class="field">
            <span>昵称（可选）</span>
            <input v-model="nickname" type="text" maxlength="50" autocomplete="nickname" placeholder="默认同用户名" />
          </label>

          <label class="field">
            <span>密码</span>
            <input v-model="password" type="password" maxlength="64" autocomplete="current-password" placeholder="至少 6 位" />
          </label>

          <p v-if="error" class="error">{{ error }}</p>

          <button class="submit" type="submit" :disabled="loading">
            {{ loading ? '处理中…' : mode === 'login' ? '登 录' : '注 册' }}
          </button>
        </form>
      </div>
    </div>
  </div>
</template>

<style scoped>
.login-page {
  padding: 70px 0;
}
.login-wrap {
  max-width: 420px;
}
.login-card {
  padding: 36px 32px 30px;
}
.login-title {
  font-size: 24px;
  font-weight: 800;
}
.login-sub {
  font-size: 13px;
  color: var(--text-3);
  margin: 6px 0 18px;
}
.tabs {
  display: flex;
  gap: 6px;
  margin-bottom: 20px;
  background: rgba(255, 255, 255, 0.04);
  border-radius: 10px;
  padding: 4px;
}
.tab {
  flex: 1;
  padding: 8px 0;
  font-size: 13px;
  font-weight: 700;
  color: var(--text-3);
  border-radius: 8px;
  transition: all 0.2s ease;
}
.tab.on {
  color: #fff;
  background: linear-gradient(135deg, rgba(59, 130, 246, 0.6), rgba(139, 92, 246, 0.6));
}
.form {
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  font-size: 13px;
  color: var(--text-2);
}
.field input {
  padding: 11px 14px;
  border-radius: 10px;
  border: 1px solid rgba(139, 165, 255, 0.18);
  background: rgba(255, 255, 255, 0.04);
  color: var(--text-1);
  font-size: 14px;
  outline: none;
  transition: border-color 0.2s ease;
}
.field input:focus {
  border-color: var(--cyan);
}
.error {
  font-size: 13px;
  color: #f87171;
}
.submit {
  margin-top: 6px;
  padding: 12px 0;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 800;
  color: #fff;
  background: linear-gradient(135deg, var(--cyan), var(--blue) 60%, var(--purple));
  box-shadow: 0 4px 16px rgba(59, 130, 246, 0.35);
  transition: transform 0.2s ease, opacity 0.2s ease;
}
.submit:hover {
  transform: translateY(-2px);
}
.submit:disabled {
  opacity: 0.6;
  transform: none;
}
</style>