<script setup>
import { ref, computed, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import SearchBar from '../components/SearchBar.vue'
import SchemeCard from '../components/SchemeCard.vue'
import ReasoningPanel from '../components/ReasoningPanel.vue'
import PathGraph from '../components/PathGraph.vue'
import Heatmap from '../components/Heatmap.vue'
import NodeDetail from '../components/NodeDetail.vue'
import { examples, findExample } from '../data/mock.js'
import { api } from '../utils/api.js'
import { getResult, putResult } from '../stores/results.js'

const route = useRoute()
const router = useRouter()

// 当前渲染的问题与展示状态
const currentQuestion = ref('')
const errorNote = ref('') // LLM 或接口的错误提示
const example = ref(examples[0]) // 当前展示的完整结果结构
const isDemo = ref(false) // 是否为演示兜底数据
const isFetching = ref(false) // 请求加载中
const activeLane = ref('') // 当前高亮的领域 lane
const activeNode = ref(null) // 当前选中的节点详情

// 获取问题结果：优先读缓存，未命中则请求后端并写入缓存
async function fetchExample(question) {
  const cached = getResult(question)
  if (cached) return cached
  const meta = await api.request('/api/search', {
    method: 'POST',
    body: {
      question,
      api_key: api.getDeepSeekKey() || '',
      provider: api.getLLMProvider(),
      model: api.getLLMModel()
    }
  })
  return putResult(question, meta)
}

// 加载指定问题的演示/真实结果
async function load(question) {
  // 无问题时回落到默认示例，并更新 url 保持可分享
  if (!question) {
    router.replace({ query: { q: examples[0].question } })
    return
  }
  currentQuestion.value = question
  isFetching.value = true
  errorNote.value = ''
  try {
    example.value = await fetchExample(question)
    isDemo.value = false
    // 后端可能附带 LLM 兜底失败提示，透传给用户
    if (example.value.llmError) errorNote.value = example.value.llmError
  } catch (e) {
    // 请求失败时回退到本地演示库，找不到则用首个示例结构兜底并标记为 demo
    errorNote.value = e.message || '图谱接口不可用'
    const hit = findExample(question)
    if (hit) {
      example.value = hit
      isDemo.value = false
    } else {
      example.value = {
        ...examples[0],
        question: question,
        id: 'custom'
      }
      isDemo.value = true
    }
  } finally {
    isFetching.value = false
  }
  // 重置选中状态：默认高亮第一个 lane、清空选中节点
  activeLane.value = example.value.lanes[0].id
  activeNode.value = null
}

// 监听地址栏 q 参数，进入页面或搜索新问题时自动加载（immediate 保证首次进入即触发）
watch(
  () => route.query.q,
  (q) => load(q),
  { immediate: true }
)

// 搜索提交：同一问题时忽略，否则跳转结果页带上新问题
function onSearch(text) {
  if (text === currentQuestion.value) return
  router.push({ name: 'result', query: { q: text } })
}

// 选择 lane：更新高亮并清空节点选中
function onSelectLane(laneId) {
  activeLane.value = laneId
  activeNode.value = null
}

// 点击路径图节点：若属于某 lane 则高亮并选中节点详情
function onNodeClick(payload) {
  if (payload.lane) {
    activeLane.value = payload.lane
  }
  activeNode.value = payload
}

// 当前选中的方案：联动完整推理链面板
const activeScheme = computed(() => {
  const found = example.value.schemes.find((s) => s.laneKey === activeLane.value)
  return found || example.value.schemes[0] || null
})

// 演示模式的说明文案
const demoNote = computed(() =>
  isDemo.value
    ? `未收录「${currentQuestion.value}」的演示数据，已用「${example.value.lanes[0].domain}」领域示例结构为你展示推理链路。`
    : ''
)

// 排除当前结果外的其余示例，作为页面底部「继续探索」入口
const otherExamples = computed(() =>
  examples.filter((e) => e.id !== example.value.id)
)

// 各节点类型的固定配色（用于图例）
const typeColor = {
  问题: '#22d3ee',
  功能: '#3b82f6',
  TRIZ原理: '#8b5cf6',
  跨域概念: '#a78bfa',
  源领域实例: '#ec4899',
  方案: '#8b5cf6'
}

// 取节点类型颜色，未知类型用默认灰蓝色
function glColor(type) {
  return typeColor[type] || '#6478b8'
}
</script>

<template>
  <div class="result">
    <div class="container">
      <!-- 顶部搜索栏 -->
      <section class="result-top card">
        <div class="result-top-left">
          <span class="label">当前问题</span>
          <h2 class="current-q">{{ currentQuestion }}</h2>
          <div v-if="demoNote" class="demo-note">{{ demoNote }}</div>
          <div v-if="errorNote" class="error-note">⚠ {{ errorNote }}（可在右上角「AI 模型」面板配置大模型后重试）</div>
        </div>
        <SearchBar
          class="result-search"
          size="md"
          :initial="currentQuestion"
          @submit="onSearch"
        />
      </section>

      <section v-if="isFetching" class="fetching-bar card">
        <span class="spinner"></span>
        正在跨领域检索与图谱重定向…
      </section>

      <!-- 摘要行 -->
      <section class="summary-row">
        <div class="card summary-card">
          <span class="summary-icon">⚙</span>
          <div>
            <span class="label">功能抽象</span>
            <p>{{ example.coreFunction }}</p>
          </div>
        </div>
        <div class="card summary-card">
          <span class="summary-icon">✧</span>
          <div>
            <span class="label">并行检索领域</span>
            <p class="domain-list">
              <span
                v-for="l in example.lanes"
                :key="l.id"
                class="domain-arrow"
                :style="{ color: l.color }"
              >
                {{ l.domain }}
              </span>
            </p>
          </div>
        </div>
        <div class="card summary-card">
          <span class="summary-icon">⚡</span>
          <div>
            <span class="label">生成方案数</span>
            <p>{{ example.schemes.length }} 个跨领域方案 · 融合生成</p>
          </div>
        </div>
      </section>

      <section class="result-grid">
        <!-- 左：方案建议 -->
        <aside class="col-schemes">
          <div class="panel-head">
            <h3>跨领域方案建议</h3>
            <span class="panel-hint">点击切换路径高亮</span>
          </div>
          <div class="scheme-list">
            <SchemeCard
              v-for="s in example.schemes"
              :key="s.laneKey"
              :scheme="s"
              :active="activeLane === s.laneKey"
              @select="onSelectLane"
            />
          </div>
        </aside>

        <!-- 中：路径图 -->
        <div class="col-graph">
          <div class="card graph-card">
            <div class="graph-head">
              <div>
                <h3>跨领域映射路径</h3>
                <p class="graph-sub">
                  问题 → 功能 → TRIZ 原理 → 跨域概念 → 源领域实例 → 融合方案
                </p>
              </div>
              <div class="lane-legend">
                <span
                  v-for="l in example.lanes"
                  :key="l.id"
                  class="legend-chip"
                  :class="{ on: activeLane === l.id }"
                  :style="{ '--lc': l.color }"
                  @click="onSelectLane(l.id)"
                >
                  {{ l.domain }}
                </span>
              </div>
            </div>
            <div class="graph-legend">
              <span v-for="t in ['问题', '功能', 'TRIZ原理', '跨域概念', '源领域实例', '方案']" :key="t" class="gl-item">
                <i class="gl-dot" :style="{ background: glColor(t) }"></i>{{ t }}
              </span>
              <span class="gl-tip">可拖拽/滚轮缩放</span>
            </div>
            <PathGraph
              :example="example"
              :active-lane="activeLane"
              @node-click="onNodeClick"
            />
          </div>

          <!-- 完整推理链：与映射路径平级的大模块，跟随选中方案联动 -->
          <ReasoningPanel v-if="activeScheme" :scheme="activeScheme" />
        </div>

        <!-- 右：节点详情 -->
        <aside class="col-side">
          <div class="card side-card">
            <div class="panel-head">
              <h3>节点详情</h3>
              <span class="panel-hint">点击路径图节点查看</span>
            </div>
            <NodeDetail :node="activeNode" />
          </div>
        </aside>
      </section>

      <!-- 底部：全宽灵感热力图 -->
      <section class="heat-section card">
        <div class="panel-head heat-head">
          <h3>灵感热力图</h3>
          <span class="panel-hint">领域 × 领域 跨域关联度，颜色越亮关联越强</span>
        </div>
        <Heatmap :heatmap="example.heatmap" />
      </section>

      <!-- 其他示例 -->
      <section class="more-section">
        <h3 class="more-title">继续探索其他示例</h3>
        <div class="more-grid">
          <button
            v-for="e in otherExamples"
            :key="e.id"
            class="more-card card"
            @click="onSearch(e.question)"
          >
            <span class="more-q">{{ e.question }}</span>
            <span class="more-arrow">→</span>
          </button>
        </div>
      </section>
    </div>
  </div>
</template>

<style scoped>
.result {
  padding: 26px 0 20px;
}

.result-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
  padding: 20px 26px;
}

.result-top-left .label {
  font-size: 12px;
  letter-spacing: 1px;
  color: var(--text-3);
}

.current-q {
  font-size: 22px;
  font-weight: 800;
  margin-top: 2px;
  line-height: 1.4;
}

.demo-note {
  font-size: 12px;
  color: var(--text-3);
  margin-top: 6px;
}

.error-note {
  font-size: 12px;
  color: var(--danger, #f87171);
  margin-top: 6px;
}

.result-search {
  width: min(420px, 100%);
  flex: none;
}

.fetching-bar {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px 20px;
  margin-bottom: 16px;
  font-size: 13px;
  color: var(--text-2);
}
.spinner {
  width: 14px;
  height: 14px;
  border: 2px solid rgba(34, 211, 238, 0.3);
  border-top-color: var(--cyan);
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.summary-row {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
  margin: 18px 0;
}

.summary-card {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 16px 20px;
}
.summary-icon {
  font-size: 22px;
}
.label {
  font-size: 12px;
  color: var(--text-3);
  letter-spacing: 1px;
}
.summary-card p {
  font-size: 15px;
  font-weight: 700;
  margin-top: 2px;
}
.domain-list {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}
.domain-arrow {
  font-weight: 800;
  font-size: 14px;
}

.result-grid {
  display: grid;
  grid-template-columns: 300px 1fr 300px;
  gap: 16px;
  align-items: start;
}

.panel-head {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  margin-bottom: 12px;
  padding: 0 4px;
}
.panel-head h3 {
  font-size: 17px;
  font-weight: 700;
}
.panel-hint {
  font-size: 12px;
  color: var(--text-3);
}

.scheme-list {
  display: flex;
  flex-direction: column;
  gap: 14px;
  max-height: 680px;
  overflow-y: auto;
  padding-right: 4px;
}

.graph-card {
  padding: 20px 18px 10px;
}

.graph-head {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 14px;
  flex-wrap: wrap;
  padding: 0 6px;
}
.graph-head h3 {
  font-size: 17px;
  font-weight: 700;
}
.graph-sub {
  font-size: 12.5px;
  color: var(--text-3);
  margin-top: 2px;
}

.lane-legend {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
.legend-chip {
  padding: 3px 14px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 700;
  border: 1px solid var(--lc);
  color: var(--lc);
  cursor: pointer;
  opacity: 0.55;
  transition: opacity 0.2s ease, background 0.2s ease;
}
.legend-chip.on {
  opacity: 1;
  background: color-mix(in srgb, var(--lc) 16%, transparent);
  box-shadow: 0 0 12px color-mix(in srgb, var(--lc) 40%, transparent);
}

.graph-legend {
  display: flex;
  align-items: center;
  gap: 14px;
  flex-wrap: wrap;
  padding: 10px 8px 0;
  border-top: 1px solid rgba(139, 165, 255, 0.1);
  margin-top: 12px;
}
.gl-item {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: var(--text-2);
}
.gl-dot {
  width: 9px;
  height: 9px;
  border-radius: 3px;
}
.gl-tip {
  margin-left: auto;
  font-size: 11px;
  color: var(--text-3);
}

.side-card {
  padding: 18px;
}

.heat-section {
  margin-top: 18px;
  padding: 18px 20px 20px;
}
.heat-head {
  margin-bottom: 10px;
  padding: 0 4px;
}

.more-section {
  margin-top: 30px;
}
.more-title {
  font-size: 17px;
  font-weight: 700;
  margin-bottom: 12px;
}
.more-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 14px;
}
.more-card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  cursor: pointer;
  text-align: left;
}
.more-card:hover {
  border-color: var(--card-border-hover);
  transform: translateY(-2px);
}
.more-q {
  font-size: 15px;
  font-weight: 700;
}
.more-arrow {
  color: var(--cyan);
  font-size: 18px;
  transition: transform 0.2s ease;
}
.more-card:hover .more-arrow {
  transform: translateX(4px);
}

@media (max-width: 1080px) {
  .result-grid {
    grid-template-columns: 1fr;
  }
  .summary-row {
    grid-template-columns: 1fr;
  }
}
@media (max-width: 720px) {
  .result-top {
    flex-direction: column;
    align-items: stretch;
  }
  .result-search {
    width: 100%;
  }
  .more-grid {
    grid-template-columns: 1fr;
  }
}
</style>