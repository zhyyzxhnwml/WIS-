<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { api } from '../utils/api.js'
import { cacheKey, putResult } from '../stores/results.js'

const router = useRouter()
const records = ref([]) // 检索历史列表
const error = ref('')
const loading = ref(false)
const user = ref(api.getUser())

// 根据令牌判断是否已登录
const loggedIn = computed(() => api.isLoggedIn())

onMounted(loadHistory)

// 加载当前用户的历史记录
async function loadHistory() {
  if (!loggedIn.value) return
  loading.value = true
  error.value = ''
  try {
    records.value = await api.request('/api/history')
  } catch (e) {
    error.value = e.message
  } finally {
    loading.value = false
  }
}

// 打开某条历史：拉取完整结果写入缓存后跳转结果页
async function openRecord(rec) {
  try {
    const meta = await api.request(`/api/history/${rec.id}`)
    putResult(rec.question, meta)
    router.push({ name: 'result', query: { q: rec.question } })
  } catch (e) {
    error.value = e.message
  }
}

// 将 ISO 时间格式化为「YYYY-MM-DD HH:mm:ss」
function formatTime(t) {
  if (!t) return ''
  return String(t).replace('T', ' ').slice(0, 19)
}

// 跳转登录页，并携带回跳地址
function goLogin() {
  router.push({ name: 'login', query: { redirect: '/history' } })
}

// 退出登录：清空本地会话并通知全局刷新用户状态
function logout() {
  api.logout()
  user.value = null
  window.dispatchEvent(new Event('innomap:login'))
}
</script>

<template>
  <div class="history-page">
    <div class="container">
      <div class="history-head">
        <h2 class="history-title">我的检索历史</h2>
        <span v-if="loggedIn" class="history-count">共 {{ records.length }} 条</span>
      </div>

      <div v-if="!loggedIn" class="card empty">
        <p>未登录，无法查看历史记录。</p>
        <button class="btn" @click="goLogin">去登录 / 注册</button>
      </div>

      <div v-else-if="loading" class="card empty">加载中…</div>

      <div v-else-if="error" class="card empty">
        <p>{{ error }}</p>
        <button class="btn" @click="loadHistory">重试</button>
      </div>

      <div v-else-if="records.length === 0" class="card empty">
        <p>暂无检索记录。去尝试一次创新问题搜索吧！</p>
        <button class="btn" @click="router.push({ name: 'home' })">回首页搜一搜</button>
      </div>

      <ul v-else class="history-list">
        <li
          v-for="r in records"
          :key="r.id"
          class="card history-item"
          @click="openRecord(r)"
        >
          <div class="item-text">
            <span class="item-q">{{ r.question }}</span>
            <span class="item-time">{{ formatTime(r.created_at) }}</span>
          </div>
          <span class="item-go">查看 <i>→</i></span>
        </li>
      </ul>

      <div v-if="loggedIn" class="history-foot">
        <span class="who">当前用户：{{ user && user.nickname }}</span>
        <button class="btn ghost" @click="logout">退出登录</button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.history-page {
  padding: 34px 0 20px;
}
.history-head {
  display: flex;
  align-items: baseline;
  gap: 14px;
  margin-bottom: 18px;
}
.history-title {
  font-size: 24px;
  font-weight: 800;
}
.history-count {
  font-size: 13px;
  color: var(--text-3);
}
.history-list {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.history-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 14px;
  padding: 16px 20px;
  cursor: pointer;
  transition: border-color 0.2s ease, transform 0.2s ease;
}
.history-item:hover {
  border-color: var(--card-border-hover);
  transform: translateX(3px);
}
.item-text {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.item-q {
  font-size: 15px;
  font-weight: 700;
}
.item-time {
  font-size: 12px;
  color: var(--text-3);
}
.item-go {
  color: var(--cyan);
  font-size: 13px;
  font-weight: 700;
  flex: none;
}
.item-go i {
  font-style: normal;
}
.empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 14px;
  padding: 48px 20px;
  text-align: center;
}
.empty p {
  color: var(--text-2);
  font-size: 14px;
}
.btn {
  padding: 10px 22px;
  border-radius: 10px;
  font-size: 14px;
  font-weight: 700;
  color: #fff;
  background: linear-gradient(135deg, var(--cyan), var(--blue) 60%, var(--purple));
}
.btn.ghost {
  background: transparent;
  color: var(--text-2);
  border: 1px solid rgba(139, 165, 255, 0.2);
}
.history-foot {
  margin-top: 22px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 13px;
  color: var(--text-3);
}
</style>