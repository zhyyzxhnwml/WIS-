// 演示 / 兜底数据：当后端不可用时，前端仍能展示完整的跨领域映射演示
// 技术栈约定：数据结构与后端接口返回的 meta 保持一致

// 各领域在可视化中的主题色
export const domainColors = {
  生物: '#34d399',
  机械: '#f59e0b',
  物理: '#22d3ee',
  材料: '#ec4899',
  化工: '#f97316',
  算法: '#a78bfa'
}

// 前端口径兜底：为缺失 reasoning 的 lane 生成与后端同结构的推理链
function mockReasoning(meta, lane) {
  return [
    { step: '问题定位', text: `问题「${meta.question}」：${meta.scene || '需要跨领域寻求创新解法。'}` },
    { step: '功能抽象', text: `将问题抽象为底层功能「${meta.coreFunction}」——${meta.functionDesc || ''}` },
    { step: '矛盾识别', text: `技术矛盾：若沿用常规手段去强化「${meta.coreFunction}」，必然以成本或可制造性的上升为代价；物理矛盾：理想解要求关键部件兼具对立属性，既要借助「${lane.concept}」这类机制的独特优势，又不能在${lane.domain}场景中增加代价。`, tag: '矛盾' },
    { step: '原理推演', text: `针对该矛盾调用 TRIZ 发明原理「${lane.triz}」${lane.trizNo || ''}：${lane.principleDesc || ''}` },
    { step: '概念中介', text: `将原理具体化为通用工程隐喻「${lane.concept}」——${lane.conceptDesc || ''}` },
    { step: '源域类比', text: `在${lane.domain}领域找到实现该隐喻的成熟参照「${lane.instance}」：${lane.instanceDesc || ''}` },
    { step: '跨域映射', text: `沿「${lane.concept}→${lane.instance}」完成柔性映射并落到目标问题：${lane.explanation || ''}` },
    { step: '方案定型', text: `形成融合方案「${lane.schemeTitle}」，预计增益：${(lane.gains || []).join('；') || '待工程实测验证。'}` }
  ]
}

// 为一个 lane（领域行）生成三个路径节点：TRIZ 原理 → 跨域概念 → 源领域实例
// 三者沿同一水平线（laneY）按不同 x 排列，形成「重定向」路径
function laneNodes(lane, laneY) {
  // 给节点挂载点击详情数据，并记录所属 lane 用于路径高亮
  const payload = (p) => ({ ...p, lane: lane.key })
  return [
    {
      id: `${lane.key}_triz`,
      name: `${lane.triz}\n(${lane.trizNo})`,
      type: 'TRIZ原理',
      x: 40,
      y: laneY,
      symbolSize: 24,
      color: lane.color,
      payload: payload({
        title: lane.triz,
        typeLabel: 'TRIZ 发明原理',
        domain: lane.domain,
        detail: lane.principleDesc
      })
    },
    {
      id: `${lane.key}_concept`,
      name: lane.concept,
      type: '跨域概念',
      x: 59,
      y: laneY,
      symbolSize: 27,
      color: lane.color,
      payload: payload({
        title: lane.concept,
        typeLabel: '抽象隐喻·跨域概念',
        domain: lane.domain,
        detail: lane.conceptDesc
      })
    },
    {
      id: `${lane.key}_instance`,
      name: lane.instance,
      type: '源领域实例',
      x: 79,
      y: laneY,
      symbolSize: 30,
      color: lane.color,
      payload: payload({
        title: lane.instance,
        typeLabel: '源领域灵感实例',
        domain: lane.domain,
        detail: lane.instanceDesc,
        weight: lane.weight
      })
    }
  ]
}

// 将接口返回的 meta 规范化为前端渲染所需的完整结果结构：
// 组装问题/功能节点、各领域路径节点、连线与热力图数据
export function buildExample(meta) {
  // 起始节点：用户问题 与 抽象出的核心功能
  const nodes = [
    {
      id: 'q',
      name: meta.question,
      type: '问题',
      x: 3,
      y: 50,
      symbolSize: 34,
      color: '#22d3ee',
      payload: { title: '技术问题', typeLabel: '用户输入', detail: meta.scene }
    },
    {
      id: 'f',
      name: meta.coreFunction,
      type: '功能',
      x: 21,
      y: 50,
      symbolSize: 29,
      color: '#3b82f6',
      payload: { title: '功能抽象', typeLabel: '需求拆解', detail: meta.functionDesc }
    }
  ]

  // 汇总所有领域的路径节点
  const lanes = meta.lanes.flatMap((lane, i) => laneNodes(lane, lane.laneY[i]))

  nodes.push(...lanes, {
    id: 'scheme',
    name: '融合创新方案',
    type: '方案',
    x: 96,
    y: 50,
    symbolSize: 42,
    color: '#8b5cf6',
    payload: {
      title: '融合创新方案',
      typeLabel: '方案汇聚',
      detail: meta.schemeDesc
    }
  })

  // 连线：问题→功能，以及每个领域内的 原理→概念→实例→方案 三段路径
  const links = [
    { source: 'q', target: 'f', label: '具备功能', color: '#6478b8', weight: 1 }
  ]
  meta.lanes.forEach((lane, i) => {
    const laneY = lane.laneY[i]
    // redirect 标记的连线表示「跨域重定向」，渲染时会着重加粗高亮
    const laneLinks = [
      { source: 'f', target: `${lane.key}_triz`, label: '图谱匹配', color: '#6478b8', weight: 0.9 },
      { source: `${lane.key}_triz`, target: `${lane.key}_concept`, label: '启发', color: '#6478b8', weight: 0.88 },
      { source: `${lane.key}_concept`, target: `${lane.key}_instance`, label: `重定向 · ${lane.weight.toFixed(2)}`, color: lane.color, weight: lane.weight, redirect: true },
      { source: `${lane.key}_instance`, target: 'scheme', label: '融合', color: '#7c6bd8', weight: 0.85 }
    ]
    laneLinks.forEach((l) => {
      links.push({ ...l, lane: lane.key })
    })
  })

  // 返回规范化的完整结果：含核心字段、节点连线（graph）、热力图（heatmap）与方案卡片数据
  return {
    id: meta.id,
    question: meta.question,
    coreFunction: meta.coreFunction,
    scene: meta.scene,
    functionDesc: meta.functionDesc,
    schemeDesc: meta.schemeDesc,
    // lanes：对外只保留渲染与展示所需字段，丢弃内部的布局坐标 laneY
    lanes: meta.lanes.map((l) => ({ ...l, laneY: undefined })).map((l) => ({
      id: l.key,
      domain: l.domain,
      color: l.color,
      triz: l.triz,
      trizNo: l.trizNo,
      concept: l.concept,
      instance: l.instance,
      weight: l.weight,
      schemeTitle: l.schemeTitle,
      schemeScore: l.schemeScore,
      explanation: l.explanation,
      annotation: l.annotation,
      reasoning: l.reasoning || mockReasoning(meta, l)
    })),
    // schemes：汇总每个领域的融合方案卡片数据（用于左侧方案列表）
    schemes: meta.lanes.map((l) => ({
      laneKey: l.key,
      domain: l.domain,
      color: l.color,
      title: l.schemeTitle,
      triz: l.triz,
      instance: l.instance,
      score: l.schemeScore,
      weight: l.weight,
      explanation: l.explanation,
      gains: l.gains,
      annotation: l.annotation,
      reasoning: l.reasoning || mockReasoning(meta, l)
    })),
    graph: { nodes, links },
    heatmap: {
      domains: meta.heatmap.domains,
      matrix: meta.heatmap.matrix
    }
  }
}

export const examples = [
  buildExample({
    id: 'drone',
    question: '如何让无人机更抗冲击？',
    scene: '户外作业频繁炸机，机臂与桨叶在撞击时易折断，希望提升整机抗冲击与耐撞能力。',
    coreFunction: '吸收冲击能量',
    functionDesc: '将“抗冲击”抽象为需要实现的底层功能：在碰撞瞬间高效吸收并耗散冲击动能，保护关键结构。',
    schemeDesc: '融合生物软骨弹性缓冲、F1 溃缩吸能、泡沫胞元压溃吸能与剪切增稠智能材料，构建多尺度吸能的仿生抗冲击结构体系。',
    lanes: [
      {
        key: 'bio', domain: '生物', color: '#34d399', laneY: [28, 43, 57, 72],
        triz: '缓冲原理', trizNo: '9',
        concept: '弹性缓冲', conceptDesc: '以可变形弹性元件吸收冲击动能的通用隐喻。',
        instance: '人体软骨减震结构', weight: 0.87,
        instanceDesc: '关节软骨由多孔弹性组织构成，通过变形与孔穴压缩吸收冲击、保护骨骼，载荷越大减速越平缓。',
        principleDesc: '缓冲原理：利用弹性元件的受压形变将冲击动能转化为形变能并缓慢释放。',
        schemeTitle: '仿生弹性缓冲无人机框架', schemeScore: 92,
        explanation: '在机臂与机身连接处加入仿软骨多孔弹性构件，撞击时通过大形变缓慢吸收动能。',
        gains: ['抗冲击载荷提升约 42%', '续航影响小于 4%']
      },
      {
        key: 'mech', domain: '机械', color: '#f59e0b', laneY: [28, 43, 57, 72],
        triz: '预作用原理', trizNo: '10',
        concept: '预先吸能', conceptDesc: '在冲击发生前预设可有序溃缩的吸能通道。',
        instance: 'F1 赛车溃缩吸能结构', weight: 0.82,
        instanceDesc: 'F1 单体壳通过蜂窝状溃缩区在碰撞中有序变形、逐级吸收能量，保证驾驶舱安全。',
        principleDesc: '预作用原理：提前布置一套可在冲击时按预定路径形变的能量耗散系统。',
        schemeTitle: '多胞溃缩吸能起落架', schemeScore: 88,
        explanation: '在起落架与电池舱外侧设计六边形胞元溃缩区，落地撞击时逐级变形吸能。',
        gains: ['硬着陆吸能提升 35%', '结构增重仅 60g']
      },
      {
        key: 'phy', domain: '物理', color: '#22d3ee', laneY: [28, 43, 57, 72],
        triz: '多孔材料原理', trizNo: '31',
        concept: '泡沫胞元吸能', conceptDesc: '多孔材料在压溃阶段保持近乎恒定的应力平台，稳定消耗冲击功。',
        instance: '泡沫铝应力-应变平台', weight: 0.79,
        instanceDesc: '泡沫铝在压溃阶段应力几乎不随应变增长，形成“应力平台”，可稳定吸收大量冲击能。',
        principleDesc: '多孔材料原理：利用多孔/蜂窝结构的压溃平台来耗散能量。',
        schemeTitle: '泡沫夹芯复合机臂', schemeScore: 84,
        explanation: '机臂采用泡沫铝夹芯结构，利用压溃平台稳定吸能，同时保持轻量化。',
        gains: ['单位质量吸能提高 30%', '重量减轻 12%']
      },
      {
        key: 'mat', domain: '材料', color: '#ec4899', laneY: [28, 43, 57, 72],
        triz: '复合材料原理', trizNo: '40',
        concept: '智能变刚度', conceptDesc: '材料随应变率改变刚度——缓冲击柔、猛击骤硬。',
        instance: 'D3O 剪切增稠材料', weight: 0.85,
        instanceDesc: 'D3O 在慢速弯折时柔软可弯曲，高速冲击时分子链锁紧变得坚硬，是优秀的护具材料。',
        principleDesc: '复合材料原理：由多种材料复合，获得单一材料无法兼具的性能。',
        schemeTitle: '剪切增稠防护桨罩', schemeScore: 90,
        explanation: '桨罩与机身蒙皮采用剪切增稠材料，日常柔韧不碍事，撞击瞬间骤硬保护桨叶。',
        gains: ['桨叶损坏率降低约 50%', '生产良率保持 97%']
      }
    ],
    heatmap: {
      domains: ['航空', '生物', '机械', '物理', '材料', '算法'],
      matrix: [
        [100, 62, 71, 58, 54, 40],
        [62, 100, 48, 55, 44, 30],
        [71, 48, 100, 67, 61, 52],
        [58, 55, 67, 100, 66, 45],
        [54, 44, 61, 66, 100, 38],
        [40, 30, 52, 45, 38, 100]
      ]
    }
  }),

  buildExample({
    id: 'insulation',
    question: '如何让建筑物外墙更保温？',
    scene: '老旧建筑外墙保温性能差、冬冷夏热，空调能耗高，希望低成本提升墙体热阻。',
    coreFunction: '延缓热量传导',
    functionDesc: '将“保温”抽象为底层功能：大幅提升墙体热阻，延缓室内外热量的传导速率。',
    schemeDesc: '融合北极熊中空毛发的空气层隔热、蜂巢多孔、真空腔体与相变蓄热技术，构建多机理协同的外墙保温体系。',
    lanes: [
      {
        key: 'bio', domain: '生物', color: '#34d399', laneY: [28, 43, 57, 72],
        triz: '嵌套原理', trizNo: '7',
        concept: '空气层隔热', conceptDesc: '用静止空气层阻断热传导路径。',
        instance: '北极熊中空毛发', weight: 0.9,
        instanceDesc: '北极熊毛发中空，内裹空气形成极佳隔热层，在极地仍能保温不散热。',
        principleDesc: '嵌套原理：将一个结构置于另一个结构之中，形成多层复合隔热。',
        schemeTitle: '仿北极熊中空纤维保温层', schemeScore: 90,
        explanation: '仿照中空毛发结构，在墙体内衬铺设中空纤维层，利用静止空气层大幅提升热阻。',
        gains: ['热阻提升约 45%', '成本仅为聚氨酯的 60%']
      },
      {
        key: 'mat', domain: '材料', color: '#ec4899', laneY: [28, 43, 57, 72],
        triz: '多孔材料原理', trizNo: '31',
        concept: '多孔隔热', conceptDesc: '密集微孔封存空气，阻断对流与传导。',
        instance: '蜂巢多孔结构', weight: 0.83,
        instanceDesc: '蜂巢六边形胞元在极高强度下保持大量中空体积，兼具结构承载与隔热作用。',
        principleDesc: '多孔材料原理：以含大量微小气孔的材料实现隔热与轻量化。',
        schemeTitle: '蜂巢多孔复合保温墙板', schemeScore: 86,
        explanation: '采用蜂巢芯板+保温芯材复合墙板，兼顾强度与隔热，且可工厂预制。',
        gains: ['保温性能提升 38%', '墙体减重 20%']
      },
      {
        key: 'phy', domain: '物理', color: '#22d3ee', laneY: [28, 43, 57, 72],
        triz: '预作用原理', trizNo: '10',
        concept: '真空腔体', conceptDesc: '抽空空气消除传导与对流，仅剩微弱辐射换热。',
        instance: '保温瓶真空夹层', weight: 0.81,
        instanceDesc: '保温瓶内外壁之间的真空夹层几乎完全阻断热传导与热对流，保温效果卓越。',
        principleDesc: '预作用原理：预先预留真空腔体，从源头切断传导与对流两大传热途径。',
        schemeTitle: '真空腔体模块化幕墙', schemeScore: 82,
        explanation: '将保温瓶原理引入幕墙，采用真空玻璃+模块化真空板，热工表现优异。',
        gains: ['传热系数低至 0.5 W/(m²·K)', '模块化施工提速 30%']
      },
      {
        key: 'chem', domain: '化工', color: '#f97316', laneY: [28, 43, 57, 72],
        triz: '复合材料原理', trizNo: '40',
        concept: '相变蓄热', conceptDesc: '利用相变潜热在夜间蓄能、日间释放，平滑温度波动。',
        instance: '石蜡相变微胶囊', weight: 0.84,
        instanceDesc: '石蜡微胶囊在特定温度发生固液相变并吸收/释放大量潜热，广泛用于建筑调温。',
        principleDesc: '复合材料原理：将相变材料包埋后复合到墙面，获得调节温度的新能力。',
        schemeTitle: '相变蓄热内墙涂层', schemeScore: 88,
        explanation: '内墙施加含微胶囊的相变涂层，白天吸收多余热量、夜间缓慢释放，稳定室温。',
        gains: ['室温波动减小 6℃', '空调节能约 22%']
      }
    ],
    heatmap: {
      domains: ['建筑', '生物', '材料', '物理', '化工'],
      matrix: [
        [100, 70, 66, 64, 60],
        [70, 100, 42, 40, 35],
        [66, 42, 100, 62, 68],
        [64, 40, 62, 100, 55],
        [60, 35, 68, 55, 100]
      ]
    }
  }),

  buildExample({
    id: 'backpack',
    question: '如何让背包更轻便易收纳？',
    scene: '差旅用户希望背包空置时能折叠收纳进小空间，满装时又能提供足够支撑与防护。',
    coreFunction: '压缩占空体积',
    functionDesc: '将“轻便易收纳”抽象为底层功能：在非使用状态下显著压缩所占空间，同时不牺牲承载能力。',
    schemeDesc: '融合折纸折展机构、鸟翼收展形态、真空压缩与碳纤维超轻骨架，实现负载与便携的协同优化。',
    lanes: [
      {
        key: 'mech', domain: '机械', color: '#f59e0b', laneY: [28, 43, 57, 72],
        triz: '分割原理', trizNo: '1',
        concept: '折展机构', conceptDesc: '将刚性面板分割连接为可折叠机构，展开成结构、折叠成平面。',
        instance: '折纸 Origami 结构', weight: 0.93,
        instanceDesc: 'Origami 折叠结构可将大面板折叠为极小体积，常用于卫星太阳翼与便携结构。',
        principleDesc: '分割原理：把整体分割为若干可相对运动的单元，实现展开与折叠两种形态。',
        schemeTitle: '折纸折叠背包骨架', schemeScore: 94,
        explanation: '背包骨架采用折纸机构，空包一按即平、展开即挺，收纳体积压缩近 70%。',
        gains: ['收纳体积减小 68%', '展开强度保持 92%']
      },
      {
        key: 'bio', domain: '生物', color: '#34d399', laneY: [28, 43, 57, 72],
        triz: '动态化原理', trizNo: '15',
        concept: '收展形态', conceptDesc: '让结构能随使用状态动态切换紧凑与展开形态。',
        instance: '鸟类翅翼收拢', weight: 0.78,
        instanceDesc: '鸟类翅翼在飞行中展开、休息时收拢贴合身体，以最小空间完成形态切换。',
        principleDesc: '动态化原理：使物体或其部件可按需改变形态、位置或状态。',
        schemeTitle: '仿鸟翼收展背负系统', schemeScore: 85,
        explanation: '借鉴鸟翼收拢，背负系统可在收纳时贴合压缩、承载时展开支撑，分散压力。',
        gains: ['收纳更紧凑 25%', '肩部压强降低 18%']
      },
      {
        key: 'phy', domain: '物理', color: '#22d3ee', laneY: [28, 43, 57, 72],
        triz: '气动液压结构原理', trizNo: '29',
        concept: '真空压缩', conceptDesc: '以大气压差压缩包裹内部空气，大幅缩减体积。',
        instance: '真空收纳袋', weight: 0.8,
        instanceDesc: '真空收纳袋排除内部空气后，依靠大气压将体积压缩至原来的三分之一。',
        principleDesc: '气动液压结构原理：利用气体压力代替实体机构完成操作与压缩。',
        schemeTitle: '内置真空压缩模块', schemeScore: 79,
        explanation: '背包夹层内置单向气阀，收纳时手动排气压缩，满装时充气恢复撑形。',
        gains: ['衣物体积压缩 60%', '无需外接设备']
      },
      {
        key: 'mat', domain: '材料', color: '#ec4899', laneY: [28, 43, 57, 72],
        triz: '重量补偿原理', trizNo: '8',
        concept: '超轻骨架', conceptDesc: '以高强度低密度材料顶替金属，减轻本体重量。',
        instance: '碳纤维桁架结构', weight: 0.76,
        instanceDesc: '碳纤维复合材料比强度约为钢的 5 倍，桁架结构以最少材料获得刚性。',
        principleDesc: '重量补偿原理：用更轻的高性能材料与结构弥补重力或自重带来的负担。',
        schemeTitle: '碳纤维超轻骨架背包', schemeScore: 80,
        explanation: '骨架改用碳纤维桁架，整包减重明显，同时提升重载下的抗变形能力。',
        gains: ['整包减重 28%', '承载提高 15%']
      }
    ],
    heatmap: {
      domains: ['出行', '机械', '生物', '物理', '材料'],
      matrix: [
        [100, 68, 55, 50, 62],
        [68, 100, 46, 58, 70],
        [55, 46, 100, 38, 30],
        [50, 58, 38, 100, 48],
        [62, 70, 30, 48, 100]
      ]
    }
  })
]

// 首页「从这些例子开始」展示的示例问题
export const sampleQuestions = [
  {
    question: '如何让无人机更抗冲击？',
    desc: '户外作业频繁炸机，希望提升整机耐撞能力',
    tags: ['飞行器', '材料', '结构']
  },
  {
    question: '如何让建筑物外墙更保温？',
    desc: '老旧建筑冬冷夏热，希望低成本提升热阻',
    tags: ['建筑', '能源', '材料']
  },
  {
    question: '如何让背包更轻便易收纳？',
    desc: '差旅场景下希望空包可折叠、满载有支撑',
    tags: ['出行', '机械', '折叠']
  }
]

// 按规范化后的问题文本在演示库中查找对应的示例结果，用于后端不可用时的兜底
export function findExample(question) {
  // 去掉问号并去除首尾空白后精确匹配
  const q = String(question || '').replace(/[？?]/g, '').trim()
  if (!q) return null
  const hit = examples.find((e) => e.question.replace(/[？?]/g, '').trim() === q)
  return hit || null
}