// 应用入口：创建 Vue 应用实例并挂载到页面
import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import './styles/global.css'

// 挂载根组件，注册路由插件后渲染到 #app 节点
createApp(App).use(router).mount('#app')