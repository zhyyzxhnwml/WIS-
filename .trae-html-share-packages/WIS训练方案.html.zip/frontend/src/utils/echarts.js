// ECharts 按需引入：只注册本平台用到的图表(关系图/热力图)与基础组件，以减小打包体积
import * as echarts from 'echarts/core'
import { GraphChart, HeatmapChart } from 'echarts/charts'
import {
  TooltipComponent,
  GridComponent,
  VisualMapComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'

// 注册所需的图表类型、组件与渲染器
echarts.use([
  GraphChart, // 关系图（路径图 / 图谱网络）
  HeatmapChart, // 热力图（领域关联度）
  TooltipComponent, // 悬浮提示
  GridComponent, // 网格坐标
  VisualMapComponent, // 视觉映射（热力图颜色分段）
  CanvasRenderer // 使用 Canvas 渲染，适配大规模节点
])

export default echarts