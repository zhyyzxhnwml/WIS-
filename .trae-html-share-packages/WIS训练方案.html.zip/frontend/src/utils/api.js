// API 工具模块：封装 localStorage 存储与后端 HTTP 请求
// 负责登录态、AI 模型配置（DeepSeek Key / Ollama 模型）、图谱接口的统一访问

// localStorage 中各类数据的键名
const TOKEN_KEY = 'innomap_token'
const USER_KEY = 'innomap_user'
const DEEPSEEK_KEY_STORAGE = 'innomap_deepseek_api_key'
const LLM_PROVIDER_STORAGE = 'innomap_llm_provider'
const LLM_MODEL_STORAGE = 'innomap_llm_model'

export const api = {
  // ---- 登录令牌 ----
  getToken() {
    return localStorage.getItem(TOKEN_KEY)
  },
  setToken(token) {
    if (token) localStorage.setItem(TOKEN_KEY, token)
    else localStorage.removeItem(TOKEN_KEY)
  },
  // ---- DeepSeek API Key ----
  getDeepSeekKey() {
    return localStorage.getItem(DEEPSEEK_KEY_STORAGE)
  },
  setDeepSeekKey(key) {
    // 保存时去除首尾空白
    if (key) localStorage.setItem(DEEPSEEK_KEY_STORAGE, key.trim())
    else localStorage.removeItem(DEEPSEEK_KEY_STORAGE)
  },
  // ---- AI 提供商（deepseek / ollama）----
  getLLMProvider() {
    return localStorage.getItem(LLM_PROVIDER_STORAGE) || 'deepseek'
  },
  setLLMProvider(provider) {
    if (provider) localStorage.setItem(LLM_PROVIDER_STORAGE, provider)
    else localStorage.removeItem(LLM_PROVIDER_STORAGE)
  },
  // ---- Ollama 模型名 ----
  getLLMModel() {
    return localStorage.getItem(LLM_MODEL_STORAGE) || ''
  },
  setLLMModel(model) {
    if (model) localStorage.setItem(LLM_MODEL_STORAGE, model)
    else localStorage.removeItem(LLM_MODEL_STORAGE)
  },
  // ---- 用户信息（JSON 字符串存于 localStorage）----
  getUser() {
    try {
      return JSON.parse(localStorage.getItem(USER_KEY) || 'null')
    } catch {
      // 解析失败（数据损坏）时按未登录处理
      return null
    }
  },
  setUser(user) {
    if (user) localStorage.setItem(USER_KEY, JSON.stringify(user))
    else localStorage.removeItem(USER_KEY)
  },
  // 是否已登录：以是否存在访问令牌为准
  isLoggedIn() {
    return Boolean(api.getToken())
  },
  // 通用请求封装：自动带上 JSON 头与可选的 Bearer Token，统一错误处理
  async request(path, { method = 'GET', body, auth = true } = {}) {
    const headers = { 'Content-Type': 'application/json' }
    if (auth) {
      const token = api.getToken()
      if (token) headers.Authorization = `Bearer ${token}`
    }
    const resp = await fetch(path, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined
    })
    if (!resp.ok) {
      // 尝试从响应体解析后端错误详情，取不到时退回 HTTP 状态码
      const detail = await resp.json().catch(() => ({}))
      throw new Error(detail.detail || `HTTP ${resp.status}`)
    }
    return resp.json()
  },
  // 登录：换取令牌并持久化用户信息
  async login(username, password) {
    const data = await api.request('/api/auth/login', {
      method: 'POST',
      body: { username, password },
      auth: false
    })
    api.setToken(data.access_token)
    api.setUser(data.user)
    return data.user
  },
  // 注册：同样会自动登录
  async register(username, password, nickname) {
    const data = await api.request('/api/auth/register', {
      method: 'POST',
      body: { username, password, nickname },
      auth: false
    })
    api.setToken(data.access_token)
    api.setUser(data.user)
    return data.user
  },
  // 退出登录：清空令牌与用户信息
  logout() {
    api.setToken(null)
    api.setUser(null)
  },
  // ---- 图谱相关接口 ----
  // 图谱统计概要（节点 / 关系 / 问题数量等）
  async graphSummary() {
    return api.request('/api/graph/summary')
  },
  // 图谱网络数据：按领域、关键词、节点类型过滤
  async graphNetwork(params = {}) {
    const query = new URLSearchParams()
    // 仅拼接有值的参数，避免无意义空参数
    for (const key in params) {
      if (params[key]) query.set(key, params[key])
    }
    return api.request(`/api/graph/network?${query.toString()}`)
  },
  // 查询单个节点及其邻域关系
  async graphNode(name) {
    return api.request(`/api/graph/node?name=${encodeURIComponent(name)}`)
  }
}