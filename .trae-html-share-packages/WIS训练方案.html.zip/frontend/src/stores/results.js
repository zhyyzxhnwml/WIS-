// 结果缓存 store：用「问题」做键缓存搜索结果，避免同一问题的重复请求
import { reactive } from 'vue'
import { buildExample } from '../data/mock.js'

// 响应式缓存对象，键为去问号后的规范化问题文本
export const resultCache = reactive({})

// 规范化问题文本作为缓存键：去掉中英文问号并去除首尾空白，保证不同写法命中同一缓存
export function cacheKey(question) {
  return String(question || '').replace(/[？?]/g, '').trim()
}

// 写入缓存：将接口元数据经 buildExample 规范化为完整演示结构后缓存，并返回该结构
export function putResult(question, meta) {
  const key = cacheKey(question)
  resultCache[key] = buildExample(meta)
  return resultCache[key]
}

// 读取缓存：命中返回已构建的结果，未命中返回 null
export function getResult(question) {
  return resultCache[cacheKey(question)] || null
}