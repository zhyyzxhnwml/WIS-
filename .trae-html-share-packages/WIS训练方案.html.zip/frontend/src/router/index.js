// 路由配置：定义应用的所有页面路由，并使用 HTML5 History 模式
import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  // 首页：问题搜索 / 示例 / 功能 / 工作原理等展示
  { path: '/', name: 'home', component: () => import('../views/HomeView.vue') },
  // 结果页：展示某个问题的跨领域映射路径、方案与热力图（通过 query.q 传递问题）
  { path: '/result', name: 'result', component: () => import('../views/ResultView.vue') },
  // 登录 / 注册页
  { path: '/login', name: 'login', component: () => import('../views/LoginView.vue') },
  // 我的历史：查看当前用户的检索记录
  { path: '/history', name: 'history', component: () => import('../views/HistoryView.vue') },
  // 图谱浏览：知识图谱可视化与检索
  { path: '/graph', name: 'graph', component: () => import('../views/GraphExploreView.vue') }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    // 浏览器前进/后退时恢复原滚动位置
    if (savedPosition) return savedPosition
    // 路由带锚点（hash）时平滑滚动至对应元素，并留出顶部导航栏间距
    if (to.hash) {
      return { el: to.hash, behavior: 'smooth', top: 40 }
    }
    // 默认回到页面顶部
    return { top: 0 }
  }
})

export default router