# InnoMap 图数据库使用说明

## 文件清单

| 文件 | 说明 |
| --- | --- |
| `nodes.csv` | 节点数据（257 个）：id / label / name / 编号 / 描述 / 来源 |
| `relationships.csv` | 关系数据（529 条）：start / end / type |
| `import_graph.cypher` | Neo4j 完整导入脚本（CREATE 节点 + MATCH 建关系） |
| `generate_graph_data.py` | 数据生成器（改数据后重新运行即可再生成） |
| `../公开数据/` | 公开数据源 CSV 与来源说明 |

## 图谱模式（对应申报书"知识重定向"链路）

```
(问题)-[:具备功能]->(功能)-[:运用TRIZ原理]->(TRIZ原理)-[:启发]->(概念)
(概念)-[:所属领域]->(领域)
(概念)-[:参考]->(实例)
(实例)-[:生成]->(方案)
(方案)-[:解决]->(问题)      # 闭环
(实例)-[:展示]->(功能)      # 证据链
(领域)-[:包含]->(实例)      # 领域归属
(概念)-[:深化]->(概念)      # 概念演绎
```

## 导入方法

### 方式一：Neo4j Browser（推荐，小型数据集）

1. 启动 Neo4j（`neo4j console` 或 Neo4j Desktop 创建项目）
2. 打开 Browser，将 `import_graph.cypher` 全部内容粘贴到输入框运行
3. 全部执行成功后，运行查询验证：
   ```cypher
   MATCH (n) RETURN labels(n) AS type, count(n) AS cnt ORDER BY cnt DESC;
   MATCH (n)-[r]->() RETURN type(r) AS rel, count(r) AS cnt ORDER BY cnt DESC;
   ```

### 方式二：LOAD CSV（数据量大时）

将 `nodes.csv`、`relationships.csv` 放入 Neo4j 的 `import` 目录：

```cypher
LOAD CSV WITH HEADERS FROM 'file:///nodes.csv' AS row
CREATE (n:`${row.label}` {name: row.name, 编号: row.编号, 描述: row.描述, 来源: row.来源});

LOAD CSV WITH HEADERS FROM 'file:///relationships.csv' AS row
MATCH (a {name: row.start_name}), (b {name: row.end_name})
CREATE (a)-[:`${row.type}`]->(b);
```

> 注：动态标签/类型写法需用 `apoc.merge.node` 或提前按类型分组导入，上述为示意。

## 示例查询（"无人机如何更抗冲击"重定向演示）

```cypher
// 1. 查看"无人机抗冲击能力不足"的完整重定向链
MATCH p = (problem:问题 {name:"无人机抗冲击能力不足"})-[*]->(solution:方案)
RETURN p LIMIT 20;

// 2. 从问题到跨领域实例（重定向路径）
MATCH (p:问题 {name:"无人机抗冲击能力不足"})-[:具备功能]->(:功能)-[:运用TRIZ原理]->(:TRIZ原理)-[:启发]->(:概念)-[:参考]->(e:实例)
RETURN e.name, e.来源;

// 3. 生物领域中的全部缓冲参考
MATCH (d:领域 {name:"生物领域"})-[:包含]->(e:实例)
WHERE e.name CONTAINS '缓冲' OR e.描述 CONTAINS '冲击'
RETURN e.name, e.描述;
```

## 数据规模

- 节点 257 个：问题 5、功能 10、TRIZ原理 41、概念 82、领域 8、实例 90、方案 21
- 关系 529 条（≥申报书 500 三元组目标）
- 数据来源见 `../公开数据/数据来源说明.md`
