﻿$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$backend = Join-Path $root "backend"
$frontend = Join-Path $root "frontend"
$logDir = Join-Path $root "logs"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null

$py = Join-Path $backend ".venv\Scripts\python.exe"

function IsPortOpen([int]$port) {
  return [bool](Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue)
}

Write-Host "== InnoMap 开发环境启动 ==" -ForegroundColor Cyan
Write-Host ""
Write-Host "请确认是否已启动 MySQL（3306）、Neo4j（7687）、Ollama（11434）" -ForegroundColor Yellow
Read-Host "按回车键继续"

# 后端
if (IsPortOpen 8000) {
  Write-Host "[后端] 8000 已在运行，跳过" -ForegroundColor Yellow
} else {
  if (-not (Test-Path $py)) {
    Write-Host "缺少 $py，请先：cd backend && python -m venv .venv && .venv\Scripts\pip install -r requirements.txt" -ForegroundColor Red
  } else {
    Start-Process -FilePath $py -ArgumentList "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8000", "--reload" `
      -WorkingDirectory $backend `
      -RedirectStandardOutput (Join-Path $logDir "uvicorn.log") `
      -RedirectStandardError (Join-Path $logDir "uvicorn.err.log")
    Write-Host "[后端] 启动中 → http://127.0.0.1:8000/docs（日志 logs\uvicorn*.log）" -ForegroundColor Green
  }
}

# 前端
if (IsPortOpen 5173) {
  Write-Host "[前端] 5173 已在运行，跳过" -ForegroundColor Yellow
} else {
  if (-not (Test-Path (Join-Path $frontend "node_modules"))) {
    Write-Host "缺少 node_modules，请先：cd frontend && npm install" -ForegroundColor Red
  } else {
    Start-Process -FilePath "node.exe" -ArgumentList "node_modules/vite/bin/vite.js" `
      -WorkingDirectory $frontend `
      -RedirectStandardOutput (Join-Path $logDir "vite.log") `
      -RedirectStandardError (Join-Path $logDir "vite.err.log")
    Write-Host "[前端] 启动中 → http://localhost:5173（日志 logs\vite*.log）" -ForegroundColor Green
  }
}

Write-Host ""
Write-Host "验证：浏览器打开 http://localhost:5173 ，搜索「如何让无人机更抗冲击？」" -ForegroundColor Cyan