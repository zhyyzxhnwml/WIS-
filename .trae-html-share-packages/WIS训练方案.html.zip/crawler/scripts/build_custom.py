# -*- coding: utf-8 -*-
"""把自定义「跨领域创新知识库」编译为 RawDoc 统一格式，输出 data/raw/custom.jsonl。

用法（项目根或 crawler 目录均可）：
    python scripts/build_custom.py

产出特点：
- 每个 (概念, 实例) 配对生成一条记录，走标准 RawDoc 格式（title/text/field/lang/source/meta）
- text 由「概念描述 + 实例描述 + 功能效用」三层拼接，供 DeepSeek 结构化抽取使用
- 可重复执行；与任何真实爬取源（wiki/patents/gitee/github）的 raw 文件共存

输入：scripts/custom_data/custom_*.json（人工整理的知识库）。
"""
import glob
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]   # crawler/
DATA_DIR = ROOT / "scripts" / "custom_data"          # 自定义知识库输入目录
OUT = ROOT / "data" / "raw" / "custom.jsonl"         # 统一 raw 输出


def _load_domain(path: pathlib.Path):
    """读取并解析一个领域知识库 JSON 文件。"""
    return json.loads(path.read_text(encoding="utf-8"))


def build():
    rows = []
    total = 0
    idx = 0  # 全局序号，用于生成唯一 id
    files = sorted(glob.glob(str(DATA_DIR / "custom_*.json")))
    if not files:
        sys.exit(f"未找到知识库文件: {DATA_DIR}/custom_*.json")
    for fp in files:
        dom = _load_domain(pathlib.Path(fp))
        field = dom["field"]
        n = 0
        for cnode in dom["concepts"]:
            concept = cnode["concept"].strip()
            cdesc = cnode.get("concept_desc", "").strip()
            func = cnode.get("function", "").strip()
            for inode in cnode.get("instances", []):
                name = inode["name"].strip()
                idesc = inode.get("desc", "").strip()
                idx += 1
                # 三层拼接正文：概念定义 + 典型实例 + 领域内功能定位
                text = (
                    f"{concept}：{cdesc}。"
                    f"典型实例：{name}（{idesc}）。"
                    f"在{field}领域，{name}是实现「{concept}」、达成「{func}」的高价值方案。"
                )
                rows.append({
                    "id": f"custom_{idx:04d}",           # 固定宽度编号，保证顺序稳定
                    "title": name,
                    "lang": "zh",
                    "field": field,
                    "text": text,
                    "url": f"custom://{field}/{concept}",  # 自定义协议，便于溯源
                    "source": "custom",
                    "meta": {"keyword": concept, "instance": name},
                })
                n += 1
        total += n
        print(f"{field:>6}: {n} 条")
    # 生成输出目录并整批写入
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"总记录 {total} 条 -> {OUT}")


if __name__ == "__main__":
    build()