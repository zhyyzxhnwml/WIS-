# -*- coding: utf-8 -*-
"""为已入库记录补录可溯源的「来源」标识，并生成对应的 Neo4j 补齐脚本。

背景：早期 custom 语料抽取时 url 为空串，图谱中 概念/实例 的「来源」属性缺失。
本脚本：

1. 读取 data/extracted/records.jsonl；
2. 对每条记录计算溯源标识：保留已写的 url，空则回填 `custom://{field}/{concept}`；
3. 汇总「概念名 -> 来源」与「实例名 -> 来源」（同名多源时首个非空优先）；
4. 生成 data/output/source_patch.cypher（UNWIND 批量 SET，按 200 个一组拆分，幂等：
   仅当节点来源为空时才写入，已有来源不动）。

用后端执行导入：
    cd backend
    .venv\\Scripts\\python -m scripts.load_cypher ..\\crawler\\data\\output\\source_patch.cypher
"""
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]  # crawler/
RECORDS = ROOT / "data" / "extracted" / "records.jsonl"
OUT = ROOT / "data" / "output" / "source_patch.cypher"
BATCH = 200  # 每个 UNWIND 批最多处理的节点数


def _records():
    """逐行读取抽取结果 records.jsonl；文件缺失时提示先运行 extract。"""
    if not RECORDS.exists():
        sys.exit(f"未找到 {RECORDS}（先运行 python -m src.cli extract）")
    with open(RECORDS, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def _cypher_map_row(name: str, url: str) -> str:
    """Cypher map 字面量：键为裸标识符，值字符串须转义单引号/反斜杠。"""
    name = (name or "").replace("\\", "\\\\").replace("'", "\\'")
    url = (url or "").replace("\\", "\\\\").replace("'", "\\'")
    return f"{{name: '{name}', url: '{url}'}}"


def _patch_block(label, rows):
    """rows: [{name, url}] -> 一条 UNWIND SET 语句（≤BATCH 行）。

    幂等写法：仅当节点来源为空（coalesce 兜底空串）时才写入，已有来源不动。
    """
    if not rows:
        return []
    chunks = [rows[i:i + BATCH] for i in range(0, len(rows), BATCH)]
    stmts = []
    for chunk in chunks:
        payload = ",".join(_cypher_map_row(r["name"], r["url"]) for r in chunk)
        stmts.append(
            f"UNWIND [{payload}] AS row\n"
            f"MATCH (n:{label} {{name: row.name}})\n"
            f"SET n.来源 = CASE WHEN coalesce(n.来源, '') = '' THEN row.url ELSE n.来源 END;"
        )
    return stmts


def main():
    concept_src, instance_src = {}, {}  # 名字 -> 溯源 url
    patched_urls = 0
    for rec in _records():
        concept = (rec.get("concept") or "").strip()
        instance = (rec.get("instance") or "").strip()
        # 已写 url 则保留；为空则回填 custom 协议，取 field/concept
        url = (rec.get("url") or "").strip() or f"custom://{rec.get('field', '')}/{concept}"
        if not concept or not instance:
            continue  # 缺语义字段不参与补录
        # 同名多源时“首个非空优先”：只在未登记时赋值
        if concept not in concept_src:
            concept_src[concept] = url
        if instance not in instance_src:
            instance_src[instance] = url
        if (rec.get("url") or "").strip() != url:
            patched_urls += 1  # 统计实际回填了多少条

    # 分别生成 概念/实例 两种节点的补录语句
    statements = []
    statements += _patch_block("概念", [{"name": k, "url": v} for k, v in sorted(concept_src.items())])
    statements += _patch_block("实例", [{"name": k, "url": v} for k, v in sorted(instance_src.items())])

    OUT.write_text("\n\n".join(statements), encoding="utf-8")
    print(f"概念 {len(concept_src)} 个 / 实例 {len(instance_src)} 个 -> {len(statements)} 条语句")
    print(f"回填 url 的记录数: {patched_urls}")
    print(f"已写出 {OUT}；导入命令：cd backend && .venv\\Scripts\\python -m scripts.load_cypher {OUT}")


if __name__ == "__main__":
    main()