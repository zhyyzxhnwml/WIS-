# InnoMap 数据获取与 Neo4j 入库全流程

本指南覆盖两件事：

1. **怎么爬到数据**（真实外网源 + 内建精选语料）
2. **怎么用 Python 把数据写入 Neo4j 图谱**

适用目录约定：

- 爬虫管线在 `crawler/`（命令都从该目录执行）
- 入库工具在 `backend/scripts/load_cypher.py`（走后端同一套 `app.db.neo4j` 驱动）
- Python 解释器统一用后端 venv：`backend\.venv\Scripts\python.exe`

---

## 1. 整体管线

```
抓取/生成 raw
   ▾
data/raw/*.jsonl          ← RawDoc 统一格式（title/text/field/lang/source/meta）
   ▾  DeepSeek 结构化抽取
data/extracted/records.jsonl   ← 每条一行 JSON（concept/instance/field/function/triz_*）
   ▾  validate + export
data/output/graph_import.cypher ← 幂等 MERGE 语句（分批分号事务）
   ▾  load_cypher.py 导入
Neo4j 图谱                 ← 问题/功能/TRIZ原理/概念/实例/领域/方案
```

图谱建模（与 `数据/图数据库/import_graph.cypher` 一致）：

```
问题-[:具备功能]->功能-[:运用TRIZ原理]->TRIZ原理-[:启发]->概念
概念-[:所属领域]->领域    领域-[:包含]->实例   概念-[:参考{weight}]->实例
实例-[:生成]->方案
```

---

## 2. 前置条件

```powershell
# 1) DeepSeek key（抽取用）：填入你自己的 key，不要使用他人的密钥
#    a) 网页方式：后端启动后，在网页右上角「API Key」弹窗填写（仅存本地浏览器）
#    b) 命令行方式：
$env:DEEPSEEK_API_KEY = '<你自己的 DeepSeek API Key>'
#    或写入 backend/.env：DEEPSEEK_API_KEY=<你自己的 key>

# 2) Neo4j 需已启动，连接信息在 backend/.env（NEO4J_PASSWORD=<你自己的真实密码>，勿把真实密码写进文档/提交到仓库）
# 3) 后端 venv：backend\.venv\Scripts\python.exe
```

> 说明：**爬取抽取的 DeepSeek Key 与网页运行时的 AI 来源是两回事**。
> - 抽取（第 6 节）必须用 DeepSeek（当前不支持用 Ollama 做结构化抽取）。
> - 网页端生成方案（`/api/search`）由使用者在前端「AI 模型」弹窗配置，可选 **DeepSeek key 或本机 Ollama**（见第 11.1 节），本项目仓库不再内置任何密钥。

---

## 3. 数据源与可用性现状（实测）

| 来源 | 命令 | 需外网 | 2026 实测 | 备注 |
|---|---|---|---|---|
| 维基百科 zh/en | `python -m src.cli wiki` | 是 | 超时不可用 | MediaWiki API |
| PatentsView 专利 | `python -m src.cli patents` | 是 | DNS 不可解析 | USPTO 开放数据 |
| 百度百科 | `python -m src.cli baike` | 否 | 返回 403 | 部分出口 IP 被限 |
| GitHub API | `python -m src.cli github` | 是 | 200 可用 | 需在 config.yaml 配置仓库名 |
| Gitee | `python -m src.cli gitee` | 否 | 可用 | 改自建仓库可复用，见 config.yaml |
| 内建精选语料 | `python -m src.cli extract`（对 custom.jsonl） | 否 | ✅ 主力 | 见第 4 节 |

> 由于外网源当前均不稳定，正式版以「内建精选语料」达到量产级（已入库 1030 条），真实抓取命令保留并如实标注状态。

---

## 4. 内建精选语料（不依赖网络）

精选语料以「领域 JSON」形式存放在 `crawler/scripts/custom_data/custom_*.json`，每个文件一个领域。

文件结构：

```json
{
  "field": "材料",
  "concepts": [
    {
      "concept": "气凝胶绝热",
      "concept_desc": "纳米孔网络抑制热对流导热",
      "function": "超低导热保温隔音",
      "instances": [
        {"name": "二氧化硅气凝胶毡", "desc": "管道高温隔热"},
        {"name": "气凝胶保温板", "desc": "建筑外墙保冷"}
      ]
    }
  ]
}
```

编译为 raw（每条 = 一个「概念→实例」配对）：

```powershell
cd crawler
python scripts\build_custom.py
# 输出 data/raw/custom.jsonl（约 1000+ 条，可重复执行覆盖）
```

生成逻辑（`crawler/scripts/build_custom.py`）：

- 每个 `(concept, instance)` 生成一条 RawDoc；`text` 由「概念描述 + 实例描述 + 功能效用」三层拼接，供抽取提示词使用
- `meta.keyword=concept`、`meta.instance=instance`，便于抽取出错时追溯
- 文件名按字典序读取，`custom_<领域>_a/_b/_c...` 同名文件会被覆盖，增量请新增后缀卷

---

## 5. 真实外网源抓取命令（供恢复网络后使用）

从 `crawler/` 目录执行：

```powershell
# 维基百科：对每个领域种子分类抓取（config.yaml 的 wikipedia 段）
python -m src.cli wiki --lang zh

# 专利：每个检索词抓取 3 页
python -m src.cli patents --pages 3

# 百度百科
python -m src.cli baike

# GitHub / Gitee 开源语料（contents API）
python -m src.cli github
python -m src.cli gitee
```

所有抓取源输出到 `crawler/data/raw/<source>.jsonl`，与 custom 源共存，后续完全走同一管线。

---

## 6. DeepSeek 结构化抽取

作用：把自由文本 `text` 提炼为图谱结构化字段（`concept / instance / field / function / triz_principle / triz_no / weight` 等）。

```powershell
cd crawler
# 先设置 DEEPSEEK_API_KEY（见第 2 节）
python -m src.cli extract
```

- 并发与模型在 `crawler/config.yaml` 的 `deepseek` 段配置（默认并发 4）
- **追加式**：`data/extracted/records.jsonl` 会增量 append。重复运行时建议先删它（或依赖 validate 去重）：
  ```powershell
  Remove-Item data\extracted\records.jsonl -ErrorAction SilentlyContinue
  ```
- 失败记录写入 `data/output/extract_errors.jsonl`，可重跑续抽

---

## 7. 校验校验（validate）

```powershell
python -m src.cli validate
```

- 输出 `data/output/stats.json`（完整性 / 领域 / 语言 / 来源分布）
- 生成人工抽检清单 `data/output/sample_checklist_*.csv`
- 去重规则（`crawler/src/pipeline/clean.py`）：
  1. 按归一化后的 `(concept, instance)` 精确去重
  2. 近似去重：仅当**同领域、且 concept 与 instance 两维**的字符集 Jaccard 都 ≥ `min_sim`（默认 0.92）才判重，避免误删同一概念的其它实例
- 若某领域只剩个位数，先怀疑 LLM 把 field 识别到了其它领域（属语义判定，可接受；也可在抽取提示词中固定领域枚举）

### 7.1 自动质检（quality）

在人工抽检之外，`quality` 命令对清洗后的记录做规则扫描，输出 high/medium/low 分级问题清单：

```powershell
python -m src.cli quality
# 输出 data/output/quality_report.json + data/output/quality_issues.csv
```

规则（`crawler/src/pipeline/quality.py`）：必填字段缺失 / 描述过短 / 概念过泛（纯泛词或删尾后仅剩不足 3 字）/
weight 越界或异常偏低 / 概念与实例高度雷同 / 同领域疑似近义概念 / 单概念过度聚集。
当前 1030 条质检结果：**0 high / 0 medium / 8 low**（low 均为疑似近义概念，供人工合并）。阈值均为常量，可在文件头部调整。

### 7.2 失败重抽

`extract` 现在默认读取 `records.jsonl` 已有的 `raw_id` 并**跳过已成功文档**（重抽失败 = 直接重跑命令）；
`--force` 忽略该逻辑全量重抽。

---

## 8. 导出 Neo4j 导入脚本

```powershell
python -m src.cli export
# 输出 data/output/graph_import.cypher
```

导出端（`crawler/src/store/neo4j_import.py`）做了三类规范化，保证与现有图谱合并、不产生碎片：

| 规范化 | 实现 |
|---|---|
| 领域短名 → 图谱全称 | `FIELD_MAP`（如 生物→生物领域、航空航天→航空航天领域） |
| 功能文本 → 10 大规范功能 | `FUNC_RULES` 关键词匹配（如包含「散热/导热/冷却」→ 高效散热） |
| TRIZ → 标准名称/编号 | `TRIZ_MAP` 读 `数据/公开数据/TRIZ_40发明原理_公开数据.csv`（编号→名称） |

关键点：脚本按 **每 40 条记录追加一个分号**，把超大文件拆成多条独立事务；否则单条几千行的 MERGE 会触发 Neo4j `Java heap space`。

---

## 9. Python 导入 Neo4j（load_cypher.py）

```powershell
cd backend
$env:PYTHONPATH = "D:\课程学习\2下\大创\innomap\backend"   # 使脚本能 import app.db.neo4j
python scripts\load_cypher.py D:\课程学习\2下\大创\innomap\crawler\data\output\graph_import.cypher
```

要点：

- 脚本按末尾分号把文本拆分，逐条执行（`load_cypher.py` 已内置）
- 全部是 **MERGE** 语句，幂等：反复导入只补不重
- 需要让 `app` 包可被导入：要么设 `PYTHONPATH`，要么在 backend 下用 `python -m scripts.load_cypher <file>` 运行
- 导入过程不会回滚分批事务，失败后直接重跑即可

> **来源补录**：早期 custom 语料 url 为空。`crawler/scripts/sync_sources.py` 会按
> `custom://<领域>/<概念>` 回填并生成 `data/output/source_patch.cypher`（UNWIND 批量 SET，仅当来源为空才写），
> 再用本小节命令导入即可全图「来源可溯源」。详见 [`数据合规与出处说明.md`](./数据合规与出处说明.md)。

---

## 10. 导入后的清理与验证

### 10.1 清理非标准 TRIZ

DeepSeek 偶会自造 TRIZ 名（如「能量转换原理」「等角螺旋」）。标准集 = CSV 的 41 行（40 条 + 「9(综合) 缓冲原理」）。清理方式：把这类节点的 `-[:启发]->概念` 边改由相应功能直接启发，再 `DETACH DELETE`。可用临时脚本（模板见 `C:\Users\LINZHI~1\AppData\Local\Temp\opencode\cleanup_triz3.py`）。

### 10.2 结构验证

```powershell
cd backend
python -c "from app.db import neo4j; print(neo4j.run('MATCH (n) RETURN labels(n)[0] AS l, count(*) c')[:5])"
```

核对要点：TRIZ 41 个全部有 `-[:启发]->` 出边；功能节点稳定为 10；领域与 `FIELD_MAP` 无分叉。

### 10.3 端到端

- `pytest`：`cd backend && python -m pytest -q`（11 项）
- API：`/api/stats`（nodes/relations），`/api/search` POST `{"question": "..."}`，图谱 `/api/graph/network?domain=材料`

---

## 11. 运行时大模型来源（网页端生成方案）

图谱未命中时，`/api/search` 按请求里的 `provider` 选择生成引擎：

| provider | 引擎 | 需要 | 请求字段 |
|---|---|---|---|
| `deepseek`（默认） | DeepSeek 在线 API | 使用者自己的 API Key（无内置） | `api_key` |
| `ollama` | 本机 Ollama（`/api/chat`） | 已启动 Ollama + 已拉取模型 | `model`（如 `qwen2.5:7b`、`gemma3:4b`） |

- 前端「AI 模型」弹窗配置并保存在浏览器 localStorage；已配置时导航栏该按钮显示青色圆点。
- 探测端点：`GET /api/llm/status` 返回 DeepSeek 是否有 key、Ollama 是否可达及其模型列表。
- Ollama 地址可用后端环境变量 `OLLAMA_BASE_URL` 覆盖（默认 `http://localhost:11434`）。
- key/model 仅本次请求内存使用，不打日志、不入库、不在仓库出现。

---

## 12. 常见故障

| 现象 | 原因 | 处理 |
|---|---|---|
| `Java heap space` | 一条 cypher 导入语句过大 | 导出按批加分号；或手动把文件拆成多条语句 |
| 某领域记录数骤减 | 去重只比 concept 不比 instance（旧版 bug，已修） | 升级 `clean.py` 后重新 validate/export |
| `ModuleNotFoundError: app` | 脚本不在 backend 下运行 | 设 `PYTHONPATH` 或用 `python -m scripts.load_cypher` |
| 抽取重复累积 | records.jsonl 追加式 | 重跑前删 records.jsonl，或依赖 validate 去重 |
| data/raw/custom.jsonl 数量不对 | 同前缀文件被覆盖 | 新增卷用不冲突的后缀（_b/_c…） |
| 网页搜索无 LLM 方案 | `provider=ollama` 但 Ollama 未启动，或 `model` 未填；或 `provider=deepseek` 但未传 key | 前端「AI 模型」弹窗配置；`/api/llm/status` 可探测 |

---

*本文档对应仓库当前状态：图谱 3300 节点 / 5656 关系（概念 956、实例 1162、方案 1102、TRIZ 41、功能 10、领域 10、问题 19）。*