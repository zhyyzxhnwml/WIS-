# InnoMap 数据管道（crawler）

把「维基百科 / 开放专利 / 国内开源语料」爬成结构化图谱数据的轻量管道。

```
raw/*.jsonl  --LLM抽取--> extracted/records.jsonl  --去重/校验-->  --导出--> graph_import.cypher
```

## 数据源一览

| 源 | 命令 | 需外网 | 说明 |
|---|---|---|---|
| 维基百科 | `python -m src.cli wiki --lang both` | 是 | zh/en，仿生/工程分类摘要 |
| 开放专利 | `python -m src.cli patents --pages 3` | 是 | PatentsView（USPTO 官方，免费无 key） |
| 百度百科 | `python -m src.cli baike` | 否 | 国内直连；部分出口 IP 会触发 403 反爬 |
| GitHub 语料 | `python -m src.cli github` | 否 | 走 api.github.com（raw 域名常被墙，contents API 可用） |
| Gitee 语料 | `python -m src.cli gitee` | 否 | 国内直连，最稳；复用同一 contents 实现 |

## 数据流

| 阶段 | 命令 | 产物 |
|---|---|---|
| 抓取 | `python -m src.cli wiki --lang both` 等（见上表） | `data/raw/<source>.jsonl` |
| 抽取 | `python -m src.cli extract` | `data/extracted/records.jsonl` |
| 校验 | `python -m src.cli validate` | `data/output/stats.json` + `sample_checklist_*.csv` |
| 导出 | `python -m src.cli export` | `data/output/graph_import.cypher` |

## 快速开始

```bash
cd crawler
pip install -r requirements.txt          # 仅依赖 PyYAML

# 配置 API（不要提交密钥）
set DEEPSEEK_API_KEY=<你自己的 DeepSeek API Key>   # 或写入 config.yaml 的 deepseek.api_key

# 1. 抓取（按你的网络情况选源）
python -m src.cli wiki --lang both      # 需外网
python -m src.cli patents --pages 3     # 需外网
python -m src.cli baike                 # 国内直连（部分 IP 会 403）
python -m src.cli gitee                 # 国内直连，最稳（先按需改 config.yaml 的 sources.gitee.repos）
python -m src.cli github                # api.github.com 直连（先按需改 sources.github.repos）

# 2. LLM 抽取（会调用 deepseek API，注意限流与成本；默认跳过已成功，--force 全量重抽）
python -m src.cli extract

# 3. 校验：统计完整率/领域分布，生成 20% 人工核对清单
python -m src.cli validate

# 3b. 自动质检：high/medium/low 分级问题清单（data/output/quality_report.json）
python -m src.cli quality

# 4. 导出 Neo4j 导入脚本
python -m src.cli export

# 5. 导入 Neo4j
#    Neo4j Browser 直接粘贴 data/output/graph_import.cypher
#    或：bin\cypher-shell -a bolt://localhost:7687 -u neo4j -p <密码> -f crawler\data\output\graph_import.cypher

# 6.（可选）来源补录：custom 语料 url 回填 custom://领域/概念 并生成 source_patch.cypher
python scripts/sync_sources.py
#    再用后端导入：cd ../backend && .venv\Scripts\python -m scripts.load_cypher ..\crawler\data\output\source_patch.cypher
```

## 与初始化脚本的关系

1. 先执行 `../neo4j/init.cypher`——建立约束 + 3 个手工示例（问题节点、完整链路、融合方案）
2. 再执行导出的 `graph_import.cypher`——附加爬取到的实例/概念

两者共用同一套标签（`概念`/`实例`/`领域`/`发明原理`/`功能`/`方案`）与关系
（`重定向`/`属于`/`所属领域`/`生成`/`匹配出`/`启发`/`融合`），可共存于同一库。

## 网络/合规说明

- **需要外网的源**：维基 (zh/en.wikipedia.org)、PatentsView (search.patentsview.org)。
- **国内可直连的源**：百度百科、Gitee、api.github.com（GitHub 的 raw.githubusercontent.com 常被屏蔽，已改用 contents API）。
- 维基为 CC BY-SA，Gitee/GitHub 语料沿用各仓库许可证；**必须保留 `来源_url`** 与出处信息（节点 `来源_url` 属性已写入）。
- 百度百科存在地域/IP 级反爬（实测部分出口会 403），如失败可换 Gitee 或其他节点。
- PatentsView 是 USPTO 官方开放数据（免费、无需 key），请遵循其 fair use 与 rate limit。
- GitHub 匿名 API 限流 60 次/时，配置 `sources.github.token` 可提升到 5000 次/时。

## 质量保障

- `validate` 会输出：字段完整率、领域分布、语言分布、来源分布；
  并生成 **20% 抽样清单（CSV）**，人工核对后回填 "人工判定" 列。
- 去重：以 `(概念, 实例)` 归一化 + 同领域概念相似度（阈值 0.92）去重。
- 建议在 `data/output/extract_errors.jsonl` 检查抽取失败原因，调整提示词后重跑 `extract`（先删旧 `records.jsonl` 避免重复）。

## 成本提示

- 默认并发 4、每文档一次调用，预计 1500 条需约 1500 次 deepseek 调用。
- 可调 `config.yaml` 的 `deepseek.max_concurrency` 做限流。
- 抽取前建议先小批量试跑看格式/成本：先删掉大部分 raw 数据，或临时改 config 的 `fields`/`query_set` 仅留一个。