"""通用 Git 托管仓库数据源：GitHub contents API 或 Gitee API。

- raw.githubusercontent.com 常被网络环境屏蔽；api.github.com 与 gitee.com 的
  contents 接口在国内网络大多可直连。
- 支持在 config.yaml 的 sources.github.repos / sources.gitee.repos 里声明
  仓库/目录/文件，host 字段决定走哪个平台：
      host: "github"  (默认)  -> https://api.github.com
      host: "gitee"           -> https://gitee.com/api/v5
- 会递归目录（深度 ≤2），把文件切成 raw 文档追加写入 JSONL：
  json/jsonl 数组 -> 按元素抽 (标题, 说明)；txt/md/csv -> 按段落切分。

使用标准库 urllib + base64 解码 API 返回的文件内容。
"""
import base64
import json
import re
import time
import urllib.parse
import urllib.request

from .base import append_jsonl

# 不同平台的内容 API 根地址
_API_BASE = {
    "github": "https://api.github.com",
    "gitee": "https://gitee.com/api/v5",
}
# 生成文件对应的在线浏览 URL（用于出处溯源）
_BLOB_URL = {
    "github": "https://github.com/{o}/{r}/blob/{ref}/{path}",
    "gitee": "https://gitee.com/{o}/{r}/blob/{ref}/{path}",
}


class GithubFetchError(Exception):
    """仓库 API 抓取失败（多次重试仍失败）时抛出。"""
    pass


def _api_get(url, token, retries=3, timeout=45):
    """GET 一个 contents/树 接口并解析 JSON，失败指数/线性退避重试。"""
    headers = {"User-Agent": "InnoMapCrawler/0.1", "Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    last = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None  # 路径不存在：视为「该路径不是目录」
            last = e
            time.sleep(2 * attempt + 1)
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(2 * attempt + 1)
    raise GithubFetchError(f"repo api failed: {last}")


# 从 JSON 条目中抽取「标题」与「正文」字段的候选键（支持中英文键名）
_TITLE_KEYS = ("title", "name", "ename", "实例", "概念", "词条")
_TEXT_KEYS = ("description", "desc", "summary", "摘要", "text", "content", "介绍", "详情", "说明")


def _doc_from(item):
    """把 JSON 数组里的一个元素抽成 (title, text) 文档；无正文则返回 None。"""
    if not isinstance(item, dict):
        return None
    title = ""
    for k in _TITLE_KEYS:
        v = item.get(k)
        if isinstance(v, str) and v.strip():
            title = v.strip()
            break
    texts = []
    for k in _TEXT_KEYS:
        v = item.get(k)
        if isinstance(v, str) and v.strip():
            texts.append(v.strip())
    if not texts:
        return None
    return {"title": title, "text": " ".join(texts)}


def _chunk(text, fallback_title):
    """把长文本切成若干文档（每段作为一个 raw 文档）。

    - 若整体是 JSON 数组：按数组元素逐个抽成文档
    - 否则按空行分段；短标题行作为下一段的标题（小标题跟随正文）
    """
    docs = []
    if not text:
        return docs
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    # 以 '[' 开头多半是 JSONL/JSON 数组文件
    if lines and lines[0].startswith("["):
        try:
            arr = json.loads(text)
            for item in arr:
                d = _doc_from(item)
                if d:
                    docs.append(d)
            if docs:
                return docs
        except Exception:  # noqa: BLE001 解析失败则当普通文本继续
            pass
    # 普通文本：统一换行符后按空行分段
    paras = re.split(r"\n\s*\n", re.sub(r"\r\n?", "\n", text))
    buf = ""
    for p in paras:
        # 去掉 markdown 列表符号/标题井号/引用符号等装饰字符
        p = re.sub(r"[\-#*>`]+", "", p).strip()
        if len(p) >= 40:
            docs.append({"title": buf or fallback_title, "text": p})
            buf = ""
        elif p:
            # 短行作为下一段的标题缓冲（上限 200 字符防膨胀）
            buf = (buf + " " + p).strip()[:200]
    return docs


def _lang(text):
    """简单语言判定：含中文字符记为 zh，否则 en。"""
    return "zh" if re.search(r"[\u4e00-\u9fff]", text) else "en"


def fetch(repo_cfg, out_path, settings, max_depth=2):
    """拉取一个仓库配置（config 中 sources.github.repos / sources.gitee.repos 的一项）。

    递归遍历目录（深度 ≤ max_depth）收集目标扩展名文件，逐个切分并写入 JSONL。
    """
    host = repo_cfg.get("host", "github")
    api_base = _API_BASE[host]
    token = (settings.github if host == "github" else settings.gitee).get("token") or ""
    ref = repo_cfg.get("branch") or ("master" if host == "gitee" else "main")
    root = repo_cfg.get("path", "").strip("/")  # 仓库内入口目录，去首尾斜杠
    exts = set(repo_cfg.get("file_exts") or ["json", "jsonl", "csv", "txt", "md"])
    max_files = int(repo_cfg.get("max_files") or 50)
    field = repo_cfg.get("field") or "通用"
    max_chars = settings.pipeline.get("raw_max_chars", 1500)

    def contents_url(path):
        """构造 contents 接口 URL（/repos/{o}/{r}/contents/{path}?ref=...）。"""
        rel = urllib.parse.quote(path) if path else ""
        q = f"?ref={urllib.parse.quote(ref)}" if ref else ""
        return f"{api_base}/repos/{repo_cfg['owner']}/{repo_cfg['repo']}/contents/{rel}{q}"

    def list_dir(path):
        """返回目录下条目列表；非目录（文件或 404）则返回 None。"""
        data = _api_get(contents_url(path), token)
        return data if isinstance(data, list) else None

    def get_file(path):
        """获取单个文件内容：base64 解码 -> utf-8 文本。"""
        data = _api_get(contents_url(path), token)
        if isinstance(data, dict) and data.get("content"):
            raw = data["content"].replace("\n", "")
            return base64.b64decode(raw).decode("utf-8", errors="replace")
        return None

    # 深度优先遍历，收集目标扩展名的文件路径，受 max_files 限制
    files = []
    stack = [(root, 0)]
    while stack and len(files) < max_files:
        cur, depth = stack.pop()
        listing = list_dir(cur)
        if listing is None:
            files.append(cur)  # 叶子：直接作为文件
            continue
        for item in listing:
            if item.get("type") == "file":
                name = item.get("name", "")
                if name.rsplit(".", 1)[-1].lower() in exts:  # 命中目标扩展名
                    files.append(item.get("path"))
            elif item.get("type") == "dir" and depth < max_depth:
                stack.append((item.get("path"), depth + 1))

    docs = []
    seen = set()
    for path in files[:max_files]:
        text = get_file(path)
        if not text:
            continue
        fname = path.rsplit("/", 1)[-1]  # 用文件名作为默认标题
        chunks = _chunk(text, fname)
        for d in chunks:
            did = f"{host}_{repo_cfg['owner']}_{repo_cfg['repo']}_{path.replace('/', '_')}_{len(seen)}"
            if did in seen:
                continue
            seen.add(did)
            docs.append(
                {
                    "id": did,
                    "title": d["title"] or fname,
                    "lang": _lang(d["text"]),
                    "field": field,
                    "text": d["text"][:max_chars],
                    "url": _BLOB_URL[host].format(
                        o=repo_cfg["owner"], r=repo_cfg["repo"], ref=ref, path=path
                    ),
                    "source": host,
                    "meta": {"repo": f"{repo_cfg['owner']}/{repo_cfg['repo']}", "file": path},
                }
            )
        time.sleep(0.2)  # 限速
    if docs:
        append_jsonl(out_path, docs)
    return len(docs)