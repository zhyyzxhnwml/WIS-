"""维基百科数据源：MediaWiki API（zh/en）。

- 用 CategoryMembers 收集种子分类下的页面标题
- 用 Extract + exintro 批量取首段摘要
- 纯标准库 urllib，仅需能访问外网

数据流向：标题收集 -> 批量取摘要 -> 组装成 raw 文档追加写入 JSONL。
"""
import json
import time
import urllib.parse
import urllib.request

from .base import append_jsonl

# 中英文维基 API 端点
_ENDPOINTS = {"zh": "https://zh.wikipedia.org/w/api.php", "en": "https://en.wikipedia.org/w/api.php"}


class FetchError(Exception):
    """维基 API 抓取失败（多次重试仍失败）时抛出。"""
    pass


def _api_get(url, params, user_agent, retries=3, timeout=60):
    """发起 GET 请求并解析 JSON；指数退避重试。

    - 自动补上 format=json
    - 网络错误/超时按幂次递增的时间退避重试，最多 retries 次
    - 全部失败则抛出 FetchError
    """
    params.update({"format": "json"})
    qs = urllib.parse.urlencode(params)
    full = f"{url}?{qs}"
    last = None
    for _ in range(retries):
        try:
            req = urllib.request.Request(full, headers={"User-Agent": user_agent})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(1.5 * 2 ** min(_, 3))  # 退避：1.5s, 3s, 6s ...
    raise FetchError(f"wiki api failed: {last}")


def category_members(lang, category, user_agent, limit=300):
    """返回分类下的页面标题列表（非子分类）。

    通过 MediaWiki continue 令牌分页拉取，直到取完该分类下所有页面。
    """
    url = _ENDPOINTS[lang]
    cms = []
    params = {
        "action": "query",
        "list": "categorymembers",
        "cmtitle": f"Category:{category}",
        "cmtype": "page|subcat",
        "cmlimit": "500",
        "cmcontinue": "",  # placeholder：实际传参时会 pop 掉，见下方分页
    }
    # 用迭代游标处理分页（MediaWiki 使用继续令牌 cmcontinue）
    cont = ""
    while True:
        # 每次请求重建参数；仅当有下一页令牌时再带上 cmcontinue
        p = dict(params)
        p.pop("cmcontinue")
        if cont:
            p["cmcontinue"] = cont
        data = _api_get(url, p, user_agent)
        # 只收集 type == "page" 的条目（subcat 只是子分类的名字，不直接当作文档）
        batch = data.get("query", {}).get("categorymembers", [])
        cms.extend(b.get("title", "") for b in batch if b.get("type") == "page")
        # continue 对象存在说明还有更多结果，取出下一页令牌继续
        cont_ = data.get("continue", {})
        if not cont_:
            break
        cont = cont_.get("cmcontinue", "")
        time.sleep(0.2)  # 温和限速
    # 去重（转义标题可能在分页重复出现）并按 limit 截断返回
    return list(dict.fromkeys(cms))[:limit]


def _extracts(lang, titles, user_agent, max_chars):
    """批量取首段摘要，返回 {title: text} 映射。

    MediaWiki 的 prop=extracts 单次最多约 50 个标题，因此按块遍历。
    """
    url = _ENDPOINTS[lang]
    snapshot = {}
    chunk = 50
    for i in range(0, len(titles), chunk):
        part = titles[i:i + chunk]
        data = _api_get(
            url,
            {
                "action": "query",
                "prop": "extracts",
                "exintro": "1",       # 只要首段
                "explaintext": "1",   # 返回纯文本而非 HTML
                "titles": "|".join(part),
                "redirects": "1",     # 跟随重定向取目标条目
            },
            user_agent,
        )
        pages = data.get("query", {}).get("pages", {})
        for pid, page in pages.items():
            title = page.get("title", "")
            snapshot[title] = (page.get("extract") or "")[:max_chars]  # 截断到 max_chars
        time.sleep(0.2)
    return snapshot


def fetch(field, lang, category, out_path, settings):
    """抓取一个分类并追加写入 raw JSONL，返回写入条数。"""
    ua = settings.wikipedia["user_agent"]
    max_chars = settings.wikipedia["max_chars"]
    titles = category_members(lang, category, ua)
    snap = _extracts(lang, titles, ua, max_chars)

    docs = []
    for title, text in snap.items():
        # 过滤过短/空条目（摘要不足 20 字视为无信息量）
        if text and len(text) >= 20:
            safe = category.replace(" ", "_")
            docs.append(
                {
                    "id": f"wikipedia_{lang}_{safe}_{title.replace(' ', '_')}",
                    "title": title,
                    "lang": lang,
                    "field": field,
                    "text": text,
                    "url": f"https://{'zh' if lang == 'zh' else 'en'}.wikipedia.org/wiki/{urllib.parse.quote(title.replace(' ', '_'))}",
                    "source": "wikipedia",
                    "meta": {"category": category},
                }
            )
    append_jsonl(out_path, docs)
    return len(docs)