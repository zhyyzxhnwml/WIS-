"""百度百科数据源（国内可直连，无需外网）。

抓取 `https://baike.baidu.com/item/<词条>` 页面，提取首段摘要
（class="lemma-summary"），作为跨领域实例语料。

说明：
- 摘要保留出处 `url`，供合规引用。
- 词条可能重定向/消歧义，返回的 title 以页面实际标题为准。

使用标准库 urllib + 正则做轻量 HTML 解析，尽量少引第三方依赖。
"""
import html
import re
import time
import urllib.parse
import urllib.request

from .base import append_jsonl

# 百度百科词条端点（词条名经 URL 编码拼接）
_ENDPOINT = "https://baike.baidu.com/item/"


class BaikeFetchError(Exception):
    """百度百科页抓取失败（多次重试仍失败）时抛出。"""
    pass


def _http_get(url, user_agent, retries=3, timeout=45):
    """GET 网页内容；带上浏览器头以减少被反爬，失败线性退避重试。"""
    last = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": user_agent,
                    "Accept-Language": "zh-CN,zh;q=0.9",
                    "Referer": "https://baike.baidu.com/",  # 模拟从百科站内发起请求
                },
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                # errors="replace"：个别非法字节不中断解析
                return resp.read().decode("utf-8", errors="replace")
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(2 * attempt + 1)  # 线性退避：1s, 3s, 5s ...
    raise BaikeFetchError(f"baike request failed: {last}")


def _extract_title(html_text):
    """提取页面标题：优先取 h1（词条名），取不到退回 <title>。"""
    m = re.search(r"<h1[^>]*>(.*?)</h1>", html_text, re.S)
    if m:
        return strip_tags(m.group(1))
    m = re.search(r'<title>(.*?)</title>', html_text, re.S)
    return strip_tags(m.group(1)) if m else ""


def strip_tags(s):
    """去除 style/script 及所有 HTML 标签、反转义、压缩空白。"""
    s = re.sub(r"<style.*?</style>", "", s, flags=re.S)
    s = re.sub(r"<script.*?</script>", "", s, flags=re.S)
    s = re.sub(r"<[^>]+>", "", s)
    s = html.unescape(s)  # 反转义 &amp; &lt; 等实体
    return re.sub(r"\s+", " ", s).strip()


def _extract_summary(html_text):
    """取 lemma-summary 摘要；找不到则逐级退回到普通段落 / meta description。"""
    # 优先：带嵌套 div 的 lemma-summary 块
    m = re.search(r'<div[^>]*class="[^"]*lemma-summary[^"]*"[^>]*>(.*?)</div>\s*</div>', html_text, re.S)
    if not m:
        # 退一步：单层 lemma-summary
        m = re.search(r'<div[^>]*class="[^"]*lemma-summary[^"]*"[^>]*>(.*?)</div>', html_text, re.S)
        if not m:
            # 摘要以外，退一步抓正文第一段 para
            m = re.search(r'<div[^>]*class="[^"]*para[^"]*"[^>]*>(.*?)</div>', html_text, re.S)
            if not m:
                # 最后一招：meta description 里的摘要
                mm = re.search(r'<meta name="description"\s+content="([^"]+)"', html_text)
                return html.unescape(mm.group(1)) if mm else ""
    if not m:
        return ""
    return strip_tags(m.group(1))


def fetch(field, keywords, out_path, settings):
    """抓取一组词条，追加写入 raw JSONL。返回写入条数。"""
    ua = settings.baike.get("user_agent") or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    max_chars = settings.baike["max_chars"]
    docs = []
    seen = set()
    for kw in keywords:
        if kw in seen:  # 词条去重
            continue
        seen.add(kw)
        safe = urllib.parse.quote(kw)  # URL 编码中文词条名
        url = _ENDPOINT + safe
        html_text = _http_get(url, ua)
        title = _extract_title(html_text)
        summary = _extract_summary(html_text)[:max_chars]
        if not title or len(summary) < 20:  # 无标题或摘要过短视为低质量，跳过
            print(f"[baike] 跳过低质量词条: {kw}")
            continue
        docs.append(
            {
                "id": f"baike_{field}_{kw}",
                "title": title,
                "lang": "zh",
                "field": field,
                "text": summary,
                "url": url,
                "source": "baike",
                "meta": {"keyword": kw},
            }
        )
        time.sleep(0.3)  # 限速，避免触发反爬
    if docs:
        append_jsonl(out_path, docs)
    return len(docs)