"""专利数据源：PatentsView (USPTO 官方数据，免费无 key)。

返回 PatentsView v1（search.patentsview.org/api/v1/patent）。
注意：需要能访问外网。

按检索词分页拉取专利，过滤掉摘要过短的，组装成 raw 文档追加写入 JSONL。
"""
import json
import time
import urllib.parse
import urllib.request

from .base import append_jsonl

# 每个专利需要拉取的字段（含首条 CPC 分类标题用于标注技术方向）
DEFAULT_FIELDS = ["patent_id", "patent_title", "patent_abstract", "patent_date", "patent_first_cpc_class_1.title"]


def _post(url, payload, timeout=90, retries=3):
    """POST JSON 载荷请求 PatentsView，失败按指数退避重试。"""
    data = json.dumps(payload).encode("utf-8")
    last = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    "User-Agent": "InnoMapCrawler/0.1 (educational project)",
                    "Content-Type": "application/json; charset=utf-8",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(2 * 2 ** min(attempt, 3))  # 退避：2s, 4s, 8s ...
    raise RuntimeError(f"patentsview failed: {last}")


def _query(field, query, page, page_size):
    """查询单个检索词的一页，返回 (docs, total)。

    total 为命中总数，用于判断是否还有下一页。
    """
    payload = {
        "q": {"text": query, "_and": [{"patent_granted": "true"}]},  # 只取已授权专利
        "f": DEFAULT_FIELDS,
        "o": {"size": page_size, "page": page},
    }
    data = _post("https://search.patentsview.org/api/v1/patent/", payload)
    patents = data.get("patents", [])
    docs = []
    for pat in patents:
        title = (pat.get("patent_title") or "").strip()
        abstract = (pat.get("patent_abstract") or "").strip()
        if len(abstract) < 40:  # 摘要过短无法支撑抽取，直接丢弃
            continue
        # CPC 分类标题可能在嵌套 dict 中，也可能是原始字符串，统一规整
        cpc = ""
        cpc_obj = pat.get("patent_first_cpc_class_1")
        if isinstance(cpc_obj, dict):
            cpc = (cpc_obj.get("title") or "").strip() or ""
        docs.append(
            {
                "id": f"patent_{pat.get('patent_id')}",
                "title": title,
                "lang": "en",
                "field": field,
                "text": abstract,
                "url": f"https://patents.google.com/patent/{pat.get('patent_id')}",
                "source": "patents",
                "meta": {
                    "patent_id": pat.get("patent_id"),
                    "date": pat.get("patent_date"),
                    "cpc": cpc,
                    "query": query,
                },
            }
        )
    return docs, int(data.get("total_patent_count") or 0)


def fetch(field, queries, out_path, settings, pages_per_query=3):
    """对每个检索词抓取若干页，去重后追加写入 raw JSONL，返回新增条数。

    用全局 seen 集合跨检索词去重（同一专利可能被多个检索词命中）。
    """
    page_size = settings.patents["page_size"]
    seen = set()
    total_added = 0
    for query in queries:
        for page in range(1, pages_per_query + 1):
            docs, total = _query(field, query, page, page_size)
            fresh = [d for d in docs if d["id"] not in seen]
            for d in fresh:
                seen.add(d["id"])
            if fresh:
                append_jsonl(out_path, fresh)
                total_added += len(fresh)
            # 已取满所有命中结果则提前结束本检索词
            if page * page_size >= total:
                break
            time.sleep(1.0)  # 限速，避免触发 API 限制
    return total_added