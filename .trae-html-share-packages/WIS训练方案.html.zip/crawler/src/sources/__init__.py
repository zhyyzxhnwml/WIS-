"""数据源子包：维基、专利、百度百科、GitHub/Gitee。

各模块提供统一的 `fetch(..., out_path, settings)` 入口，
将抓取结果以 raw JSONL 追加写入 out_path。
"""