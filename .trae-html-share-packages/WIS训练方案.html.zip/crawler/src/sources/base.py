"""统一数据源接口与中间产物格式。

每个数据源（维基、专利…）产出 raw JSONL，行结构统一为：
{
  "id": "wikipedia_zh_仿生学_x",       # 唯一
  "title": "...",
  "lang": "zh",
  "field": "生物",                      # 领域先验（种子分类）
  "text": "条目/摘要正文",
  "url": "...",
  "source": "wikipedia" | "patents",
  "meta": {...}
}
后续 extract 只消费本文件，因此数据源可替换、可在有网环境单独跑。

本模块提供 raw JSONL 的读写工具函数，供各数据源与抽取阶段复用。
"""
import json
import pathlib


def iter_jsonl(path: pathlib.Path):
    """逐行读取 JSONL 并 yield 每行的字典。

    - 用 utf-8-sig 读入以兼容带 BOM 的文件（如 Excel 生成）
    - 跳过空行；不存在的文件会由调用方预先保证存在
    """
    with open(path, "r", encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            yield json.loads(line)


def append_jsonl(path: pathlib.Path, docs):
    """把若干文档追加写入 JSONL 文件。

    - 每行一条 JSON（ensure_ascii=False 保留中文），以 \n 结尾
    - 一次性批量写入（每批仅打开一次文件），避免逐条 IO
    """
    buf = []
    for d in docs:
        buf.append(json.dumps(d, ensure_ascii=False))
    with open(path, "a", encoding="utf-8") as f:
        f.write("\n".join(buf) + "\n")