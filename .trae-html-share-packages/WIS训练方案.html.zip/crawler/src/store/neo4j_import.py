"""将清洗后的记录导出为 Neo4j Cypher。

与现有库的图谱建模保持一致（数据/图数据库/import_graph.cypher）：
  问题-具备功能->功能-运用TRIZ原理->TRIZ原理-启发->概念-参考->实例
  概念-所属领域->领域, 领域-包含->实例, 实例-生成->方案
关系命名: 参考 / 包含 / 所属领域 / 运用TRIZ原理 / 启发 / 生成
对每条记录生成一段独立 MERGE 语句（幂等，可整文件重复执行）。

规范化：
- 领域短名 -> 图谱全称（避免领域节点分叉）
- LLM 生成的功能文本 -> 聚合到 10 大规范功能（保持功能体系稳定）
- TRIZ 名称按「TRIZ_40发明原理_公开数据.csv」校准到标准名称与编号
"""
import csv
import pathlib

# 领域短名 -> 图谱全称（避免与现有 8 个领域节点分叉）
FIELD_MAP = {
    "生物": "生物领域",
    "机械": "机械工程领域",
    "材料": "材料科学领域",
    "物理": "物理领域",
    "化工": "化学化工领域",
    "电子信息": "电子信息领域",
    "电子": "电子信息领域",
    "航空": "航空航天领域",
    "航天": "航空航天领域",
    "航空航天": "航空航天领域",
    "建筑": "建筑结构领域",
    "能源": "能源动力领域",
    "算法": "算法领域",
}

# 规范功能（与现有库 10 个功能节点同名 MERGE 合并）
STANDARD_FUNCTIONS = [
    "吸收冲击能量",
    "延长冲击作用时间",
    "储存并回弹能量",
    "增大接地接触面积",
    "自适应地形",
    "保护核心部件",
    "轻量化承载",
    "高效散热",
    "降低摩擦磨损",
    "衰减振动",
]

# 功能文本 -> 规范功能（关键词匹配，顺序敏感：靠前的更具体）
FUNC_RULES = [
    ("吸收冲击能量", ["吸能", "吸震", "抗冲击", "抗撞", "碰撞", "缓冲", "冲击", "抗震", "吸收"]),
    ("延长冲击作用时间", ["作用时间", "减速", "行程"]),
    ("储存并回弹能量", ["回弹", "储能", "回馈", "蓄能", "释放能量", "储"]),
    ("增大接地接触面积", ["接地", "接触面积", "着陆", "支撑面", "触地"]),
    ("自适应地形", ["自适应", "复杂地形", "地形", "可展", "折叠", "展开", "变形", "自调节"]),
    ("保护核心部件", ["保护", "隔离", "防护", "封装", "密封"]),
    ("轻量化承载", ["轻量", "减重", "轻质", "承重", "承载", "强度", "刚度"]),
    ("高效散热", ["散热", "导热", "降温", "制冷", "冷却", "温度", "均温", "吸热", "放热", "蓄热", "保温", "隔热", "温控", "热"]),
    ("降低摩擦磨损", ["摩擦", "磨损", "耐磨", "润滑", "减磨"]),
    ("衰减振动", ["振动", "减振", "隔振", "阻尼", "隔声", "降噪", "抑制", "平息", "声"]),
]


def _load_triz_map():
    """编号 -> 标准名称（读项目根数据目录的标准 TRIZ 表）。"""
    # 定位到项目根「数据/公开数据/TRIZ_40发明原理_公开数据.csv」
    csv_path = pathlib.Path(__file__).resolve().parents[3] / "数据" / "公开数据" / "TRIZ_40发明原理_公开数据.csv"
    mapping = {}
    if csv_path.exists():
        with open(csv_path, "r", encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                no = (row.get("编号") or "").strip()
                name = (row.get("名称") or "").strip()
                if no and name:
                    mapping[no] = name
    return mapping


TRIZ_MAP = _load_triz_map()  # 模块加载时一次性读入标准 TRIZ 表


def _norm_function(text: str):
    """把功能文本按关键词聚合成规范功能；无匹配返回 None。"""
    if not text:
        return None
    for std, keys in FUNC_RULES:
        for k in keys:
            if k in text:
                return std
    return None


def _norm_triz(name: str, no):
    """把 TRIZ 原理名/编号校准为标准（名称, 编号）。

    - 编号能直接命中标准表则直接用标准名
    - 否则若编号在 [1,40] 内，退回标准名或原样保留编号
    - 否则用名称前缀匹配标准名
    """
    no = (str(no or "")).strip()
    if no in TRIZ_MAP:
        return TRIZ_MAP[no], no
    if no and no.isdigit() and 1 <= int(no) <= 40:
        return TRIZ_MAP.get(no, name), no
    if name:
        for std, no_std in TRIZ_MAP.items():
            if name.startswith(std) or name == std:
                return std, no_std
    return (name or "").strip(), no


def _esc(v):
    """把值转义成 Cypher 字符串字面量：转义反斜杠、双引号、换行；None 转 null。"""
    if v is None:
        return "null"
    s = str(v)
    s = s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
    return f'"{s}"'


def _props_str(props):
    """拼接属性映射字符串（如 `name:"x", 描述:"y"`）。当前未直接使用，保留备用。"""
    return ",".join(f"{k}:{_esc(v)}" for k, v in props.items())


BATCH_SIZE = 40  # 每条记录约 20+ 行 cypher；按批加“;”拆分为多事务，避免单条超长语句撑爆 Neo4j JVM 堆


def build_cypher(records):
    """把清洗后的记录生成整段 Cypher 文本（多 BATCH 用 ';' 拆分事务）。"""
    lines = [
        "// ============================================================",
        "// InnoMap 知识图谱 —— 爬取扩充数据导入（crawler 自动生成）",
        "// 与 数据/图数据库/import_graph.cypher 同一套标签/关系，可重复执行（MERGE 幂等）",
        "// 每 BATCH_SIZE 条加分号拆分为独立事务导入",
        "// ============================================================",
        "",
    ]
    used = 0      # 生成节点变量名序号（c1/e1/d1/s1 ...）
    attached = 0  # 已挂接到规范功能链的记录数
    for i, rec in enumerate(records, 1):
        concept = (rec.get("concept") or "").strip()
        instance = (rec.get("instance") or "").strip()
        field = (rec.get("field") or "未知").strip()
        if not concept or not instance:
            continue  # 缺语义字段的记录跳过

        used += 1
        # 变量名：c=概念 e=实例 d=领域 s=方案，每个记录编号唯一
        c, e, d, s = f"c{used}", f"e{used}", f"d{used}", f"sc{used}"
        url = _esc(rec.get("url") or "")

        lines.append(f"// —— {rec.get('title') or concept} [{rec.get('raw_id') or ''}] ——")

        # 核心：概念-参考->实例，实例属于领域，概念关联领域（均幂等 MERGE）
        lines.append(f"MERGE ({c}:概念 {{ name: {_esc(concept)} }}) ON CREATE SET {c}.描述 = {_esc(rec.get('concept_desc'))}, {c}.来源 = {url}")
        lines.append(f"MERGE ({e}:实例 {{ name: {_esc(instance)} }}) ON CREATE SET {e}.描述 = {_esc(rec.get('instance_desc'))}, {e}.来源 = {url}")
        lines.append(f"MERGE ({d}:领域 {{ name: {_esc(FIELD_MAP.get(field, field))} }})")
        lines.append(f"MERGE ({d})-[:包含]->({e})")
        lines.append(f"MERGE ({c})-[:所属领域]->({d})")
        w = rec.get("weight")
        if w is None:
            w = 0.8  # 缺失权重默认给 0.8
        lines.append(f"MERGE ({c})-[:参考 {{ weight: {w} }}]->({e})")

        # TRIZ（校准到标准名称）+ 功能（聚合到规范功能）
        triz, tno = _norm_triz((rec.get("triz_principle") or "").strip(), rec.get("triz_no"))
        fun = _norm_function(rec.get("function") or "")
        if triz:
            # 有 TRIZ：功能-运用TRIZ原理->TRIZ原理-启发->概念
            t = f"t{used}"
            lines.append(f"MERGE ({t}:TRIZ原理 {{ name: {_esc(triz)} }}) ON CREATE SET {t}.编号 = {_esc(tno)}")
            lines.append(f"MERGE ({t})-[:启发]->({c})")
            if fun:
                f = f"f{used}"
                lines.append(f"MERGE ({f}:功能 {{ name: {_esc(fun)} }})")
                lines.append(f"MERGE ({f})-[:运用TRIZ原理]->({t})")
                attached += 1
        elif fun:
            # 无 TRIZ但有功能：功能-启发->概念
            f = f"f{used}"
            lines.append(f"MERGE ({f}:功能 {{ name: {_esc(fun)} }})")
            lines.append(f"MERGE ({f})-[:启发]->({c})")
            attached += 1

        # 实例 → 方案（爬取数据无独立问题节点，用功能聚合）
        scheme_name = f"基于{concept}的{instance}应用方案"
        lines.append(f"MERGE ({s}:方案 {{ name: {_esc(scheme_name)} }}) ON CREATE SET {s}.创新度 = 80, {s}.融合 = false")
        lines.append(f"MERGE ({e})-[:生成]->({s})")
        lines.append("")
        # 每满 BATCH_SIZE 条加 ';' 拆事务
        if i % BATCH_SIZE == 0:
            lines.append(";")
    # 余下不足一个 BATCH 的记录也要补一个结尾分号
    if len(records) % BATCH_SIZE != 0:
        lines.append(";")

    # 在头部注释里插入统计信息
    lines.insert(2, f"// {used} 条记录，{attached} 条已挂接规范功能链")
    return "\n".join(lines)


def export(records, out_path):
    """把记录导出到 .cypher 文件，返回记录总条数。"""
    text = build_cypher(records)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(text)
    return len(records)