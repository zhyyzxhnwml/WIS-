"""DeepSeek LLM 抽取客户端。

- 并发抽取（ThreadPoolExecutor）
- 失败重试 + JSON 清洗（去除 markdown 代码块、截取第一个 { ... }）
"""
import concurrent.futures
import json
import re
import time
import urllib.request

from .prompts import SYSTEM_PROMPT, build_user_prompt


class ExtractError(Exception):
    """抽取最终失败（重试耗尽或 JSON 无法解析）时抛出。"""
    pass


def _clean_json(text):
    """把 LLM 返回文本清洗成 JSON 并解析。

    - 去掉 markdown 代码块围栏（```json ... ```）
    - 截取第一个 `{` 到最后一个 `}` 之间的内容再解析
    - 找不到配对花括号则抛出 ExtractError
    """
    text = text.strip()
    # 去掉可能的 markdown 代码块围栏
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        raise ExtractError(f"no json object: {text[:200]}")
    return json.loads(text[start:end + 1])


def _chat_once(base_url, api_key, model, temperature, system, user, timeout):
    """调用一次 OpenAI 兼容的 /chat/completions，返回回复文本。"""
    payload = {
        "model": model,
        "temperature": temperature,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        base_url.rstrip("/") + "/chat/completions",  # 兼容结尾带/的 base_url
        data=data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = json.loads(resp.read().decode("utf-8"))
    return body["choices"][0]["message"]["content"]


class DeepSeekExtractor:
    """DeepSeek 结构化抽取器：并发抽取 + 失败重试 + usable 过滤。"""

    def __init__(self, config, api_key):
        self.cfg = config
        self.key = api_key
        if not self.key:
            raise ValueError("未配置 DEEPSEEK_API_KEY")

    def _extract_one(self, doc):
        """抽取单篇文档，返回记录；usable=false 返回 None；重试耗尽抛异常。"""
        user = build_user_prompt(doc["text"], doc.get("title", ""), doc.get("lang", "zh"))
        last = None
        # 最多重试 max_retries 次（共 max_retries+1 次尝试），指数退避
        for attempt in range(self.cfg["max_retries"] + 1):
            try:
                content = _chat_once(
                    self.cfg["base_url"],
                    self.key,
                    self.cfg["model"],
                    self.cfg["temperature"],
                    SYSTEM_PROMPT,
                    user,
                    self.cfg["timeout"],
                )
                parsed = _clean_json(content)
                if parsed.get("usable") is True:
                    return self._wrap(doc, parsed)
                return None  # usable=false，跳过
            except Exception as e:  # noqa: BLE001
                last = e
                time.sleep(2 ** attempt + 1)  # 退避：2s, 3s, 5s ...
        raise ExtractError(f"doc {doc['id']}: {last}")

    def _wrap(self, doc, parsed):
        """把 LLM 返回的字段与原文元数据组装成标准记录结构。"""
        return {
            "raw_id": doc["id"],
            "title": doc.get("title", ""),
            "lang": doc.get("lang", "zh"),
            # 领域兜底：LLM 未给则继承源文档的领域先验
            "field": parsed.get("field") or doc.get("field"),
            "source": doc.get("source", ""),
            "url": doc.get("url", ""),
            "instance": parsed.get("instance"),
            "instance_desc": parsed.get("instance_desc"),
            "concept": parsed.get("concept"),
            "concept_desc": parsed.get("concept_desc"),
            "function": parsed.get("function"),
            "triz_principle": parsed.get("triz_principle"),
            "triz_no": parsed.get("triz_no"),
            "weight": parsed.get("weight"),
            "why": parsed.get("why"),
        }

    def extract_many(self, docs, max_workers):
        """并发抽取，返回 (kept_records, errors)。

        - 用线程池并行调 LLM，as_completed 逐条收结果
        - kept 追加成功记录，errs 追加失败摘要（id + 错误信息）
        """
        kept = []
        errs = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = {pool.submit(self._extract_one, d): d for d in docs}
            for fut in concurrent.futures.as_completed(futures):
                d = futures[fut]
                try:
                    res = fut.result()
                    if res:
                        kept.append(res)
                except Exception as e:  # noqa: BLE001
                    errs.append({"id": d["id"], "error": str(e)[:200]})
        return kept, errs