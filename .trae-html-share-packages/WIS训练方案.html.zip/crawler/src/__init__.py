"""InnoMap 爬取数据管道 src 包。

本包是 crawler 数据管道的内核，包含：
- settings:      配置加载
- sources:       各数据源（维基/专利/百科/GitHub/Gitee）抓取
- extract:       DeepSeek 结构化抽取
- pipeline:      清洗/校验/质检
- store:         Neo4j 导入导出
"""