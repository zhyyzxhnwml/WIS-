"""InnoMap 数据管道 CLI。

命令行入口，子命令对应数据管道各阶段：

用法（从 crawler/ 目录）:
  python -m src.cli wiki --lang zh            # 抓取维基每个种子分类（zh/en/default=both）
  python -m src.cli patents --pages 3        # 抓取专利检索词
python -m src.cli extract                   # LLM 抽取 raw/*.jsonl -> extracted/records.jsonl
   python -m src.cli validate                  # 统计 + 生成抽样人工核对清单
   python -m src.cli quality                   # 抽取结果自动质检（分级问题清单）
   python -m src.cli export                    # 生成 Neo4j 导入 .cypher
"""
import argparse
import csv
import json
import pathlib
import sys

from .settings import load_settings
from .sources import baidu, github_open, patents, wikipedia
from .sources.base import append_jsonl, iter_jsonl
from .extract.llm import DeepSeekExtractor
from .pipeline import clean, quality, validate
from .store import neo4j_import


def cmd_wiki(args):
    """子命令 wiki：按语言遍历所有种子分类并抓取维基条目。"""
    st = load_settings()
    out = st.raw_dir / "wikipedia.jsonl"  # 统一追加到同一原始语料文件
    total = 0
    for field, lang, category in st.wikipedia_fields():
        # 仅在指定语言与配置匹配时抓取（--lang zh/en/both）
        if args.lang != "both" and lang != args.lang:
            continue
        n = wikipedia.fetch(field, lang, category, out, st)
        total += n
        print(f"[wiki] {lang}/{category} -> {n} docs")
    print(f"完成，共 {total} docs -> {out}")


def cmd_patents(args):
    """子命令 patents：对每个检索词抓取指定页数。"""
    st = load_settings()
    out = st.raw_dir / "patents.jsonl"
    total = 0
    for field, queries in st.patent_queries():
        n = patents.fetch(field, queries, out, st, pages_per_query=args.pages)
        total += n
        print(f"[patents] {field} -> {n} docs")
    print(f"完成，共 {total} docs -> {out}")


def cmd_baike(args):
    """子命令 baike：抓取百度百科词条。"""
    st = load_settings()
    out = st.raw_dir / "baike.jsonl"
    total = 0
    for field, keywords in st.baike_topics():
        n = baidu.fetch(field, keywords, out, st)
        total += n
        print(f"[baike] {field} -> {n} docs")
    print(f"完成，共 {total} docs -> {out}")


def cmd_github(args):
    """子命令 github / gitee：按仓库配置拉取开源语料。"""
    st = load_settings()
    target = args.source  # "github" 或 "gitee"
    # 根据目标平台取对应依赖配置中的仓库列表
    repos = (st.gitee if target == "gitee" else st.github).get("repos", [])

    out = st.raw_dir / f"{target}.jsonl"  # github.jsonl / gitee.jsonl
    total = 0
    for repo in repos:
        # 仓库可显式声明 host 覆盖平台，默认可与 target 一致
        host = repo.get("host", target)
        n = github_open.fetch(repo, out, st)
        total += n
        print(f"[{target}] {repo.get('owner')}/{repo.get('repo')}:{repo.get('path', '')} -> {n} docs")
    print(f"完成，共 {total} docs -> {out}")


def _load_all_raw(st):
    """读取 raw_dir 下所有 *.jsonl，合并为原始文档列表。"""
    docs = []
    for p in sorted(st.raw_dir.glob("*.jsonl")):
        docs.extend(iter_jsonl(p))
        print(f"  读取 {p.name}: {p.stat().st_size} B")
    return docs


def cmd_extract(args):
    """子命令 extract：调用 DeepSeek 对 raw 文档做结构化抽取。

    默认跳过已成功（records.jsonl 中已存在 raw_id 的）文档；
    --force 则忽略历史结果全量重抽。
    """
    st = load_settings()
    all_docs = _load_all_raw(st)
    if not all_docs:
        print("没有 raw 数据，先运行 wiki / patents。")
        sys.exit(1)
    # 已成功的记录 id 集合（records.jsonl 中每条含 raw_id）
    done_ids = {r.get("raw_id") for r in iter_jsonl(st.extracted_dir / "records.jsonl")}
    if args.force:
        docs = all_docs
        print(f"强制重抽 {len(docs)} 篇")
    else:
        # 仅抽取尚未成功的文档
        docs = [d for d in all_docs if d["id"] not in done_ids]
        print(f"待抽取 {len(docs)} 篇（跳过已成功 {len(all_docs) - len(docs)} 篇）")
    if not docs:
        print("无待抽取文档（全部已成功）。失败重抽：先删 data/output/extract_errors.jsonl 重跑，或用 --force 全量。")
        return
    extractor = DeepSeekExtractor(st.deepseek, st.deepseek_key)
    kept, errs = extractor.extract_many(docs, max_workers=st.deepseek["max_concurrency"])
    out_path = st.extracted_dir / "records.jsonl"
    append_jsonl(out_path, kept)  # 增量追加；如重复运行可先删该文件
    if errs:
        err_path = st.out_dir / "extract_errors.jsonl"
        append_jsonl(err_path, errs)
        print(f"抽取失败 {len(errs)} 条 -> {err_path}")
    print(f"抽取完成: 保留 {len(kept)} / 总 {len(docs)} -> {out_path}")


def cmd_quality(args):
    """子命令 quality：对清洗后的记录做自动质检，输出分级问题清单。"""
    st = load_settings()
    recs = list(iter_jsonl(st.extracted_dir / "records.jsonl"))
    # 先按与去重一致的最小相似度清洗
    cleaned = clean.clean_records(recs, min_sim=st.pipeline["dedup_min_similarity"])
    report, issues = quality.check(cleaned)
    # 写入 JSON 报告
    report_path = st.out_dir / "quality_report.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    # 写入 CSV 问题清单
    issues_path = st.out_dir / "quality_issues.csv"
    quality.write_issues(issues, issues_path)
    # 打印分级汇总
    print(f"质检 {report['total']} 条 -> 问题 {report['issues']} (high {report['by_level']['high']} / "
          f"medium {report['by_level']['medium']} / low {report['by_level']['low']})")
    print(f"报告: {report_path}")
    if issues:
        print(f"问题清单: {issues_path}")
        print("按规则分布:", report["by_rule"])
    print("高危(type=required_missing / generic_concept)与中等(short_*)项，人工复核后决定是否删除或修改相应语料。")


def cmd_validate(args):
    """子命令 validate：统计字段完整率/分布，并生成抽样人工核对清单。"""
    st = load_settings()
    recs = list(iter_jsonl(st.extracted_dir / "records.jsonl"))
    # 与其它子命令一致的清洗（去重）
    cleaned = clean.clean_records(recs, min_sim=st.pipeline["dedup_min_similarity"])
    report = validate.analyze(cleaned)

    # 统计报告写入 out_dir
    report_path = st.out_dir / "stats.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    # 抽样清单（CSV，utf-8-sig 便于 Excel 直接打开识别中文）
    rows, fname = validate.sample_checklist(cleaned, ratio=st.validate["sample_ratio"], n_max=600)
    if rows:
        csv_path = st.out_dir / fname
        with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()  # 写表头
            writer.writerows(rows)
        print(f"抽样清单: {csv_path}")

    print(f"去重前 {len(recs)} -> 去重后 {report['total']}")
    print("字段完整率:", report["completeness"])
    print("领域分布:", report["field_distribution"])
    print("语言分布:", report["lang_distribution"])
    print("来源分布:", report["source_distribution"])
    print(f"统计报告: {report_path}")


def cmd_export(args):
    """子命令 export：把清洗后的记录导出为 Neo4j 导入 Cypher 脚本。"""
    st = load_settings()
    recs = list(iter_jsonl(st.extracted_dir / "records.jsonl"))
    cleaned = clean.clean_records(recs, min_sim=st.pipeline["dedup_min_similarity"])
    out_path = st.out_dir / "graph_import.cypher"
    n = neo4j_import.export(cleaned, out_path)
    print(f"导出 {n} 条记录 -> {out_path}")


def main():
    """解析命令行参数并分发到对应子命令函数。"""
    parser = argparse.ArgumentParser(prog="innomap-crawler", description="InnoMap 知识图谱数据管道")
    sub = parser.add_subparsers(dest="cmd")

    # 各子命令定义：参数 + 绑定处理函数（--lang 可过滤维基语言）
    p_wiki = sub.add_parser("wiki", help="抓取维基百科种子分类")
    p_wiki.add_argument("--lang", choices=["zh", "en", "both"], default="zh")
    p_wiki.set_defaults(func=cmd_wiki)

    p_pat = sub.add_parser("patents", help="抓取专利检索词")
    p_pat.add_argument("--pages", type=int, default=3, help="每个检索词抓取页数")
    p_pat.set_defaults(func=cmd_patents)

    p_bk = sub.add_parser("baike", help="抓取百度百科词条（国内可直连）")
    p_bk.set_defaults(func=cmd_baike)

    p_gh = sub.add_parser("github", help="拉取 GitHub 开源语料（contents API）")
    p_gh.set_defaults(func=cmd_github, source="github")

    p_gt = sub.add_parser("gitee", help="拉取 Gitee 开源语料（国内可直连）")
    p_gt.set_defaults(func=cmd_github, source="gitee")

    p_ext = sub.add_parser("extract", help="LLM 结构化抽取（默认跳过已成功，--force 全量重抽）")
    p_ext.add_argument("--force", action="store_true", help="忽略已成功记录全量重抽")
    p_ext.set_defaults(func=cmd_extract)

    p_val = sub.add_parser("validate", help="统计 + 抽样核对清单")
    p_val.set_defaults(func=cmd_validate)

    p_q = sub.add_parser("quality", help="抽取结果自动质检（规则扫描，输出分级问题清单）")
    p_q.set_defaults(func=cmd_quality)

    p_exp = sub.add_parser("export", help="导出 Neo4j 导入脚本")
    p_exp.set_defaults(func=cmd_export)

    args = parser.parse_args()
    # 未提供子命令时打印帮助并退出
    if not getattr(args, "func", None):
        parser.print_help()
        sys.exit(1)
    args.func(args)


if __name__ == "__main__":
    main()