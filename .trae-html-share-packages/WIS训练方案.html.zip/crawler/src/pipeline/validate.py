"""校验与统计：
- 字段完整率统计
- 领域分布
- 生成 20% 抽样人工核对清单（markdown 表格）

对清洗后的记录做数据体检，帮助人工评估抽取质量。
"""
import collections
import csv
import json


def analyze(records):
    """返回统计报告 dict：总量、各字段完整率、领域/语言/来源分布。"""
    total = len(records)
    # 需要统计完整率的核心字段
    fields = ["concept", "concept_desc", "instance", "instance_desc", "field", "function", "weight", "why"]
    completeness = {}
    for f in fields:
        miss = sum(1 for r in records if not r.get(f))  # 值为空的记录数
        # 完整率 = 非空占比，取整到 3 位小数；total 为 0 时避免除零
        completeness[f] = round(1 - miss / max(total, 1), 3)

    # 各维度的分布计数（空值归入“未知”类）
    field_dist = collections.Counter(r.get("field") or "未知" for r in records)
    lang_dist = collections.Counter(r.get("lang") or "unknown" for r in records)
    source_dist = collections.Counter(r.get("source") or "unknown" for r in records)

    return {
        "total": total,
        "completeness": completeness,
        "field_distribution": dict(field_dist),
        "lang_distribution": dict(lang_dist),
        "source_distribution": dict(source_dist),
    }


def sample_checklist(records, ratio=0.2, n_max=600):
    """按比例均匀抽样，用于人工核对。返回 (csv 行列表, 文件名)。

    用固定步长 `records[::step]` 均匀采样，避免随机抽样的偶然性。
    """
    if not records:
        return [], None
    n = max(1, min(n_max, int(len(records) * ratio)))  # 抽样本数
    step = max(1, len(records) // n)                     # 均匀步长
    picks = records[::step][:n]
    rows = []
    for r in picks:
        rows.append(
            {
                "raw_id": r["raw_id"],
                "title": r.get("title", ""),
                "concept": r.get("concept", ""),
                "instance": r.get("instance", ""),
                "field": r.get("field", ""),
                "function": r.get("function", ""),
                "weight": r.get("weight", ""),
                "why": r.get("why", ""),
                "url": r.get("url", ""),
                "人工判定": "",  # 供人工填写是否合格
            }
        )
    return rows, f"sample_checklist_{n}.csv"