"""清洗与去重。

- 字段规范化（trim、空值处理）
- 按 (concept, instance) 做语义去重：
  先按归一化后的名称精确去重，再按领域与概念并集、元组归一化相似度去重
- 阈值降低时逐步扩展候选池，避免 O(n^2)

注意：`clean_records` 目前是「首个出现即保留」的全量两两比较实现，
当记录量很大且仅有部分近似的场景下会接近 O(n^2)，属可优化点。
"""
import re


def norm(s):
    """归一化：去空白、标点、全半角、小写。

    用于比较的两个字符串都归一化后，再参与精确/'字符集相似度'去重，
    从而把"全角/半角、括号注释、连接符"等噪声视为一致。
    """
    if not s:
        return ""
    s = str(s).strip().lower()
    # 去掉各类分隔/标点（含中文全角标点）
    s = re.sub(r"[\s\-\/．。、，,；;：:··]+\s*", "", s)
    # 去掉括号及其中的内容（如 "材料（XX）" -> "材料"）
    s = re.sub(r"[\\(（].*?[\\)）]", "", s)
    return s


def _trim(record):
    """预留的字段裁剪钩子（当前未启用，直接原样返回）。"""
    for k in ("field", "function", "weight"):
        continue  # reserved
    return record


def similarity(a, b):
    """简化相似度：编辑距离阈值版 Jaccard（字符集合并查重）。

    计算两个字符串归一化后字符集合的 Jaccard 系数：交集大小 / 并集大小。
    完全一致则 1.0，完全无关则 0.0；用于近似去重与质量抽检判定。
    """
    sa, sb = norm(a), norm(b)
    if not sa or not sb:
        return 0.0
    inter = len(set(sa) & set(sb))
    union = len(set(sa) | set(sb))
    return inter / union if union else 0.0


def clean_records(records, min_sim=0.92):
    """返回去重后的记录列表，保留首次出现的记录。

    剔除 concept/instance 缺失的记录；去重规则：
    - 精确去重：归一化后的 (concept, instance) 完全相同
    - 近似去重：同领域，且 concept、instance 两维相似度都 ≥ min_sim
    """
    seen_names = {}  # (norm_concept, norm_instance) -> 首次记录，保留第一份
    final = []
    for rec in records:
        concept = rec.get("concept") or ""
        instance = rec.get("instance") or ""
        if not concept or not instance:
            continue
        key = (norm(concept), norm(instance))
        # 精确去重：完全相同的元组直接跳过
        if key in seen_names:
            continue
        # 近似去重：仅当同领域、且概念与实例两维都越过相似度阈值才视为重复
        dup = False
        for (ck, ik), first in seen_names.items():
            if (
                rec.get("field") == first.get("field")
                and similarity(ck, key[0]) >= min_sim
                and similarity(ik, key[1]) >= min_sim
            ):
                dup = True
                break
        if dup:
            continue
        seen_names[key] = rec
        final.append(rec)
    return final


def write_records(records, out_path):
    """把记录逐行写入 JSONL（ensure_ascii=False 保留中文）。"""
    import json

    with open(out_path, "w", encoding="utf-8") as f:
        for rec in records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")