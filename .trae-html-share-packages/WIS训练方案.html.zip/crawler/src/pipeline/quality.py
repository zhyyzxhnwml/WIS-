"""抽取结果自动质检。

对 records.jsonl 清洗后的集合做规则检查，输出分级问题清单（high/medium/low），
用于在人工抽检之外自动兜住明显质量问题：

- 必填字段缺失 / 描述过短
- 概念过泛（无信息量的泛词、过短或过长）
- weight 越界或异常偏低
- 概念与实例高度雷同
- 同领域内疑似近义概念（字符集相似度过高但名称不同）
- 单概念过度聚集（疑为过粗粒度）
"""
import csv

from . import clean

# 无信息量的泛化词：概念名等于或仅含这些词时高度疑似「过泛」
GENERIC_WORDS = ["方法", "原理", "技术", "方案", "系统", "设计", "材料", "结构", "途径", "技术原理", "机制"]

# 阈值
MIN_NAME_LEN = 3                    # 概念最短长度
MIN_DESC_LEN = 10                   # 描述最短长度
MIN_WEIGHT = 0.5                    # weight 低限
MIN_SIM_CONCEPT_INSTANCE = 0.95       # concept 与 instance 两两字符相似度过高 -> 高度重合
MIN_SIM_NEAR_CONCEPT = 0.92           # 同领域两两概念 字符相似度阈值（与 clean 的去重阈值一致）
MAX_CONCEPT_OCCUR = 15                # 同一概念被引用超过该次数 -> low 级提示
MAX_NAME_LEN = 40                     # 概念超长阈值


def _txt(r, k):
    """取字段的非空文本（None/缺失归一为空串）。"""
    return str(r.get(k) or "").strip()


def _weight(r):
    """把 weight 转成 float；缺失/异常返回 None 以便单独处理。"""
    try:
        w = float(r.get("weight")) if r.get("weight") not in (None, "") else 1.0
    except (TypeError, ValueError):
        return None
    return w


def check(records):
    """records: 清洗后的记录列表。返回 (report_dict, issues_list)。

    问题分级：high=必填缺失/概念过泛；medium=short/anomaly；low=聚集提示类。
    """
    issues = []
    by_rule = {}
    by_level = {"high": 0, "medium": 0, "low": 0}

    def add(level, rule, rec, message):
        """登记一条问题并更新按级别/按规则的计数。"""
        issues.append({
            "level": level,
            "raw_id": rec.get("raw_id", ""),
            "field": rec.get("field", ""),
            "concept": rec.get("concept", ""),
            "instance": rec.get("instance", ""),
            "rule": rule,
            "message": message,
        })
        by_level[level] = by_level.get(level, 0) + 1
        by_rule[rule] = by_rule.get(rule, 0) + 1

    concept_refs = {}  # concept -> [引用它的记录]，用于统计聚集度
    for rec in records:
        concept = _txt(rec, "concept")
        instance = _txt(rec, "instance")
        cdesc = _txt(rec, "concept_desc")
        idesc = _txt(rec, "instance_desc")

        # r1 必填缺失
        missing = [k for k in ("concept", "instance", "instance_desc") if not rec.get(k)]
        if missing:
            add("high", "required_missing", rec, f"必填字段缺失: {','.join(missing)}")
        if not concept or not instance:
            continue  # 之后规则依赖 concept/instance，缺则跳过

        # r2 概念过泛 / 极短或超长
        if concept in GENERIC_WORDS or not concept:
            add("high", "generic_concept", rec, f"概念「{concept}」为无信息量泛词")
        elif len(concept) < MIN_NAME_LEN:
            add("medium", "short_concept", rec, f"概念过短: {len(concept)} 字")
        elif len(concept) > MAX_NAME_LEN:
            add("low", "long_concept", rec, f"概念过长: {len(concept)} 字")
        else:
            # 以泛词结尾且去掉泛词后所剩内容不足 3 字 → 泛词带走了全部信息量
            for w in sorted(GENERIC_WORDS, key=len, reverse=True):  # 长词优先匹配
                if concept.endswith(w) and len(concept) - len(w) < 3:
                    add("medium", "generic_concept", rec,
                        f"概念主要以泛词「{w}」构成，信息量低（针对「{concept}」）")
                    break

        # r3 描述过短（0 < 长度 < 阈值；为空已有 r1 覆盖，故仅判断 >0）
        for key, val, label in (("concept_desc", cdesc, "概念描述"), ("instance_desc", idesc, "实例描述")):
            if 0 < len(val) < MIN_DESC_LEN:
                add("medium", "short_desc", rec, f"{label}过短: {len(val)} 字")

        # r4 weight 异常
        w = _weight(rec)
        if w is not None and (not (0 <= w <= 1) or (w < MIN_WEIGHT and w > 0)):
            add("medium", "abnormal_weight", rec, f"weight={w} 异常偏低或越界")

        # r5 concept 与 instance 高度重合
        if clean.similarity(concept, instance) >= MIN_SIM_CONCEPT_INSTANCE:
            add("medium", "concept_instance_overlap", rec, f"概念与实例几乎相同: 相似度≥{MIN_SIM_CONCEPT_INSTANCE}")

        # r6 单概念聚集度：记录每个概念被引用的次数
        concept_refs.setdefault(concept, []).append(rec)

    # r7 同领域疑似近义概念（两两比较，仅提示）
    by_field = {}
    for rec in records:
        f = rec.get("field") or ""
        if f:
            by_field.setdefault(f, []).append(rec.get("concept") or "")
    for field, names in by_field.items():
        uniq = list(dict.fromkeys(n for n in names if n))  # 去重后的概念名
        for i in range(len(uniq)):
            for j in range(i + 1, len(uniq)):
                if uniq[i] != uniq[j] and clean.similarity(uniq[i], uniq[j]) >= MIN_SIM_NEAR_CONCEPT:
                    add("low", "near_duplicate_concept",
                        {"field": field, "concept": uniq[i], "instance": uniq[j], "raw_id": "", },
                        f"疑似近义概念: 「{uniq[i]}」vs「{uniq[j]}」相似度≥{MIN_SIM_NEAR_CONCEPT}")
    # r8 高度聚集概念：同一概念被引用过多，疑为过粗粒度（建议拆分）
    for concept, refs in sorted(concept_refs.items(), key=lambda kv: -len(kv[1])):
        if len(refs) > MAX_CONCEPT_OCCUR:
            add("low", "over_aggregated_concept", refs[0],
                f"概念「{concept}」被引用 {len(refs)} 次，疑为过度汇聚（建议拆分）")

    report = {
        "total": len(records),
        "issues": len(issues),
        "by_level": by_level,
        "by_rule": by_rule,
        "top_aggregated": [{"concept": c, "count": len(r)} for c, r in
                           sorted(concept_refs.items(), key=lambda kv: -len(kv[1]))[:10]],
        "sample": issues[:200],  # 报告中附带前 200 条问题便于快速浏览
    }
    return report, issues


def write_issues(issues, out_path):
    """把问题清单写成 CSV（utf-8-sig，字段名取第一条的键）。"""
    if not issues:
        return 0
    with open(out_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(issues[0].keys()))
        writer.writeheader()
        writer.writerows(issues)
    return len(issues)