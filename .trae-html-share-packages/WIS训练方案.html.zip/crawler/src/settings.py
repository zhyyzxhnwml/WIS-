"""配置加载：config.yaml + 环境变量。

集中管理所有可调参数（数据源、输出目录、DeepSeek 密钥等）。
优先级：环境变量（密钥） > config.yaml。
"""
import os
import pathlib

import yaml

# ROOT 指向 crawler/ 目录（本文件位于 crawler/src/，上两级即 crawler/）
ROOT = pathlib.Path(__file__).resolve().parent.parent
# 默认配置文件路径
DEFAULT_CONFIG = ROOT / "config.yaml"


class Settings:
    """从 config.yaml 解析出各类配置，并保证输出目录存在。

    属性约定：
    - root / raw_dir / extracted_dir / out_dir：路径相关
    - wikipedia / patents / baike / github / gitee：各数据源配置
    - deepseek / pipeline / validate：抽取与流水线配置
    """

    def __init__(self, config_path: pathlib.Path = DEFAULT_CONFIG):
        # 读取并解析 yaml 配置（以 UTF-8 读入，兼容中文）
        with open(config_path, "r", encoding="utf-8") as f:
            self._raw = yaml.safe_load(f)

        self.root = ROOT
        # 输出目录均相对项目根解析成绝对路径
        self.raw_dir = (ROOT / self._raw["output"]["raw_dir"]).resolve()
        self.extracted_dir = (ROOT / self._raw["output"]["extracted_dir"]).resolve()
        self.out_dir = (ROOT / self._raw["output"]["out_dir"]).resolve()
        # 不存在的目录自动创建，避免后续写入报错
        for d in (self.raw_dir, self.extracted_dir, self.out_dir):
            d.mkdir(parents=True, exist_ok=True)

        self.deepseek = self._raw["deepseek"]
        # 优先环境变量，避免密钥入库
        # 解析规则：DEEPSEEK_API_KEY 环境变量 > config.yaml 中的 api_key，都没有则为空串
        self.deepseek_key = os.environ.get("DEEPSEEK_API_KEY") or (
            self.deepseek.get("api_key") or ""
        )

        self.wikipedia = self._raw["sources"]["wikipedia"]
        self.patents = self._raw["sources"]["patents"]
        self.baike = self._raw["sources"]["baike"]
        self.github = self._raw["sources"]["github"]
        # gitee 是可选项，缺省给空列表与空 token，保证无该段配置时仍可用
        self.gitee = self._raw["sources"].get("gitee", {"repos": [], "token": ""})
        self.pipeline = self._raw["pipeline"]
        self.validate = self._raw["validate"]

    def wikipedia_fields(self):
        """返回 [(field, lang, category), ...] 按语言展开。

        每条配置可同时声明 zh_category 与 en_category，
        展开为各自独立的 (领域, 语言, 分类) 三元组，供抓取遍历。
        """
        out = []
        for item in self.wikipedia["fields"]:
            if item.get("zh_category"):
                out.append((item["field"], "zh", item["zh_category"]))
            if item.get("en_category"):
                out.append((item["field"], "en", item["en_category"]))
        return out

    def patent_queries(self):
        """返回 [(field, [query,...]), ...]，即各领域的专利检索词列表。"""
        return [(q["field"], q["queries"]) for q in self.patents["query_set"]]

    def baike_topics(self):
        """返回 [(field, [keywords,...]), ...]，即各领域的百度百科词条列表。"""
        return [(item["field"], item["keywords"]) for item in self.baike["topic_sets"]]


def load_settings(path=pathlib.Path(DEFAULT_CONFIG)):
    """便捷入口：默认加载配置并返回 Settings 实例。"""
    return Settings(path)